var TC001_ProductQuality = function () {
  this.setDefaultTimeout(60000);

  var login = require("../PageObjects/login-po.js");
  var PQ_HomePage = require("../PageObjects/PQ_HomePage-po.js");
 var checkLoopValue=require("../PageObjects/checkLoopValue-po.js");

  this.Given(/^Login to the Application with the given credential$/, function () {
    browser.ignoreSynchronization = true;
    return login.navigateAndLogin().then(function () {
    });
  });

  this.When(/^Click on CONTINUE button in a Welcome popup page, and close Scorecard popup from home page$/, function () {
     PQ_HomePage.popup_ContinueButton();
         PQ_HomePage.clickBalanceScorecard();  
     //^^^Page hits on 'SEE PROTOTYPE' So this method takes us to 'BALANCE SCORECARD' page
     return    PQ_HomePage.closePopupbutton();
        // PQ_HomePage.delta_Toggle();
  });

  this.Then(/^Display all the Dates from the dropdown list and verify that latest date is selected in ISSUE DATE OF REPORT$/, function () {
    
    PQ_HomePage.clickListedDatesDropdown();
    PQ_HomePage.readAllListedDate();
    return  PQ_HomePage.select_IssueDateOfReport();
     
      
  });

  this.Then(/^Verify that table contains only one row which have GEHC in a Product Quality Scorecard column$/, function () {
    return   PQ_HomePage.readFirstRow();
    // return PQ_HomePage.readSecondRow();
  });

  this.Then(/^Verify REGION status is selected as ALL and DELTA as OFF$/, function () {
    PQ_HomePage.REGIONValue();
    return PQ_HomePage.DeltaButtonValue();
  });

  this.Then(/^Verify Search, Hide Metric and Metric Column space should be Empty$/, function () {
    PQ_HomePage.DisplayContentsFromSearch();
    PQ_HomePage.DisplayContentsFromHideMetric();
    return PQ_HomePage.DisplayContentsFromMetricColumn();

  });

  this.Then(/^Read all the values listed in a Dropdown from Legend and Other option button$/, function () {
    // PQ_HomePage.selectTab(' METRICS ');
    // PQ_HomePage.clickOnSearchSpace();
    
    PQ_HomePage.ClickLegendButton();
    PQ_HomePage.DisplayDropdownValuesFromLegend();
    checkLoopValue.escapeClick();
    
    PQ_HomePage.ClickOtherOptionsButton();
      PQ_HomePage.DisplayDropdownValuesFromOtherOptions();
   return checkLoopValue.escapeClick();
     
  });

  this.When(/^Click on Refresh button, Only one GEHC row should displayes on a page$/, function () {
  return  PQ_HomePage.ClickRefreshButton();
  });

  this.Then(/^Read all the Main header$/, function () {
//       PQ_HomePage.MetricMainHeader().then(function(t){ 
//  console.log("Heared vales: "+t);     });
     
    //  PQ_HomePage.MetricMainHeader();
          // checkLoopValue.MetricMainHeaderValues();
   return checkLoopValue.MetricMainHeaderValues();
      //  PQ_HomePage.MetricMainHeader();
  });

  this.Then(/^Read all the Sub header Values$/, function () {
    return   PQ_HomePage.subHeaderAllValues();
      //  checkLoopValue.verifyFileInDownloadsFolder(); //verify weather the file is downloaded or no
  });

  this.Then(/^Read all the Dropdown values from Metric Column$/, function () {
    PQ_HomePage.clickMerticColumnDropdownLink();
    //  PQ_HomePage.metricColoumnDropDownList();
     PQ_HomePage.CompareVlauesFromSubHeader();
     return PQ_HomePage.HideMetricDropdown();
  });

  this.Then(/^Read the Hide Metric dropdown values and its count$/, function(){
   
    PQ_HomePage.HideMetricDropdown();
      PQ_HomePage.listedDropdownValues();
      return checkLoopValue.escapeClick();
  });

  this.Then(/^Read all Hide Column dropdown values and its count$/, function(){
     PQ_HomePage.HideColumnDropdown();
       PQ_HomePage.listedDropdownValues();
     return checkLoopValue.escapeClick();
    //  PQ_HomePage.HideColumnDropdown();
  });

  this.When(/^Enable the Checkbox from Hide Metric dropdown$/, function(){
    PQ_HomePage.HideMetricDropdown();
    checkLoopValue.selectAndReadCheckbox(1);
    // checkLoopValue.selectAndReadCheckbox(3);
    checkLoopValue.escapeClick();
  
  return PQ_HomePage.MetricMainHeader();
  });


this.Then(/^Proceed with recursive click$/,function(){
  PQ_HomePage.clickOnFirstRowValue();
return checkLoopValue.recursiveReadings();
});

};
module.exports = TC001_ProductQuality;