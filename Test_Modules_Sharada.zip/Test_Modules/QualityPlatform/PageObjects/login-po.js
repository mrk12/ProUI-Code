function login() {
    
    var self = this;
    var EC = protractor.ExpectedConditions;
    var PromiseUtils = require('../PageObjects/promise-utils-po.js');
    var promiseUtil = new PromiseUtils();
    var currentPage = 'loginXpaths';
    var currentPage1 = 'PQ_homepage_Locators';

    var loginpage = objectManager.getLocalObjectManager("QualityPlatform", "login", currentPage);
    var mainhomepage = objectManager.getLocalObjectManager("QualityPlatform", "PQ_HomePage", currentPage1);
    var lem = loginpage.ElementManager;
    var lem1 = mainhomepage.ElementManager;
    var testHelper = loginpage.TestHelper;
    // this.waitTime = 60000;
   
    this.get = function (url) {
        return browser.driver.get(url);
    };

    this.setUserName = function (username) {
        var elementUsername = lem.findElement(currentPage, 'username');
        return promiseUtil.getDisplayedElement(elementUsername).then(function () {
            return promiseUtil.clear(elementUsername).then(function () {
                return promiseUtil.sendKeys(elementUsername, username).then(function () {
                    return true;
                });
            });
        });
    };

    this.setPassword = function (password) {
        var elementPassword = lem.findElement(currentPage, 'password');
        return promiseUtil.getDisplayedElement(elementPassword).then(function () {
            return promiseUtil.clear(elementPassword).then(function () {
                return promiseUtil.sendKeys(elementPassword, password).then(function () {
                    return true;
                });
            });
        });
    };

    this.clickLoginButton = function () {
        var signinButton = lem.findElement(currentPage, 'signin');
        var continueButton = lem1.findElement(currentPage1, 'Popup');
        return promiseUtil.clickAndVerifyDisplayedElement(signinButton, continueButton);
        // return promiseUtil.click(signinButton);
    };

    this.signOut = function () {
        var signinButton = lem.findElement(currentPage, 'signin');
        var signoutButton = lem.findElement(currentPage, 'signout');
        return promiseUtil.clickAndVerifyDisplayedElement(signoutButton, signinButton);
    };

    this.login = function (userName, password) {
        self.setUserName(userName);
        self.setPassword(password);
        // if (database) {
        //     self.setDatabase(database);
        // }
        return self.clickLoginButton();
    };

    this.navigateAndLogin = function () {
        var url = browser.params.login.baseUrl;
        var userName = browser.params.login.username;
        var password = browser.params.login.password;
        // var database = browser.params.login.database;

        self.get(url);
        return self.login(userName, password);
    };
}
module.exports = new login();

