
function PromiseUtils() {
    var self = this;
    var EC = protractor.ExpectedConditions;
    this.waitTime = 60000;

    this.getAll = function (locator) {
        var deferred = protractor.promise.defer();

        var arr = [];
        element.all(locator).then(function (items) {
            items.forEach(function (item, index) {
                arr.push(item);
            });
        });
        deferred.fulfill(arr);

        return deferred.promise;
    };

    this.getAllText = function (locator) {
        var deferred = protractor.promise.defer();

        self.getAll(locator).then(function (items) {
            var arr = [];
            for (var i = 0; i < items.length; i++) {
                items[i].getText().then(function(text) {
                    arr.push(text);
                });
            }
            return arr;
        }).then(function (data) {
            deferred.fulfill(data);
        });

        return deferred.promise;
    };

    this.getAllElementsText = function (elements) {
        var deferred = protractor.promise.defer();
        var arr = [];
        for (var i = 0; i < elements.length; i++) {
            elements[i].getText().then(function (text) {
                arr.push(text);
            });
        }
        deferred.fulfill(arr);

        return deferred.promise;
    };

    this.getAllAttribute = function (locator, attribute) {
        var deferred = protractor.promise.defer();

        self.getAll(locator).then(function (items) {
            var arr = [];
            for (var i = 0; i < items.length; i++) {
                items[i].getAttribute(attribute).then(function (attributeValue) {
                    arr.push(attributeValue);
                });
            } 
            return arr;
        }).then(function (data) {
            deferred.fulfill(data);
        });

        return deferred.promise;
    
    };

    this.getAllElementsAttribute = function (elements, attribute) {
        deferred = protractor.promise.defer();
        elements.count().then(function (s) { console.log('total count is:' + s); });
        var arr = [];
        elements.then(function (items) {
            items.forEach(function (item, index) {
                item.getAttribute(attribute).then(function (attributeValue) {
                    arr.push(attributeValue);
                });
            });
            return arr;
        }).then(function (data) {
            deferred.fulfill(data);
        });
        return deferred.promise;
    };

    this.getCount = function (locator) {
        var deferred = protractor.promise.defer();

        element.all(locator).then(function (items) {
            return items.length;
        }).then(function (data) {
            deferred.fulfill(data);
        });

        return deferred.promise;
    };

    this.getByIndex = function (locator, index) {
        var deferred = protractor.promise.defer();

        deferred.fulfill(element.all(locator).get(index - 1));

        return deferred.promise;
    };

    this.click = function (element) {
        return browser.wait(function () { return element.click().then(function () { return true; }, function () { return false; }); }, self.waitTime);
    };

    this.clear = function (element) {
        return browser.wait(function () { return element.clear().then(function () { return true; }, function () { return false; }); }, self.waitTime);
    };

    this.sendKeys = function (element, text) {
        return browser.wait(function () { return element.sendKeys(text).then(function () { return true; }, function () { return false; }); }, self.waitTime);
    };

    this.getDisplayedElement = function (element) {
        return browser.wait(EC.visibilityOf(element), self.waitTime).then(function () {
            return element;
        });
    };

    this.isElementDisplayed = function (element) {
        return browser.wait(EC.visibilityOf(element), self.waitTime).then(function () {
            return true;
        }, function () { return false; });
    };

    this.isElementNotDisplayed = function (element) {
        return browser.wait(EC.invisibilityOf(element), self.waitTime).then(function (status) {
            return true;
        }, function () { return false; });
    };

    this.isElementPresent = function (element) {
        return browser.wait(EC.presenceOf(element), self.waitTime).then(function () {
            return true;
        }, function () { return false; });
    };

    this.getPresentElement = function (element) {
        return browser.wait(EC.presenceOf(element), self.waitTime).then(function () {
            return element;
        });
    };

    this.getDisplayedElementText = function (element) {
        var deferred = protractor.promise.defer();

        browser.wait(EC.visibilityOf(element), self.waitTime);
        element.getText().then(function (text) {
            deferred.fulfill(text);
        });

        return deferred.promise;
    };

    this.getPresentElementText = function (element) {
        var deferred = protractor.promise.defer();

        browser.wait(EC.presenceOf(element), self.waitTime);
        element.getText().then(function (text) {
            deferred.fulfill(text);
        });

        return deferred.promise;
    };

    this.clickAndVerifyDisplayedElement = function (elementToClick, elementToVerify) {
        var deferred = protractor.promise.defer();

        self.click(elementToClick);
        browser.wait(EC.visibilityOf(elementToVerify), self.waitTime).then(function (displayed) {
            deferred.fulfill(displayed);
        });

        return deferred.promise;
    };

    this.clickAndVerifyPresentElement = function (elementToClick, elementToVerify) {
        var deferred = protractor.promise.defer();

        self.click(elementToClick);
        browser.wait(EC.presenceOf(elementToVerify), self.waitTime).then(function (displayed) {
            deferred.fulfill(displayed);
        });

        return deferred.promise;
    };
}
module.exports = PromiseUtils;