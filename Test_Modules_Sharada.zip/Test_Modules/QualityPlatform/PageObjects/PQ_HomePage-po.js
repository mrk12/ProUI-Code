function PQ_HomePage() {
    var currentPage = 'PQ_homepage_Locators';
    var self = this;
    var PromiseUtils = require('../PageObjects/promise-utils-po.js');
    var promiseUtil = new PromiseUtils();

    var mainhomepage = objectManager.getLocalObjectManager("QualityPlatform", "PQ_HomePage", currentPage);
    var lem = mainhomepage.ElementManager;
    var TestHelper = mainhomepage.TestHelper;



    //Click on "Continue" button which is displayed on the Popup page
    this.popup_ContinueButton = function () {
        TestHelper.elementToBeClickable(currentPage, "Popup");
        console.log("Continue button is clicked on a Welcome page popup");
        return Logger.info("Continue button is clicked on a Welcome page popup");
    };

     //Click on the ScoreCard popup Close button
     this.closePopupbutton = function () {
        TestHelper.elementToBeClickable(currentPage, "CloseScoreCard");
        console.log("Scorecard popup is closed");
        return Logger.info("Scorecard popup is closed");
    };

    //Reads the Issue Date of Report and displayes the same
    this.select_IssueDateOfReport = function (Expected) {
        var displayedDate = lem.findElement(currentPage, "LatestDate");
        return promiseUtil.getDisplayedElement(displayedDate).then(function (selectWritenDate) {
            return selectWritenDate.getText().then(function (showingDate) {
                console.log("Issue Date Of Report is displayed as : " + showingDate);
                TestHelper.assertTrue(showingDate, Expected);
                Logger.info("Issue Date Of Report is displayed as : " + showingDate);
            });
        });
    };

    //Click on down arrow to open a dropdown list in Issue date of Report 
    this.clickListedDatesDropdown = function () {
        TestHelper.elementToBeClickable(currentPage, "ClickDropdownForDateList");
        console.log("Clicked on down arrow for ISSUE DATE OF REPORT dropdown");
        return Logger.info("Clicked on down arrow for ISSUE DATE OF REPORT dropdown");
    };

    // Read all the listed dates from a Issue Date of Report dropdown
    this.readAllListedDate = function () {
        return element.all(by.xpath("//mat-option[contains(@id,'mat-option')]//span[contains(@class,'mat-option-text')]")).getText().then(function (ReadAllDate) {
            console.log("Dates list which is in ISSUE DATE OF REPORT dropdown: "+ReadAllDate);
            Logger.info("Dates list which is in ISSUE DATE OF REPORT dropdown:");
return element.all(by.xpath("//mat-option[contains(@id,'mat-option')]//span[contains(@class,'mat-option-text')]")).get(0).getText().then(function (ReadLatestDate) {
                console.log("Latest Date which is in ISSUE DATE OF REPORT dropdown: " + ReadLatestDate);
                return Logger.info("Latest Date which is in ISSUE DATE OF REPORT dropdown");
            });
        });
    };

    //In general set any past date or future date(here adding one more month to todays date)
    this.GetTodayDate = function () {

        var today = new Date();
        var dd = today.getDate();
        var mm = today.getMonth();
        var yyyy = today.getFullYear();
        if (dd < 10) {
            dd = '0' + dd;
        }

        if (mm < 12) {
            mm = 1 + mm;
        }

        // today = mm + '/' + dd + '/' + yyyy;
        today = yyyy + '-' + dd + '-' + mm;
        console.log(today);
        return today;
    };


   
//Read a First row value which in a home page table
    this.readFirstRow = function (GEHC) {
        var ReadFirstRowName = lem.findElement(currentPage, "FirstRowContains");
        return promiseUtil.getDisplayedElement(ReadFirstRowName).then(function (RowName) {
            return RowName.getText().then(function (RowNameContains) {
                console.log("First row contains a value as: " + RowNameContains);
                TestHelper.assertTrue(RowNameContains, GEHC);
                return       Logger.info("First row contains a value as: " + RowNameContains);
            });
        });
    };


    this.clickOnFirstRowValue=function(){
        browser.driver.sleep(3000);
        TestHelper.elementToBeClickable(currentPage,"FirstRowContains");
        return console.log("GEHC row is selected");
    };
 
    //Verify a Second row value from a home page table and refresh the page if it present
    this.readSecondRow = function () {
        var ReadSecondRowName = lem.findElement(currentPage, "SecondRowContains");
        return promiseUtil.isElementPresent(ReadSecondRowName).then(function (SecRowName) {
            // var SecRowName=promiseUtil.isElementPresent(ReadSecondRowName).then(function (SecRowName)
            if (SecRowName == true) {
                console.log("Multiple Rows are present so click on Reload button");
             return     self.ClickRefreshButton();
            }
            else {
         return   console.log("Verified as Single Row is Present in a Table");   
            }
    //  return   console.log("Second Row is not Present and it is " + SecRowName); 
        });
    };

    //Verify Region is having a Value as 'ALL' by Default
    this.REGIONValue = function (ExpectedValue) {
        var DefaultRegionValue = lem.findElement(currentPage, "RegionDefaultValue");
        return promiseUtil.getDisplayedElement(DefaultRegionValue).then(function (selectWritenValue) {
            return selectWritenValue.getText().then(function (showingValue) {
                console.log("Region Value is displayed by default as : " + showingValue);
                TestHelper.assertTrue(showingValue, ExpectedValue);
                Logger.info("Region Value is displayed by default as : " + showingValue);
            });
        });
    };

    //Verify 'Delta' should be by default 'OFF'
    this.DeltaButtonValue = function (ExpectedButtonValue) {
        var DefaultDeltaButtonValue = lem.findElement(currentPage, "DeltaValueOff");
        return promiseUtil.getDisplayedElement(DefaultDeltaButtonValue).then(function (DeltaValue) {
            return DeltaValue.getText().then(function (showingDeltaValue) {
                console.log("Delta button is Enabled as : " + showingDeltaValue);
                TestHelper.assertTrue(showingDeltaValue, ExpectedButtonValue);
                Logger.info("Delta button is Enabled as : " + showingDeltaValue);
            });
        });
    };

    

    this.deltaToggle_ON=function(){
        TestHelper.elementToBeClickable(element(by.xpath("//button[contains(@class,'mat-button-toggle-button')]//div[text()='ON']")));
    };

    this.deltaToggle_OFF=function(){
        TestHelper.elementToBeClickable(element(by.xpath("//button[contains(@class,'mat-button-toggle-button')]//div[text()='OFF']")));
    };

    this.clickOnSearchSpace = function () {
        TestHelper.elementToBeClickable(currentPage, "Searchicon");
        browser.actions().sendKeys(protractor.Key.ENTER).perform();
     return    console.log("Cicked on search icon");
        
    };

//Verify and confirm as Search doesnot have any value init
    this.DisplayContentsFromSearch = function (blank) {
        var DeafultSearchValue = lem.findElement(currentPage, "SearchSpace");
        return promiseUtil.getDisplayedElement(DeafultSearchValue).then(function (searchValue) {
            return searchValue.getText().then(function (Searchvaluecontains) {
                console.log("Search Space Contains: " + Searchvaluecontains);
                TestHelper.assertTrue(Searchvaluecontains, blank);
                Logger.info("Search Space Contains: " + Searchvaluecontains);
            });
        });
    };

//Verify and confirm as Hide Metric doesnot have any value init
    this.DisplayContentsFromHideMetric = function (blank) {
        var DefaultHideMetricValue = lem.findElement(currentPage, "HideMetric");
        return promiseUtil.getDisplayedElement(DefaultHideMetricValue).then(function (HideMetricValue) {
            return HideMetricValue.getText().then(function (HideMetricContains) {
                console.log("Hide Metric contains: " + HideMetricContains);
                TestHelper.assertTrue(HideMetricContains, blank);
                Logger.info("Hide Metric contains: " + HideMetricContains);
            });
        });
    };

//Verify and confirm as Metric Column doesnot have any value init
    this.DisplayContentsFromMetricColumn = function (blank) {
        var DefalutMetricColumnValue = lem.findElement(currentPage, "HideColumn");
        return promiseUtil.getDisplayedElement(DefalutMetricColumnValue).then(function (MetricColumnValue) {
            return MetricColumnValue.getText().then(function (MetricCloumnContains) {
                console.log("Metric Column Contains: " + MetricCloumnContains);
                TestHelper.assertTrue(MetricCloumnContains, blank);
                Logger.info("Metric Column Contains: " + MetricCloumnContains);
            });
        });
    };

    this.ClickRefreshButton = function () {
        TestHelper.elementToBeClickable(currentPage, "RefeshLink");
        return console.log("Refresh Button is Clicked");

    };

//Legend Button is Clicked to get a listed values
    this.ClickLegendButton = function () {
        TestHelper.elementToBeClickable(currentPage, "Legendbutton");
        console.log("Legend Button is Clicked");
             Logger.info("Legend Button is Clicked");
    };

//Other option Button is Clicked to get a listed values
    this.ClickOtherOptionsButton = function () {
        TestHelper.elementToBeClickable(currentPage, "OtherOptionsButton");
        console.log("Other Options Button is Clicked");
     Logger.info("Other Options Button is Clicked");
    };

//List all the dropdown values from a Legend 
    this.DisplayDropdownValuesFromLegend = function () {
        return element.all(by.xpath("(//button[@class='mat-menu-item'])")).getText().then(function (DefalutDropdownValuesFromLegend) {
            console.log("Displaying all the Legend elements: "+DefalutDropdownValuesFromLegend);
            Logger.info("Displaying all the Legend elements: "+DefalutDropdownValuesFromLegend);
        });
    };

//List all the dropdown values from a Other option
    this.DisplayDropdownValuesFromOtherOptions = function () {
        return element.all(by.xpath("(//button[@class='mat-menu-item ng-star-inserted'])")).getText().then(function (DefaultDropdownValuesFromOtherOption) {
            console.log("Displaying all the Other option elements: "+DefaultDropdownValuesFromOtherOption);
            Logger.info("Displaying all the Other option elements: "+DefaultDropdownValuesFromOtherOption);
        });
    };

    //Read all the Main Header
    this.MetricMainHeader = function () {
        return element.all(by.xpath("((//table[@id='myTable']//tr[@class='header'])//)[1]")).getText().then(function (AllMetricHeader) {
            console.log("All the Main Headers list from the table: "+ AllMetricHeader);      
   
            return element.all(by.xpath("(//table[@id='myTable']//tr[@class='header'])//th")).count().then(function (AllMetricHeadercount) {
                console.log("Main header count: "+AllMetricHeadercount);     
// var a1= element(by.xpath('//tr[@class="header"]'));  
// return a1.getText(); 
    });
            });   
    };

    this.subHeaderAllValues = function () {
        return element.all(by.xpath("//tr[@class='subheader']//th")).count().then(function (numberAllSubHeader) {
            console.log("sub header count: " + numberAllSubHeader);
            var allheader = element.all(by.xpath("//tr[@class='subheader']//th"));
            return allheader.getText().then(function (readAllSubHeader) {
                console.log("SubHeader contains following values: ");
                console.log(readAllSubHeader);
            });
        });
    };

    this.clickMerticColumnDropdownLink = function () {
   return     TestHelper.elementToBeClickable(currentPage, "clickDropdownLinkOfMetricColumn");
    };

    this.metricColoumnDropDownList = function () {
        return element.all(by.xpath("//mat-pseudo-checkbox/..//span[@class='mat-option-text']")).getText().then(function (dispalyAllDropDownValues) {
            console.log("Metric Column contsins following values: ");
            console.log(dispalyAllDropDownValues);
        });
    };


    this.CompareVlauesFromSubHeader = function () {
    var metricColoumnDropDown = element.all(by.xpath("//mat-pseudo-checkbox/..//span[@class='mat-option-text']"));
        var subHeaderValues = element.all(by.xpath("//tr[@class='subheader']//th"));
        // expect(metricColoumnDropDown.getText()).toEqual(subHeaderValues.getText());
        // console.log("Values are Compared");
        return metricColoumnDropDown.count().then(function (metricColoumnCount) {
            console.log("Metric Column values count: " + metricColoumnCount);
            return subHeaderValues.count().then(function (subHeaderCount) {
                console.log("Sub Header Count: " + subHeaderCount);
            });
        });
    };


//Click on Hide Metric Dropdown
this.HideMetricDropdown=function(){
    browser.driver.sleep(8000);
    TestHelper.elementToBeClickable(currentPage,"ClickHideMetricDropdown");
    return    console.log("Hide Metric dropdown is clicked");
};

//Click on close Hide Metric dropdown
this.closeHideMetricDropdown=function(event){
   // TestHelper.elementToBeClickable(currentPage,"ClickHideMetricDropdown");
//    event.stopProgation();
browser.sleep(2000);
   browser.actions().sendKeys(protractor.Key.ENTER ).perform();
    return    console.log("Hide Metric dropdown is clicked to close");
}; 

//Click on Hide Column Dropdown
this.HideColumnDropdown=function(){
    TestHelper.elementToBeClickable(currentPage,"ClickHideColumnDropdown");
    return console.log("Hide Column is clicked");
};

    //List of dropdown values from Hide Metric and Column
    this.listedDropdownValues=function(){
        browser.driver.sleep(5000);
        var DropdownListedValues=element.all(by.xpath("//span[@class='mat-option-text']"));
        return DropdownListedValues.count().then(function(listedValueCount){
            return DropdownListedValues.getText().then(function(displayAlltheListedValue){
                console.log("Total count of the values are present in a list: "+listedValueCount);
                Logger.info("Total count of the values are present in a list: "+listedValueCount);
                console.log("Display all the values are present in a list: "+displayAlltheListedValue);
                Logger.info("Display all the values are present in a list: "+displayAlltheListedValue);
            });
        });
        
    };

    this.Scroll = function () {
        var scrollLeft = element(by.xpath("(//div[@class='ps__thumb-x']/../..//table//tr[@class='header']//th[contains(@class,'ng-star-inserted')])[10]"));
        scrollLeft.click().then(function(){
        scrollLeft.sendKeys(protractor.Key.ENTER);  
        // browser.executeScript('arguments[0].scrollIntoView()',scrollLeft.getWebElement());
        // browser.actions().mouseMove(scrollLeft).perform();
        
        
    });
 };

//Click and select a tab
this.selectTab=function(ReplaceText){
    var TabOption=element(by.xpath("//div[@class='mat-tab-links']//a[contains(text(),' " + ReplaceText + " ')]"));
    TestHelper.elementToBeClickable(TabOption);
 return   console.log(ReplaceText+ "tab is selectd");
};  

this.delta_Toggle=function(){
    TestHelper.elementToBeClickable(currentPage, "ToggleDelta");
 return   console.log("Toggle popup is closed");
};

this.clickBalanceScorecard=function(){
    TestHelper.elementToBeClickable(currentPage,"BalaceScoreCardTab");
   
    browser.actions().sendKeys( protractor.Key.ENTER ).perform();
    return   console.log("Page moves from SEE PROTOTYPE to BALANCED SCORECARD");
};


}
module.exports = new PQ_HomePage();