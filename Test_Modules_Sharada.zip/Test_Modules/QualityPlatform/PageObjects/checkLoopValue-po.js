function checkLoopValue() {
    var currentPage = 'Value4AllLoop';
    var self = this;
    var PromiseUtils = require('../PageObjects/promise-utils-po.js');
    var promiseUtil = new PromiseUtils();

    var mainhomepage = objectManager.getLocalObjectManager("QualityPlatform", "checkLoopValue", currentPage);
    var lem = mainhomepage.ElementManager;
    var TestHelper = mainhomepage.TestHelper;
    var firstLevelElements;
    var secondLevelElements;

this.enableCheckbox_HideMetric=function(replacenumber){
    var path4Checkbox=element(by.xpath("(//mat-pseudo-checkbox)[" + replacenumber + "]"));
    browser.sleep(2000);
    TestHelper.elementToBeClickable(path4Checkbox);
 return   console.log(replacenumber+ " checkbox is selected");
};



this.readEnabledCheckboxValue=function(replacenumber){
    var CheckboxValue=element(by.xpath("(//mat-pseudo-checkbox/..//span[@class='mat-option-text'])[" + replacenumber + "]"));
    browser.sleep(2000);
   return promiseUtil.getDisplayedElement(CheckboxValue).then(function(getElementValue){
       return getElementValue.getText().then(function(ReadTextValue){
           console.log(replacenumber+" line is selected and it conatins a value as "+ ReadTextValue);
       });
   });
};

this.selectAndReadCheckbox=function(indexnumner){
    self.enableCheckbox_HideMetric(indexnumner);
    self.readEnabledCheckboxValue(indexnumner);
};

this.verifyFileInDownloadsFolder=function() {
    console.log("hi");
        var filename = 'C:/Users/smania/Downloads/download.xls';
       return   browser.driver.wait(function() {
            return fs.existsSync(filename);
          }, 30000).then(function() {
            console.log("Getting the ERROR while downloading file as file is not downloaded.");
          });
};


//Read all the Main Header
this.MetricMainHeaderValues= function () {
       
        //     for(var i=1; i<=4; i++)
        //     {
        //     console.log("i is:: "+i);
     
        //     // var Hearedvalue=element(by.xpath("(//table[@id='myTable']//tr[@class='header'])//th[" + i + "]"));
        // //   return Hearedvalue.getText().then(function(Headervalue){

        //     return element.all(by.xpath("(//table[@id='myTable']//tr[@class='header'])//th[" + i + "]")).getText().then(function(Headervalue1){
        //         // var Headervalue1=Headervalue.getText();
        //      console.log("Heared name is :"+Headervalue1);
        //     });   
        // }

        
            browser.waitForAngular();
            browser.driver.sleep(3000);
            return element(by.xpath("(//table[@id='myTable']//tr[@class='header'])//th[1]")).getText().then(function (completed) {
            console.log("title : " + completed);
            //assert.equal(tooltip,completed); 
            return element(by.xpath("(//table[@id='myTable']//tr[@class='header'])//th[2]")).getText().then(function (complete) { 
            console.log("title : " + complete); 
            return element(by.xpath("(//table[@id='myTable']//tr[@class='header'])//th[3]")).getText().then(function (completed) {
                console.log("title : " + completed);
                //assert.equal(tooltip,completed); 
                return element(by.xpath("(//table[@id='myTable']//tr[@class='header'])//th[4]")).getText().then(function (complete) { 
                console.log("title : " + complete); 

                var elm = element.all(by.xpath("(//div[@class='ps__thumb-x']/../..//table//tr[@class='header']//th)[6]")).last(); 
                browser.executeScript("arguments[0].scrollIntoView();", elm.getWebElement()).then(function () {
                    var until = protractor.ExpectedConditions;
                    browser.sleep(5000);
                    browser.executeScript('window.scrollTo(5000,0);');
                    console.log('Page Scroll side'); 



            //     TestHelper.elementToBeClickable(element(by.xpath("(//div[@class='ps__thumb-x']/../..//table//tr[@class='header']//th)[5]")));
            // console.log("scroll ");
            // TestHelper.elementToBeClickable(element(by.xpath("//button[contains(@class,'okbtn')]")));
            // console.log("Click ok button");
            // for(var j=5; j<=8; j++)
            // {
            // console.log("i is:: "+j);
            // var Headervalue2= element(by.xpath("(//table[@id='myTable']//tr[@class='header'])//th[" + j + "]")).getText();
            //  console.log("Heared name is :"+Headervalue2);
            // }

            browser.waitForAngular();
            browser.driver.sleep(3000);
            return element(by.xpath("(//table[@id='myTable']//tr[@class='header'])//th[5]")).getText().then(function (completed) {
            console.log("title : " + completed);
            //assert.equal(tooltip,completed); 
            return element(by.xpath("(//table[@id='myTable']//tr[@class='header'])//th[6]")).getText().then(function (complete) { 
            console.log("title : " + complete); 
            // return element(by.xpath("(//table[@id='myTable']//tr[@class='header'])//th[7]")).getText().then(function (completed) {
            //     console.log("title : " + completed);
            //     //assert.equal(tooltip,completed); 
            //     return element(by.xpath("(//table[@id='myTable']//tr[@class='header'])//th[8]")).getText().then(function (complete) { 
            //     console.log("title : " + complete); 

                var elm = element.all(by.xpath("(//div[@class='ps__thumb-x']/../..//table//tr[@class='header']//th)[8]")).last(); 
                browser.executeScript("arguments[0].scrollIntoView();", elm.getWebElement()).then(function () {
                    var until = protractor.ExpectedConditions;
                    browser.sleep(5000);
                    browser.executeScript('window.scrollTo(5000,0);');
                    console.log('Page Scroll side'); 

                    return element(by.xpath("(//table[@id='myTable']//tr[@class='header'])//th[7]")).getText().then(function (completed) {
                        console.log("title : " + completed);
                        //assert.equal(tooltip,completed); 
                        // return element(by.xpath("(//table[@id='myTable']//tr[@class='header'])//th[8]")).getText().then(function (complete) { 
                        // console.log("title : " + complete); 
                    //     return element(by.xpath("(//table[@id='myTable']//tr[@class='header'])//th[9]")).getText().then(function (complete) { 
                    //     console.log("title : " + complete); 
                    // }); 
                    // }); 
                });
            }); 
        });
            }); 
        });
        
          
    }); 
});
    }); 
});  
        //     });
        // });
};


this.recursiveReadings1234=function(){
    browser.waitForAngular();
    browser.driver.sleep(5000);
    var readall= element.all(by.xpath("//tr[contains(@class,'level1')]//th[contains(@class,'scorecard')]"));

    return readall.then(function(allR){

    for(var i=1; i<allR.length; ++i){
        //getPromise.then(function(){
            return allR(i).getText().then(function(readallatone){
    console.log(readallatone);
}); //}); 
    }  });
    };
//   console.log("Total number of Elements in Level 1: "+levelOneCount);
//   for(var i=1;i<levelOneCount.length;++i){
//     browser.waitForAngular();
//     browser.driver.sleep(3000);
//  firstLevelElements=
//   element.all(by.xpath("(//tr[contains(@class,'level1')]//th[contains(@class,'scorecard')])[" + i + "]"));
//   return firstLevelElements.getText().then(function(oneElementName){
//       browser.sleep(2000);
//       console.log("Element name which is in 1 level: "+oneElementName);
//   });
// });



this.recursiveReadings=function(){
    browser.waitForAngular();
    browser.driver.sleep(3000);
    return element.all(by.xpath("//tr[contains(@class,'level1')]//th[contains(@class,'scorecard')]")).count().then(function(levelOneCount){
  console.log("Total number of Elements in Level 1: "+ levelOneCount, levelOneCount);

  browser.waitForAngular();
  browser.sleep(6000);
  for(var i=1; i<=levelOneCount; i++){
    browser.waitForAngular();
    browser.driver.sleep(3000);
    console.log("entered into for loop " +i);
 firstLevelElements= element.all(by.xpath("(//tr[contains(@class,'level1')]//th[contains(@class,'scorecard')])[" + i + "]"));
  firstLevelElements.getText().then(function(oneElementName){
      browser.sleep(2000);
      console.log("Element name which is in 1 level 2: "+oneElementName);
  
//    TestHelper.elementToBeClickable(firstLevelElements);
//       browser.sleep(2000);
//     return element.all(by.xpath("//tr[contains(@class,'level1')]//th[contains(@class,'scorecard')]")).count().then(function(levelTwoCount){
//   console.log("Total number of Elements in Level 1: "+levelTwoCount);
//       for(var j=1;j<=levelTwoCount;j++){      //get the count for intervention and update
//          secondLevelElements=
//       element.all(by.xpath("(//tr[contains(@class,'level2')]//th[contains(@class,'scorecard')])[" + j + "]"));
//       browser.sleep(2000);
//       return secondLevelElements.getText().then(function(twoElementName){
//           console.log("Element name which is in "+j+" level: "+twoElementName);
//           TestHelper.elementToBeClickable(secondLevelElements); 

//  var elm = 
//  element.all(by.xpath("(//div[@class='ps__thumb-y']/../..//table//tr[contains(@class,'level3')]//th)[1]")).last(); 
//  browser.driver.sleep(3000);
//           browser.executeScript("arguments[0].scrollIntoView();", elm.getWebElement()).then(function () {
//               var until = protractor.ExpectedConditions;
//               browser.driver.sleep(1000);
//               browser.executeScript('window.scrollTo(0,5000);');
//         // browser.actions().mouseMove(elm).perform();
//               console.log('Page Scroll down'); 

// var thirdLevelElements=
//       element.all(by.xpath("(//tr[contains(@class,'level3')]//th[contains(@class,'scorecard')])"));
//       browser.driver.sleep(2000);
//       return thirdLevelElements.count().then(function(thirdLevelAllCount){
//       return thirdLevelElements.getText().then(function(thirdLevelAllElements){
//         browser.driver.sleep(2000);
//         console.log("Count of Elements in Third Level "+thirdLevelAllCount);
//           console.log("List of Elements name in Third Level "+thirdLevelAllElements);
//          }); }); //thrid level
//         }); //scroll close
//     }); } //second level

// });
 }); } //first level
  

}); };


this.scrollIntoClick=function(elemLocator) {
    var elmName = commonUtil.getWebElement(currentPage,'clearFilter'); 
    logger.info("scrollIntoClick:To click on the element getting into scroll view");
     browser.executeScript(function(elemLocator) {
    elemLocator.scrollIntoView(false);
    }, elemLocator.getWebElement());
    return elemLocator.click();
    };

this.escapeClick=function(){
    browser.driver.sleep(3000);
    browser.actions().sendKeys(protractor.Key.ESCAPE).perform();
  return  console.log("Come out of the Dropdown");
};

 this.alignTab=function(){
  return  TestHelper.elementToBeClickable(currentPage,"alignLeftTab");
 };

this.clickonarrow=function(){
    var clickElement=element(by.xpath("//mat-select[@placeholder='HIDE METRIC']//div[@class='mat-select-arrow-wrapper']"));
   promiseUtil.click(clickElement);
 return   browser.actions().sendKeys(protractor.Key.ENTER).perform();
};
  
this.clickoutside=function(){
    var clickout=element(by.xpath("//div[@class='cdk-overlay-container']"));
    promiseUtil.click(clickout);
    console.log("cliked outside");
};

 this.scrollIntoClick = function(elemLocator) {
    // var elmName = lem.findElement(currentPage,"Scroll"); 
    var elmName=element(by.xpath("//tr[@class='header']//th[4]"));
    var retval = lem.scrollIntoClick(elmName);   
    logger.info("scrollIntoClick:To click on the element getting into scroll view");
  
    return retval.click();
}; 
    // var retval = commonUtil.scrollIntoClick(elmName);  
    // var elmName = commonUtil.getWebElement(currentPage,'clearFilter'); 
      //  browser.executeScript(function(elemLocator) {
    // elemLocator.scrollIntoView(false);
    // }, elemLocator.getWebElement());
    
}
module.exports=new checkLoopValue();