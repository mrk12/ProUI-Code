/**
 * Created by 212629051 on 12/21/17.
 */
exports.config = {

    // ---- While testing locally
    sauceUser: null,
    sauceKey: null,
    sauceSeleniumAddress: null,
    directConnect: true,
    firefoxPath: null,

    // ---------------------------------------------------------------------------
    // ----- What tests to run ---------------------------------------------------
    // ---------------------------------------------------------------------------

    specs: [],
    // Patterns to exclude.
    exclude: [],

    // Organize spec files into suites. To run specific suite, --suite=<name of suite>
    suites: {
        login:// ['../Features/TC208041_E2EWorkflow.feature'] ,
           // ['../Features/MI_RBI581_E2EWorkFlow.feature'],
    ['../Features/TC001_ProductQuality.feature'],
    // ['../Features/TC_PQ001.feature'],
    // ['../Features/TC_PQ002.feature'],
    // ['../Features/TC_PQ003.feature'],
    // ['../Features/TC_PQ004.feature'],
    

    },

    // Hooks running in the background
    plugins: [{
        path: '../../../node_modules/proui-utils/Compressed_Utils/GeneralHook.js',
    }],

    capabilities: {
        browserName: 'chrome',
        /*proxy: {
         proxyType: 'manual',
         httpProxy: 'sjc1intproxy01.crd.ge.com:8080',
         sslProxy: 'sjc1intproxy01.crd.ge.com:8080'
         },*/
        count: 1,
        shardTestFiles: false,
        maxInstances: 1,
        'chromeOptions': {
            args: ['--no-sandbox', '--test-type=browser', '--start-maximized'],
            // Set download path and avoid prompting for download even though
            // this is already the default on Chrome but for completeness
            prefs: {
                'download': {
                    'prompt_for_download': false,
                    'directory_upgrade': true,
                    'default_directory': 'C:/Jenkins/sharedspace/public/test/e2e-reboot/steps/'
                }
            }
        }
    },


    maxSessions: -1,

    allScriptsTimeout: 250000,

    // How long to wait for a page to load.
    getPageTimeout: 650000,

    // Before launching the application
    beforeLaunch: function () {
    },

    // Browser parameters for feature files.
    params: {

        login: {

          //Dev Envi
          "baseUrl":"https://g11892-2.cloud.health.ge.com/ebsc",
          // QA Envi
        //   "baseUrl":"https://g13018-1.cloud.health.ge.com/ebsc",
              "username": "502804174",
              "password":  "Adler@2018@a",
            //       "database": " "

        }
    },

    // Application is launched but before it starts executing
    onPrepare: function () {

        // Create reports folder if it does not exist
        var folderName = (new Date()).toString().split(' ').splice(1, 4).join(' ');
        var mkdirp = require('mkdirp');
        var reportsPath = "./Reports/";

        mkdirp(reportsPath, function (err) {
            if (err) {
                console.error(err);
            } else {
            }
        });

        browser.manage().deleteAllCookies();
        browser.manage().timeouts().pageLoadTimeout(60000);

        chai = require('chai');
        expect = chai.expect;
        path = require('path');
        Cucumber = require('cucumber');
        fs = require('fs');
        

        // This is declaration for Object Manager
        objectManagerFile = require('proui-utils').ObjectManager;
        objectManager = new objectManagerFile();

        Logger = require('ProUI-Utils').Logger;
    },


    // A callback function called once tests are finished
    onComplete: function () {
    },

    // A callback function called once tests are cleaning up
    onCleanUp: function (exitCode) {

    },

    // A callback function after tests are launched
    afterLaunch: function () {

    },
    resultJsonOutputFile: null,

    // If true, protractor will restart the browser between each test.
    // CAUTION: This will cause your tests to slow down drastically.
    restartBrowserBetweenTests: false,

    // Custom framework in this case cucumber
    framework: 'custom',
    frameworkPath: require.resolve('protractor-cucumber-framework'),
    cucumberOpts: {

        // define your step definitions in this file
        require: [
            //  '../../../../MI/ProUI/Test_Modules/MI_RBI_PRD_ANALYSYS/StepDefn'
            '../../../node_modules/proui-utils/Compressed_Utils/Reporter.js',
            // '../../Test_Modules/SmokeTest/*'
           
            // '../StepDefn/TC208041_E2EWorkFlow-StpDefn.js'
          
            '../StepDefinition/*',



            // '../../Test_Modules/LCC/step_definitions/newanalysis-step-def.js'
        ],

        //format: 'pretty'
    }
};
