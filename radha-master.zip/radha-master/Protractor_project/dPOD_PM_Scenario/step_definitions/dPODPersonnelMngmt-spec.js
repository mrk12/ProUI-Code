var currentPage = 'taskMgmtPage';
var text;
module.exports = function() {

      this.Given(/^I login to (.*)$/, function (env, callback) {
		env = browser.params.login.url;
          taskMgmtPage.getLogin(env).then(function (completed) {
			browser.ignoreSynchronization = true;
			assert.isTrue(completed, 'Not login page');
			callback();
		});
	});

    this.Given(/^I am into (.*) env$/, function (env,callback) {
        browser.executeScript('window.open()').then(function () {
            browser.getAllWindowHandles().then(function (handles) {
                var secondWindow = handles[1];
                browser.switchTo().window(secondWindow).then(function () {
                    console.log("Email is :"+env);
                     browser.driver.get(env);
                    browser.ignoreSynchronization = true;
                    callback();
                });
            });
        });
    });

    this.Given(/^I am login into (.*) env$/, function (env,callback) {
        browser.executeScript('window.open()').then(function () {
            browser.getAllWindowHandles().then(function (handles) {
                var secondWindow = handles[1];
                browser.switchTo().window(secondWindow).then(function () {
                    env = browser.params.login.url;
                    taskMgmtPage.getLogin(env).then(function (completed) {
                        browser.ignoreSynchronization = true;
                        assert.isTrue(completed, 'Not login page');
                        callback();
                    });
                });
            });
        });
    });

	this.When(/^I authenticate with valid (.*) and (.*)$/, function (userName, password, callback) {
		userName = browser.params.login.username;
		password = browser.params.login.password;
        taskMgmtPage.setName(userName).then(function () {
            taskMgmtPage.setPassword(password).then(function () {
                taskMgmtPage.clickLogin().then(function () {
					callback();
				});
			});
		});
	});

    this.When(/^I can login with (.*) and (.*)$/, function (userName, password, callback) {
        userName = browser.params.login.username1;
        password = browser.params.login.password1;
        taskMgmtPage.setName(userName).then(function () {
            taskMgmtPage.setPassword(password).then(function () {
                taskMgmtPage.clickLogin().then(function () {
                    callback();
                });
            });
        });
    });

    this.When(/^I login with (.*) and (.*) for single site$/, function (userName, password, callback) {
        userName = browser.params.login.username2;
        password = browser.params.login.password2;
        taskMgmtPage.setName(userName).then(function () {
            taskMgmtPage.setPassword(password).then(function () {
                taskMgmtPage.clickLogin().then(function () {
                    callback();
                });
            });
        });
    });

    this.Then(/^I can validate personnel management and click on it$/, function (callback) {
        taskMgmtPage.validatePM().then(function () {
            callback();
        });
    });

    this.Then(/^I can validate Task Management Tab in dPOD and click on it$/, function (callback) {
        taskMgmtPage.validateTaskPage().then(function () {
            callback();
        });
    });

    this.Given(/^I can click on add new personnel$/, function (callback) {
        taskMgmtPage.addPersonnel().then(function(){
            callback();
		});
	});

    this.Then(/^I can add email in the detail filed$/, function (callback) {
        taskMgmtPage.addEmailId().then(function(){
            callback();
        });
    });


    this.Then(/^I can add (.*) in userId of the detail field$/, function (userId,callback) {
        taskMgmtPage.addSSO(userId).then(function(){
            callback();
        });
    });

    this.Then(/^I can add (.*) in firstName of the detail field$/, function (firstName,callback) {
        taskMgmtPage.addFName(firstName).then(function(){
            callback();
        });
    });

    this.Then(/^I can add (.*) in lastName of the detail field$/, function (lastName,callback) {
        taskMgmtPage.addLName(lastName).then(function () {
            callback();
        });
    });

    this.Then(/^I can add (.*) in nickName of the detail field$/, function (nickName,callback) {
        taskMgmtPage.addNName(nickName).then(function () {
            callback();
        });
    });

    this.Then(/^I can add (.*) in mobileNumber of the detail field$/, function (mobileNumber,callback) {
        taskMgmtPage.addMNumber(mobileNumber).then(function () {
            callback();
        });
    });

    this.Then(/^I can add (.*) in officeNumber of the detail field$/, function (officeNumber,callback) {
        taskMgmtPage.addONumber(officeNumber).then(function () {
            callback();
        });
    });

    this.Then(/^I can click on the dropDown and select the (.*) role$/, function (role,callback) {
        taskMgmtPage.addJobTitle(role).then(function(){
            callback();
        });
    });

    this.Then(/^I can add the user for different (.*)$/, function (site,callback) {
        taskMgmtPage.addSite(site).then(function(){
            callback();
        });
    });

    this.Then(/^I can click in the cancel button$/, function (callback) {
		taskMgmtPage.clickCancel().then(function() {
            callback();
        });
    });

    this.Given(/^I can able to click on the first row from left nav$/, function (callback) {
        taskMgmtPage.clickFirstRow().then(function() {
            callback();
        });
    });

    this.When(/^I am able to store the firstName from the long form$/, function (callback) {
        taskMgmtPage.storeFirstNameLForm().then(function() {
            callback();
        });
    });

    this.When(/^I am able to store the lastName from the long form$/, function (callback) {
        taskMgmtPage.storeLastNameLForm().then(function() {
            callback();
        });
    });

    this.When(/^I am able to store the role from the long form$/, function (callback) {
        taskMgmtPage.storeRoleLForm().then(function() {
            callback();
        });
    });

    this.When(/^I am able to store the number form the long form$/, function (callback) {
        taskMgmtPage.storeMobileLForm().then(function() {
            callback();
        });
    });

    this.When(/^I am able to get the full name from the short$/, function (callback) {
        taskMgmtPage.validateFullName().then(function() {
            callback();
        });
    });

    this.When(/^I am able to validate the job title from the short form$/, function (callback) {
        taskMgmtPage.validateRole().then(function() {
            callback();
        });
    });

    this.When(/^I am able to validate the mobile number from the short form$/, function (callback) {
        taskMgmtPage.validateMobileNumber().then(function () {
            callback();
        });
    });

    this.Then(/^I am able to logout$/, function (callback) {
        browser.sleep(5000);
        element(by.xpath('//*[@id="pxh-user-menu"]/a/div[2]')).isPresent().then(function () {
            browser.sleep(2000);
            element(by.xpath('//*[@id="pxh-user-menu"]/a/div[2]')).click().then(function () {
                element(by.css('[title="Log Out"]')).isPresent().then(function () {
                    taskMgmtPage.logOut().then(function () {
                        browser.driver.isElementPresent(by.xpath('//*[@value="Sign in"]'));
                        callback();
                    });
                });
            });
        });
    });

    this.Given(/^I can validate edit icon in left nav$/, function (callback) {
        taskMgmtPage.validateEditIcon().then(function () {
            callback();
        });
    });

    this.Given(/^I can click on the edit option$/, function (callback) {
        taskMgmtPage.clickEditIcon().then(function () {
            callback();
        });
    });

    this.Given(/^I can validate emailTab is not editable$/, function (callback) {
        taskMgmtPage.emailDisable().then(function () {
			callback();
        });
    });

    this.Given(/^I can validate userId is not editable$/, function (callback) {
        taskMgmtPage.userIdDisable().then(function () {
            callback();
        });
    });

    this.Given(/^I can validate userId is not editable for existing user$/, function (callback) {
        taskMgmtPage.validateUserId().then(function () {
            callback();
        });
    });

    this.Given(/^I can validate edit icon in right nav$/, function (callback) {
        taskMgmtPage.rightEditIcon().then(function () {
            callback();
        });
    });

    this.Given(/^I can click on the edit option on right side$/, function (callback) {
        taskMgmtPage.rightClkEditIcon().then(function () {
            callback();
        });
    });

    this.Then(/^I can click on delete Icon which is present in right side$/, function (callback) {
        taskMgmtPage.rightClkDeleteIcon().then(function () {
            callback();
        });
    });

    this.Given(/^I am able to validate the data is based on the sorted by first name$/, function (callback) {
        taskMgmtPage.validateSortFName(callback);
	});

    this.When(/^I can click on sort$/, function (callback) {
        taskMgmtPage.clickSort().then(function () {
            callback();
        });
    });

    this.When(/^I can sort firstName$/, function (callback) {
        taskMgmtPage.selectFName().then(function () {
            callback();
        });
    });

    this.When(/^I can click on sortText$/, function (callback) {
        taskMgmtPage.selectSortText().then(function () {
            callback();
        });
    });

    this.When(/^I am able to validate the data is based on the descending by first name$/, function (callback) {
        taskMgmtPage.validateDescOrder(callback);
    });

    this.When(/^I can sort lastName$/, function (callback) {
        taskMgmtPage.selectLName().then(function () {
            callback();
        });
    });

    this.When(/^I am able to validate the data is based on the sorted by last name$/, function (callback) {
        taskMgmtPage.validateSortLName(callback);
    });

    this.When(/^I am able to validate the data is based on the descending by last name$/, function (callback) {
        taskMgmtPage.descOrderLName(callback);
    });

    this.When(/^I can sort jobTitle$/, function (callback) {
        taskMgmtPage.selectJTitle().then(function () {
            callback();
        });
    });

    this.When(/^I am able to validate the data is based on the sorted by job title$/, function (callback) {
        taskMgmtPage.validateSortJTitle(callback);
    });

    this.When(/^I am able to validate the data is based on the descending by job title$/, function (callback) {
        taskMgmtPage.descJTitle(callback);
    });

    this.When(/^I can remove sort$/, function (callback) {
        taskMgmtPage.removeSort().then(function () {
            callback();
        });
    });


    this.Given(/^I am able to validate text present for pagination$/, function (callback) {
        taskMgmtPage.textPagiValid().then(function () {
            callback();
        });
    });

    this.Given(/^I can click on the dropDown and select records (.*)$/, function (records,callback) {
        taskMgmtPage.validateRecords(records).then(function () {
            callback();
        });
    });

    this.Given(/^I am able to count number of records present in to list$/, function (callback) {
        taskMgmtPage.countRecords().then(function () {
            callback();
        });
    });

    this.Given(/^I am able to validate message when there is no data$/, function (callback) {
       taskMgmtPage.validateNoDataMsg().then(function () {
		   callback();
       });
    });

    this.Given(/^I am able to validate if there is message present$/, function (callback) {
        taskMgmtPage.validateMsg(callback);
    });

    this.Given(/^I am able to validate add personnel is present$/, function (callback) {
        taskMgmtPage.validateAddPer().then(function () {
            callback();
        });
    });

    this.Given(/^I am able to validate cancel and save button is disable$/, function (callback) {
        taskMgmtPage.validateButton().then(function () {
            callback();
        });
    });

    this.Given(/^I am able to validate Save button is disabled and Cancel button is enabled$/, function (callback) {
        taskMgmtPage.validateCancelAndSaveButton().then(function () {
            callback();
        });
    });

    this.Then(/^I can click on the save button$/, function (callback) {
        taskMgmtPage.clkSave().then(function () {
            callback();
        });
    });

    this.Then(/^I am able to validate success message$/, function (callback) {
        var message='Person has been successfully added. Please reload the Personnel Management page to see the changes reflected.';
        browser.driver.sleep(2000);
             cem.findElement(currentPage, 'successMessage').getText().then(function (value) {
                console.log("Message is :" + value);
               // assert.equal(message, value);
                callback();
            // });
        });
    });

    this.Given(/^I am able to validate update message$/, function (callback) {
        var message = "Personnel details updated successfully. Please reload the Personnel Management page to see the changes reflected.";
            browser.driver.sleep(2000);
            cem.findElement(currentPage, 'successMessage').getText().then(function (value) {
                console.log("Message is :" + value);
                // assert.equal(message, value);
                callback();
            // });
        });
    });

    this.Then(/^I can validate requestAccess button$/, function (callback) {
        taskMgmtPage.requestAccess().then(function(){
            callback();
        });
    });

    this.Then(/^I can validate requestAccess button is not present$/, function (callback) {
        taskMgmtPage.requestAccessNP().then(function(){
            callback();
        });
    });

    this.Given(/^I can add email (.*) in the detail filed$/, function (email,callback) {
        taskMgmtPage.addEmail(email).then(function(){
            callback();
        });
    });

    this.Given(/^I am able to see the error message$/, function (callback) {
        taskMgmtPage.errorMessage().then(function(){
            callback();
        });
    });

    this.Given(/^I can click on the email and clear the field$/, function (callback) {
        taskMgmtPage.clearEField().then(function(){
            callback();
        });
    });

    this.Given(/^I am able to validate email is mandatory field$/, function (callback) {
        taskMgmtPage.validateEMand().then(function(){
            callback();
        });
    });

    this.Given(/^I can click on the firstName and clear the field$/, function (callback) {
        taskMgmtPage.clearFNameField().then(function(){
            callback();
        });
    });

    this.Given(/^I am able to validate firstName is mandatory field$/, function (callback) {
        taskMgmtPage.validateFMand().then(function(){
            callback();
        });
    });

    this.Given(/^I am able to see the error message for firstName$/, function (callback) {
        taskMgmtPage.errorFMessage().then(function () {
            callback();
        });
    });

    this.Given(/^I am able to validate error message for firstName$/, function (callback) {
        taskMgmtPage.errorMessageValidationFN().then(function () {
            callback();
        });
    });

    this.Given(/^I am not able to see the error message for firstName$/, function (callback) {
        taskMgmtPage.errorMessageNotPresentValidationFN().then(function () {
            callback();
        });
    });

    this.Given(/^I am not able to see the error message for lastName$/, function (callback) {
        taskMgmtPage.errorMessageNotPresentValidationLN().then(function () {
            callback();
        });
    });


    this.Given(/^I am able to validate error message for lastName$/, function (callback) {
        taskMgmtPage.errorMessageValidationLN().then(function () {
            callback();
        });
    });

    this.Given(/^I am able to validate lastName is mandatory field$/, function (callback) {
        taskMgmtPage.validateLMand().then(function(){
            callback();
        });
    });

    this.Given(/^I am able to see the error message for lastName$/, function (callback) {
        taskMgmtPage.errorLMessage().then(function () {
            callback();
        });
    });

    this.Given(/^I can click on the lastName and clear the field$/, function (callback) {
        taskMgmtPage.clearLNameField().then(function(){
            callback();
        });
    });

    this.Given(/^I can add exciting email in the detail filed$/, function (callback) {
        taskMgmtPage.addExcitingEmail().then(function(){
            callback();
        });
    });

    this.Given(/^I am able to validate assign site/, function (callback) {
        taskMgmtPage.validateAssignSite().then(function(){
            callback();
        });
    });

    this.Then(/^I can save the site name$/, function (callback) {
        taskMgmtPage.saveSiteName().then(function(){
            callback();
        });
    });

    this.Given(/^I can click on add contractor$/, function (callback) {
        taskMgmtPage.addContractor().then(function() {
            callback();
        });
    });

    this.Then(/^I can click on last contractor person$/, function (callback) {
        taskMgmtPage.selectLastContractor().then(function() {
            callback();
        });
    });

    this.When(/^I am able to drop the newly created contractor user into existing crew$/, function (callback) {
        taskMgmtPage.dropToFirstCrew().then(function() {
            callback();
        });
    });

    this.Then(/^I am able to select the edit option for contract$/, function (callback) {
        taskMgmtPage.selectEdit().then(function() {
            callback();
        });
    });

    this.Then(/^I can see SSO is disable$/, function (callback) {
        taskMgmtPage.ssoDisable().then(function() {
            callback();
        });
    });

    this.Then(/^I am able to drag and drop$/, function (callback) {
        taskMgmtPage.dragDrop().then(function() {
            callback();
        });
    });

    this.Then(/^I can click on the contractor that added$/, function (callback) {
        taskMgmtPage.lastCrew().then(function() {
            callback();
        });
    });

    this.When(/^I am able to save the contractor name$/, function (callback) {
        taskMgmtPage.saveCrewName().then(function() {
            callback();
        });
    });

    this.Then(/^I am able to see the status of the contractor$/, function (callback) {
        taskMgmtPage.workStatus().then(function () {
            callback();
        });
    });

    this.Given(/^I am able to edit (.*) in firstName field$/, function (firstName,callback) {
        taskMgmtPage.addFiName(firstName).then(function() {
            callback();
        });
    });

    this.Given(/^I am able to edit (.*) in lastName field$/, function (lastName,callback) {
        taskMgmtPage.addLaName(lastName).then(function() {
            callback();
        });
    });

    this.Given(/^I am able to edit (.*) in nickName field$/, function (nickName,callback) {
        taskMgmtPage.addNiName(nickName).then(function() {
            callback();
        });
    });

    this.Given(/^I am able to edit (.*) in initials field$/, function (initials,callback) {
        taskMgmtPage.addInitials(initials).then(function() {
            callback();
        });
    });

    this.Given(/^I am able to validate role is disabled$/, function (callback) {
        taskMgmtPage.disRole().then(function() {
            callback();
        });
    });

    this.Then(/^I am able to add (.*) in email field$/, function (email,callback) {
        taskMgmtPage.addEma(email).then(function() {
            callback();
        });
    });

    this.Then(/^I am able to add (.*) in phone field$/, function (phone,callback) {
        taskMgmtPage.addPhone(phone).then(function() {
            callback();
        });
    });

    this.Then(/^I can click on save$/, function (callback) {
        taskMgmtPage.clickSave().then(function() {
            callback();
        });
    });

    this.Given(/^I can change the status to on call$/, function (callback) {
        taskMgmtPage.onCall().then(function() {
            callback();
        });
    });

    this.Then(/^I am able to validate onCall symbol$/, function (callback) {
        taskMgmtPage.onCallSymbol().then(function() {
            callback();
        });
    });

    this.Given(/^I am able to validate error message$/, function (callback) {
        taskMgmtPage.errorMessageDpod().then(function() {
            callback();
        });
    });

    this.Given(/^I am able to validate search is present$/, function (callback) {
        taskMgmtPage.searchPresent().then(function () {
			callback();
        });
    });

    this.When(/^I am able to insert firstName (.*) and validate the list is present$/, function (firstName,callback) {
        taskMgmtPage.enterFName(firstName).then(function () {
            callback();
        });
    });

    this.When(/^I am able to validate (.*) firstName is present in the list$/, function (firstName,callback) {
        taskMgmtPage.validateFName(firstName).then(function () {
            callback();
        });
    });

    this.When(/^I am able to enter (.*) wrong name and able to validate (.*)$/, function (wrongName,message,callback) {
        taskMgmtPage.validateWName(wrongName).then(function () {
            taskMgmtPage.validateMessage(message).then(function () {
                callback();
            });
        });
    });

    this.When(/^I am able to insert lastName (.*) and validate the list is present$/, function (lastName,callback) {
        taskMgmtPage.enterLName(lastName).then(function () {
            callback();
        });
    });

    this.When(/^I am able to validate (.*) lastName is present in the list$/, function (lastName,callback) {
        taskMgmtPage.validateLName(lastName).then(function () {
            callback();
        });
    });

    this.Given(/^I am able to insert poneNumber (.*) and validate number of record$/, function (phoneNumber,callback) {
        taskMgmtPage.enterPNumber(phoneNumber).then(function () {
            callback();
        });
    });

    this.Given(/^I am able to validate (.*) poneNumber is present in the list$/, function (phoneNumber,callback) {
        taskMgmtPage.validatePNumber(phoneNumber).then(function () {
            callback();
        });
    });

    this.Given(/^I am able to enter (.*) wrong number and able to validate (.*)$/, function (wrongNumber,message,callback) {
        taskMgmtPage.validateWNumber(wrongNumber).then(function () {
            taskMgmtPage.validateMessage(message).then(function () {
                callback();
            });
        });
    });

    this.Given(/^I am able to select the delete option for contract$/, function (callback) {
        taskMgmtPage.selectDelete().then(function() {
            callback();
        });
    });

    this.Then(/^I am able to validate contractor is deleted$/, function (callback) {
        taskMgmtPage.validateCrewName().then(function() {
            callback();
        });
    });

    this.Then(/^I can validate crew count in the work plan section$/, function (callback) {
        taskMgmtPage.validateCrewCountWorkPlanSection().then(function() {
            callback();
        });
    });

    this.Then(/^I can validate if updated crew count is reflected in the work plan section$/, function (callback) {
        taskMgmtPage.validateUpdatedCrewCountWorkPlanSection().then(function() {
            callback();
        });
    });

    this.Given(/^I can do one click on the contractor that added$/, function (callback) {
        taskMgmtPage.performOneClick().then(function() {
            callback();
        });
    });

    this.Given(/^I can refresh page$/, function () {
        browser.sleep(3000);
       return browser.driver.navigate().refresh();
    });

    this.Given(/^User should able to select (.*) as site group$/, function (site,callback) {
        taskMgmtPage.selectSite(site).then(function() {
            callback();
        });
    });

    this.Given(/^User should able to select (.*) as site group only one site$/, function (site,callback) {
        taskMgmtPage.selectSite1(site).then(function() {
            callback();
        });
    });

    this.When(/^I am able to validate (.*) message for different site$/, function (message,callback) {
        taskMgmtPage.validateMessage(message).then(function () {
            callback();
        });
    });

    this.Given(/^I can validate edit icon is not present$/, function (callback) {
        taskMgmtPage.validateEditIconNP().then(function () {
            callback();
        });
    });

    this.Given(/^I can validate delete icon is not present$/, function (callback) {
        taskMgmtPage.validateDeleteIconNP().then(function () {
            callback();
        });
    });

    this.Given(/^I am able to validate edit icon is not present in right side$/, function (callback) {
        taskMgmtPage.validateEditIconRNP().then(function () {
            callback();
        });
    });

    this.Then(/^I can add random mobile number$/, function (callback) {
        taskMgmtPage.addRNumber().then(function () {
            callback();
        });
    });

    this.Given(/^I am able to insert saved phone number$/, function (callback) {
        taskMgmtPage.addSNumber().then(function () {
            callback();
        });
    });

    this.Given(/^I am able to insert saved email id into search box$/, function (callback) {
        taskMgmtPage.addExistingEmailId().then(function () {
            callback();
        });
    });

    this.Given(/^I am able to insert saved personnel name (.*) into search box$/, function (personnelName,callback) {
        taskMgmtPage.searchExistingPersonnel(personnelName).then(function () {
            callback();
        });
    });

    this.Given(/^I am able to insert saved email id$/, function (callback) {
        taskMgmtPage.addSEmail().then(function () {
            callback();
        });
    });

    this.Given(/^I can add the user for every site$/, function (callback) {
        taskMgmtPage.addAllSite().then(function () {
            callback();
        });
    });

    this.When(/^I can click multiple time$/, function (callback) {
        taskMgmtPage.clickRequestAccess(callback);
    });
    
    this.When(/^I can click requestAccess button$/, function (callback) {
        taskMgmtPage.clickRequestAccessOnce(callback);
    });

    this.When(/^I can click on download csv file$/, function (callback) {
        taskMgmtPage.clickCsv().then(function () {
            callback();
        });
    });

    this.Given(/^I am able to validate turbine status is present$/, function (callback) {
        taskMgmtPage.validateWidget().then(function () {
            callback();
        });
    });

    this.Given(/^I am able to read the number of turbine present$/, function (callback) {
        taskMgmtPage.numberOfTurbine().then(function () {
            callback();
        });
    });

    this.Given(/^I am able to read the status of faulted$/, function (callback) {
        taskMgmtPage.countFaultedStatus().then(function () {
            callback();
        });
    });

    this.Then(/^I am able to count stopped status$/, function (callback) {
        taskMgmtPage.countStoppedStatus().then(function () {
            callback();
        });
    });

    this.Given(/^I am able to count impacted status$/, function (callback) {
        taskMgmtPage.countImpactedStatus().then(function () {
            callback();
        });
    });

    this.Then(/^I am able to count netcom status$/, function (callback) {
        taskMgmtPage.countNetcomStatus().then(function () {
            callback();
        });
    });

    this.Then(/^I am able validate the count for all$/, function (callback) {
        taskMgmtPage.validateCount(callback);
    });

    this.Given(/^I can validate number of faulted turbine and see tooltip$/, function (callback) {
        taskMgmtPage.validateToolTipFaulted(callback);
    });

    this.Given(/^I can validate number of stopped turbine and see tooltip$/, function (callback) {
        taskMgmtPage.validateToolTipStopped(callback)
    });

    this.Given(/^I can validate number of impacted turbine and see tooltip$/, function (callback) {
        taskMgmtPage.validateToolTipImpacted(callback);
    });
    this.Given(/^I can validate number of netcom turbine and see tooltip$/, function (callback) {
        taskMgmtPage.validateToolTipNetcom(callback);
    });

    this.Given(/^I can validate weather widget$/, function (callback) {
        taskMgmtPage.validateWeaWidget().then(function () {
            callback();
        });
    });

    this.Given(/^I am able to validate the dark sky and click on it$/, function (callback) {
        taskMgmtPage.validateDarkSky().then(function () {
            callback();
        });
    });

    this.Then(/^I can switch control to child page$/, function (callback) {
        taskMgmtPage.childWindow(callback);
    });

    this.Given(/^I can get the URL for link$/, function (callback) {
        taskMgmtPage.urlRead(callback);
    });

    this.Given(/^I am get the Title of the page$/, function (callback) {
        taskMgmtPage.titleRead(callback);
    });

    this.Then(/^I can go to parent window$/, function (callback) {
        taskMgmtPage.parentWind(callback);
    });

    this.Given(/^I am able to count cases status$/, function (callback) {
        taskMgmtPage.countApmCasesStatus().then(function () {
            callback();
        });
    });

    this.Given(/^I can validate number of cases and see tooltip$/, function (callback) {
        taskMgmtPage.validateToolTipCases(callback);
    });

    this.Given(/^I can click on the first cases$/, function (callback) {
        taskMgmtPage.validateCase().then(function () {
            callback();
        });
    });

    this.Given(/^I am able to read the date$/, function (callback) {
        taskMgmtPage.validateRef().then(function () {
            callback();
        });
    });

    this.Given(/^I can validate sort is open$/, function (callback) {
        taskMgmtPage.validateSortList().then(function () {
            callback();
        });
    });

    this.Then(/^I can validate sort is closed$/, function (callback) {
        taskMgmtPage.notPresentSortList().then(function () {
            callback();
        });
    });

    this.Given(/^I can validate the error message for site$/, function (callback) {
       taskMgmtPage.validateErrorMsg().then(function(){
       	callback();
	   });
    });

    this.Given(/^I can validate the number of count and click on the records$/, function (callback) {
        taskMgmtPage.selectRecord().then(function() {
            callback();
        });
    });

    this.When(/^I am able to read the last record from the short$/, function (callback) {
        taskMgmtPage.selectLastRecord().then(function() {
            callback();
        });
    });

    this.When(/^I am able to validate the job title from the last record of short form$/, function (callback) {
        taskMgmtPage.selectLastRecordJob().then(function() {
            callback();
        });
    });

    this.When(/^I am able to validate the mobile number from the the last record of short form$/, function (callback) {
        taskMgmtPage.selectLastRecordMobile().then(function() {
            callback();
        });
    });


    this.Given(/^I can clear the search filter$/, function (callback) {
    	taskMgmtPage.searchClr().then(function () {
			callback();
        });
    });

    this.Then(/^I can validate popup is present and verify msg with buttons$/, function (callback) {
        taskMgmtPage.validatePopUp().then(function () {
            callback();
        });
    });

    this.Then(/^I can click on the cancel which is present in popUp$/, function (callback) {
        taskMgmtPage.clickPopCancel().then(function () {
            callback();
        });
    });

    this.Then(/^I can validate popup is present and click on yes$/, function (callback) {
        taskMgmtPage.clickPopSave().then(function () {
            callback();
        });
    });

    this.When(/^I can validate email$/, function (callback) {
        taskMgmtPage.validateEmail().then(function () {
            callback();
        });
    });

    this.When(/^I can validate firstName (.*) with the existing longform name$/, function (firstName,callback) {
        taskMgmtPage.retFName(firstName).then(function () {
            callback();
        });
    });

    this.Given(/I can validate lastName (.*) with the existing longform name$/, function (lastName,callback) {
        taskMgmtPage.retLName(lastName).then(function () {
        	callback();
        });
    });

    this.Given(/^I can store the email as well$/, function (callback) {
        taskMgmtPage.storeEmail().then(function () {
            callback();
        });
    });

    this.Given(/^I can click on the no which is present in popUp$/, function (callback) {
        taskMgmtPage.clickPopNo().then(function () {
            callback();
        });
    });

    this.Then(/^I can validate DPOD and click on it$/, function (callback) {
        taskMgmtPage.validateDpod().then(function () {
            callback();
        });
    });

    this.Then(/^I can see the popUp$/, function (callback) {
        taskMgmtPage.validateEXPopUp().then(function () {
            callback();
        });
    });

    this.Then(/^I am able to validate text for pop$/, function (callback) {
        taskMgmtPage.validatePopUpText().then(function () {
            callback();
        });
    });

    this.Then(/^I am able to validate text for pop for same section$/, function (callback) {
        taskMgmtPage.validateSecPopUpText().then(function () {
            callback();
        });
    });

    this.Then(/^I can see plan module is selected$/, function (callback) {
        taskMgmtPage.planModuleSel().then(function () {
            callback();
        });
    });

    this.Given(/^I am able to validate email id is different$/, function (callback) {
        taskMgmtPage.diffEmailId().then(function () {
            callback();
        });
    });

    this.Then(/^I can validate email with excising email$/, function (callback) {
        taskMgmtPage.validateEId().then(function () {
            callback();
        });
    });

    this.Given(/^I can click on the last page button$/, function (callback) {
        taskMgmtPage.lastPage().then(function () {
            callback();
        });
    });

    this.Given(/^I can validate data is present$/, function (callback) {
        taskMgmtPage.validateData().then(function () {
            callback();
        });
    });

    this.Then(/^I can scroll down/, function (callback) {
        element.all(by.xpath("//*[@class='search searchList pt']/li")).count().then(function (Count) {
            var elm = element.all(by.xpath("//*[@class='search searchList pt']/li")).first();
            browser.executeScript("arguments[0].scrollIntoView();", elm.getWebElement()).then(function () {
                var until = protractor.ExpectedConditions;
                browser.sleep(5000);
                browser.executeScript('window.scrollTo(0,1000);').then(function () {
                    console.log('Page Scroll Down');
                    callback();
                });
            });
        });
    });

    this.Given(/^I can validate edit personnel test is present$/, function (callback) {
        taskMgmtPage.validateEditText().then(function (){
           callback();
        });
    });

    this.Given(/^I can validate edit personnel test is not present$/, function (callback) {
        taskMgmtPage.validateEditNotPre().then(function (){
            callback();
        });
    });

    this.Given(/^I can click on the last record$/, function () {
        return element.all(by.xpath("//*[@class='search searchList pt']/li")).count().then(function (Count) {
            console.log("Count is :" +Count);
            browser.sleep(5000);
            return  element(by.xpath('//*[@class="search searchList pt"]/li'+'['+Count+']')).click();
        });
    });

    this.Given(/^I can click on the private computer$/, function (callback) {
        browser.waitForAngular();
       element(by.xpath("//*[@id='rdoPrvt']")).click();
       callback();

    });

    this.Given(/^I can click on sign in$/, function (callback) {
         browser.driver.isElementPresent(by.xpath(browser.params.login.btn));
         element(by.xpath(browser.params.login.btn)).click();
        callback();
    });

    this.Given(/^I can provide (.*)$/, function (userName) {
       return element(by.xpath("//*[@id='loginHeader']/div")).getText().then(function (value) {
        console.log(value);
        assert.equal(value,'Sign in');
        return element(by.xpath("//*[@name='loginfmt']")).isPresent().then(function(){
            return element(by.xpath("//*[@name='loginfmt']")).sendKeys(userName);
        });
       });
    });

    this.Given(/^I can click on Next$/, function () {
        browser.sleep(3000);
        return element(by.xpath("//*[@value='Next']")).isPresent().then(function () {
           return element(by.xpath("//*[@value='Next']")).click();
        });
    });

    this.When(/^I can click on search and put email (.*)$/, function (email) {
        browser.sleep(5000);
        browser.waitForAngular();
       return element(by.xpath("//*[@class='_n_l ms-fwt-sl ms-fcl-ns ms-fcl-np']")).isPresent().then(function () {
           browser.sleep(5000);
          element(by.xpath("//*[@class='o365cs-mfp-textboy o365cs-mfp-circular-small']")).isPresent();
           element(by.xpath("//*[@class='_n_l ms-fwt-sl ms-fcl-ns ms-fcl-np']")).click().then(function () {
                browser.sleep(5000);
                return element(by.xpath("//*[@class='_is_r']/input")).sendKeys(email+protractor.Key.ENTER);
            });
        });
    });

    this.When(/^I can click on select range$/, function () {
        browser.sleep(5000);
        return element(by.xpath("//*[@class='_is_5']//*[@title='Select range']/div/span")).click();

    });

    this.When(/^I can validate logo for outlook$/, function () {
        browser.sleep(3000);
        return element(by.xpath("//*[@id='loadingLogo']")).isPresent();
    });

    this.Given(/^I can validate site with date$/, function (callback) {
        var array1;
        var Site_Name;
        var Value;
        var currentDate;
        var dateFormat = require('dateformat');
        var XLSX = require('xlsx');
        var workbook = XLSX.readFile('../../Test_Doc.xlsx');
        var sheet_name_list = workbook.SheetNames;
        var xlData = XLSX.utils.sheet_to_json(workbook.Sheets[sheet_name_list]);
        console.log(xlData);

        var dateFormat = require('dateformat');
        var now = new Date();
        currentDate = dateFormat(now,"dd mmm yyyy");
        console.log("Today's date is " +currentDate);

        console.log("--------------Site Information --------");
        browser.sleep(3000);
          element.all(by.xpath("//*[@class='_lvv_V']/span")).getText().then(function (value) {
            var result = false;
            for (var i = 0; i < xlData.length; i++) {
                console.log("----------------------------------------");
                Site_Name = xlData[i].Site_Name;
                console.log("Site Name is : " + Site_Name);
                Value = xlData[i].Value;
                console.log("Value is : " + Value);
                console.log("----------------------------------------");
                var siteName = Site_Name + ' ' + Value + ' ' + currentDate;
                console.log("Site name is :" + siteName);
                console.log("Site Value from UI is :" + value);
                array1 = value;
                if (array1.includes(siteName)) {
                    console.log("****************************************");
                    console.log("****************************************");
                    console.log("Report is present for " + siteName);
                    console.log("****************************************");
                    console.log("****************************************");
                    result = true;
                } else {
                    console.log("****************************************");
                    console.log("****************************************");
                    console.log("Report of " + siteName + " is not present");
                    result;
                    console.log("****************************************");
                    console.log("****************************************");
                }
            }
            callback();
        });

    });
    
    this.When(/^I can click on the first email$/, function() {
        return element(by.xpath("//*[@id='primaryContainer']/div[4]/div/div[1]/div/div[4]/div[3]/div/div[2]/div/div/div/div[5]/div[3]/div[1]/div[3]/div[1]/div/div/div[2]/div[2]/div[2]")).click();
    });
    
    this.When(/^I can click on the second email$/, function() {
        return element(by.xpath("//*[@id='primaryContainer']/div[4]/div/div[1]/div/div[4]/div[3]/div/div[2]/div/div/div/div[5]/div[3]/div[1]/div[3]/div[1]/div/div/div[2]/div[3]/div[2]")).click();
    });
    
    this.Then(/^I can validate email text containing Requested by$/, function (callback) {
    	  browser.sleep(3000);
	      element.all(by.xpath("//*[@id='Item.MessageUniqueBody']/div/div/div")).getText().then(function (value) {
	    	    var emailText = value;
	    	    console.log(emailText);
	    	  	if (emailText.includes("Requested by")) {
	    	  		console.log("Requested by is present in email");
	            } else {
	                console.log("Requested by is not present in email");
	            }
	    	  	callback();
         });

    });

    this.When(/^I can click on search$/, function () {
        browser.sleep(3000);
        return element(by.xpath("//*[@class='_is_t ms-bgc-w ms-bcl-tp']/button/span")).click();
    });

    this.Then(/^I can validate recipients is present and click on it$/, function () {
        browser.waitForAngular();
        browser.sleep(20000);
        element(by.xpath("//*[@id='rptRecipient']")).isPresent();
        return element(by.xpath("//*[@id='rptRecipient']")).click();
    });

    this.Then(/^I can add (.*) in the recipients$/, function (email) {
        browser.sleep(3000);
        element.all(by.xpath("//*[@class='u-mb+ float--left u-mr+ label--inline ng-scope']//span[1]")).getText().then(function(value){
           console.log("Recipients are " +value);
           if(value.includes(email)){
               console.log("Email is Present");
           }else{
               return element(by.xpath("//*[@ng-model='tempNewEmailId']")).sendKeys(email+ protractor.Key.TAB) ;
           }
        });
       // return element(by.xpath("//*[@ng-model='tempNewEmailId']")).sendKeys(email+ protractor.Key.TAB) ;
    });

    this.Then(/^I can click on the back$/, function () {
        browser.sleep(3000);
        element(by.xpath("//*[text()='Back']")).isPresent();
        return element(by.xpath("//*[text()='Back']")).click();
    });

    this.Then(/^I can click on save button$/, function () {
        browser.sleep(3000);
        element(by.xpath("//*[text()='Save']")).isPresent();
        return element(by.xpath("//*[text()='Save']")).click();
    });

    this.Then(/^I can validate message$/, function () {
        var message ="Error in saving the report. Please try later!";
        browser.sleep(2000);
        return element(by.xpath("//*[@class='pxh-toast pxh-toast--animate-in']//*[@class='pxh-toast__text']")).getText().then(function (value) {
            if(message === value){
                return element(by.xpath("//*[text()='Save']")).click();
            }
        });
    });
    this.When(/^I should able to select (.*) as site group$/, function (site) {
        browser.driver.navigate().refresh();
        browser.waitForAngular();
        browser.driver.sleep(15000);
        cem.findElement(currentPage, 'siteGroupDropdwn').click();
        browser.driver.sleep(3000);
        return element(by.xpath('//*[@class="selected list-bare level style-scope px-context-browser"]//li//span[text()="' + site + '"]')).click();
    });

    this.Then(/^I am able to logout from DOPD$/, function () {
        element(by.xpath('//*[@id="pxh-user-menu"]/a/div[2]')).isPresent().then(function () {
            browser.driver.sleep(8000);
            element(by.xpath('//*[@id="pxh-user-menu"]/a/div[2]')).click().then(function () {
                element(by.css('[title="Log Out"]')).isPresent().then(function () {
                  return element(by.css('[title="Log Out"]')).click();
                });
            });
        });
    });

    this.When(/^I can click on preview$/, function () {
        browser.driver.sleep(8000);
        element(by.xpath("//*[text()='Preview']")).isPresent();
        browser.driver.sleep(8000);
        return element(by.xpath("//*[text()='Preview']")).click();
    });

    this.When(/^I can click on print to email$/, function () {
        browser.driver.sleep(20000);
        element(by.xpath("//*[text()='Print to email']")).isPresent();
        browser.driver.sleep(20000);
        return element(by.xpath("//*[text()='Print to email']")).click();
    });

    this.When(/^I can wait for spinner to complete$/, function () {
        browser.driver.sleep(20000);
        return !browser.isElementPresent(by.css('div.spinner.style-scope.px-spinner'));
    });

    this.When(/^I can click on the EOD$/, function () {
        browser.driver.sleep(8000);
        element(by.xpath("//*[@id='tab2']")).isPresent();
         return element(by.xpath("//*[@id='tab2']")).click();
    });

    this.Given(/^I can signout from outlook$/, function () {
        browser.driver.sleep(3000);
        element(by.xpath("//*[@class='o365cs-mfp-presenceButton ms-Icon--skypeCheck o365cs-mfp-skypeAvailable']")).isPresent();
        browser.driver.sleep(3000);
        element(by.xpath("//*[@class='o365cs-mfp-presenceButton ms-Icon--skypeCheck o365cs-mfp-skypeAvailable']")).click();
        browser.driver.sleep(3000);
        element(by.xpath("//*[@id='O365_SubLink_ShellSignout']//span[contains(text(),'Sign out')] ")).isPresent();
        browser.driver.sleep(3000);
        return element(by.xpath("//*[@id='O365_SubLink_ShellSignout']//span[contains(text(),'Sign out')] ")).click();
    });
    
    this.Given(/^I can signout from mail$/, function () {
        element(by.xpath("//*[@id='O365_MeFlexPane_ButtonID']/div[1]/div[2]")).click();
        return element(by.xpath("//*[@id='O365_SubLink_ShellSignout']")).click();
    });

    this.Then(/^I can remove rei dos ventos from list$/, function (callback) {
        taskMgmtPage.removeSite().then(function () {
            callback();
        });
    });

    this.Given(/^I can get the enabled and disabled value from list$/, function (callback) {
        taskMgmtPage.validateEnaDisabled(callback);
    });

    this.Given(/^I can add rei dos ventos from list$/, function (callback) {
        taskMgmtPage.addExtSite(callback);
    });


    this.Given(/^I can get list off all existing sites$/, function (callback) {
        taskMgmtPage.existingSite(callback);
    });

    this.Then(/^I should able to click on Task Management Tab in dPOD$/, function(callback) {
        taskMgmtPage.taskMangmntTab(callback)
    });

    this.Given(/^In task page I can scroll down$/, function (callback) {
        taskMgmtPage.scrollDownTask(callback);
    });

    this.Given(/^In turbine page I can scroll down$/, function (callback) {
        taskMgmtPage.scrollDownTurbine(callback);
    });

    this.Given(/^I can validate site and create button is present$/, function (callback) {
        taskMgmtPage.validateCreate(callback);
    });

    this.Given(/^I can click on the create$/, function (callback) {
        taskMgmtPage.clickCreate().then(function(){
            callback();
        });
    });

    this.Given(/^In page I can scroll down on left page$/, function (callback) {
        taskMgmtPage.dropDownLeft(callback);
    });

    this.Given(/^I can validate upper part is fixed on left nev$/, function (callback) {
        taskMgmtPage.validateUpper(callback);
    });

    this.Given(/^I can validate lower part is fixed on left nev$/, function (callback) {
        taskMgmtPage.validateLower(callback);
    });

    this.Given(/^I can click on the last record in dpod$/, function (callback) {
        taskMgmtPage.validateLastSel(callback);
    });

    this.Then(/^I can store list off all existing sites$/, function (callback) {
        taskMgmtPage.saveAllSite(callback);
    });

    this.Given(/^I can validate site is present$/, function (callback) {
        taskMgmtPage.validateSite(callback);
    });

    this.Given(/^I should able to click on Turbine Tab in dPOD$/, function (callback) {
        taskMgmtPage.turbineTab().then(function () {
            callback();
        });
    });

    this.Given(/^I can validate lower part is fixed on left nev in turbine$/, function (callback) {
        taskMgmtPage.validateLowerTurbine(callback);
    });

    this.Given(/^In turbine page I can scroll down on left page$/, function (callback) {
        taskMgmtPage.dropDownLeftTurbine(callback);
    });

    this.Given(/^I can click on turbine for the last record in dpod$/, function (callback) {
        taskMgmtPage.validateLastSelTur(callback);
    });

    this.Given(/^I can click on delete Icon$/, function (callback) {
        taskMgmtPage.clickDeleteIcon().then(function () {
            callback();
        });
    });

    this.Given(/^I can store site name$/, function (callback) {
       taskMgmtPage.storeSite().then(function(){
           callback();
       })
    });

    this.Given(/^I can validate site is not present from where person is deleted$/, function (callback) {
        taskMgmtPage.validateDeleteSite().then(function(){
            callback();
        })
    });

    this.Given(/^I can validate text for delete$/, function (callback) {
        taskMgmtPage.deleteText().then(function(){
            callback();
        })
    });

    this.Given(/^I can click on Yes in delete popUp$/, function (callback) {
        taskMgmtPage.deleteYes().then(function(){
            callback();
        })
    });

    this.Given(/^I can validate message about no record found$/, function (callback) {
        taskMgmtPage.validateNoRecord(callback);
    });

    this.Given(/^validate created user is present in the initial crew section$/, function (callback) {
        taskMgmtPage.initialCrewCount(callback);
    });

    this.Given(/^validate created user is not present in the crew section$/, function (callback) {
        taskMgmtPage.validateInCrew(callback);
    });

    this.Given(/^validate created user is present in the crew section$/, function (callback) {
        taskMgmtPage.validateCrewPre(callback);
    });

		this.Then(/^Verify user able to create new crew by drag and drop newly created personnel at new crew option$/, function(callback) {
				browser.waitForAngular();
			  browser.driver.sleep(10000);
		    TestHelperPO.isElementPresent(element(by.xpath('//*[@id="crewPopOver"]/span/center'))).then(function () {
		    	var src = element(by.xpath("//*[@id='crewSpan']//*[text()='ZZ']"));
		      var drop = element(by.xpath('//*[@id="crewPopOver"]/span/center'));
		      browser.actions().dragAndDrop(src,drop).mouseUp().perform();
					browser.waitForAngular();
		      callback();
		    });
		});

    this.Then(/^Verify created user is existing in DPOD crew$/, function(callback) {
        browser.waitForAngular();
        browser.driver.sleep(10000);
        TestHelperPO.isElementPresent(element(by.xpath("//*[@id='crewSpan']//*[text()='Z-']"))).then(function () {
          console.log("Added user is available in DPOD Crew");
          callback();
        });
    });

    this.Given(/^I can fetch the last crew name$/, function (callback) {
        taskMgmtPage.fetchCrewNameCrewsSection().then(function() {
            callback();
        });
    });

    this.Given(/^I validate that deleted personnel and crew are not existing$/, function (callback) {
        taskMgmtPage.validatePersonnelDeletion().then(function() {
            callback();
        });
    });

    this.Given(/^I can select (.*) first turbine and site$/, function (task,callback) {
        taskMgmtPage.selectTask(task).then(function(){
            callback();
        });
    });

    this.Given(/^I can give (.*) name as per todays date$/, function (task,callback) {
        taskMgmtPage.taskName(task).then(function(){
            callback();
        });
    });

    this.Given(/^I can right description$/, function (callback) {
        taskMgmtPage.selectDescription().then(function(){
            callback();
        });
    });

    this.Given(/^I can select category as others$/, function (callback) {
        taskMgmtPage.selectCategory().then(function(){
            callback();
        });
    });

    this.Given(/^I can select group as documentation$/, function (callback) {
        taskMgmtPage.selectDocumentation().then(function(){
            callback();
        });
    });

    this.Given(/^I can select section as work instruction$/, function (callback) {
        taskMgmtPage.selectSection().then(function(){
            callback();
        });
    });

    this.Given(/^I can click on plus sign to select turbine$/, function (callback) {
        taskMgmtPage.selectPlus().then(function(){
            callback();
        });
    });

    this.Then(/^I can save the first turbine number$/, function (callback) {
        taskMgmtPage.turbineValue().then(function() {
            callback();
        });
    });

    this.Then(/^I can select first checkBox value$/, function (callback) {
        taskMgmtPage.selectFirstValue().then(function(){
            callback();
        });
    });

    this.Then(/^I can click on save in add turbine page$/, function (callback) {
        taskMgmtPage.saveButtonTur().then(function() {
            callback();
        });
    });

    this.Then(/^I can select priority as LOW$/, function (callback) {
        taskMgmtPage.selectPriority().then(function() {
            callback();
        });
    });

    this.Then(/^I can select estimated tech and select number of tech$/, function (callback) {
        taskMgmtPage.selectTech().then(function() {
            callback();
        });
    });

    this.Then(/^I can click on due two times$/, function (callback) {
        taskMgmtPage.selectDue().then(function() {
            callback();
        });
    });

    this.Then(/^I can click on planned two times$/, function (callback) {
        taskMgmtPage.selectPlanned().then(function() {
            callback();
        });
    });

    this.Then(/^I can make estimated hours as four$/, function (callback) {
        taskMgmtPage.changeHour().then(function() {
            callback();
        });
    });

    this.Then(/^I can add none as parts need$/, function (callback) {
        taskMgmtPage.partsNeed().then(function() {
            callback();
        });
    });

    this.Then(/^I can add be careful as tech notes$/, function (callback) {
        taskMgmtPage.techNotes().then(function() {
            callback();
        });
    });

    this.Then(/^I can add do your best as POD\/EOD notes$/, function (callback) {
        taskMgmtPage.podEodNotes().then(function() {
            callback();
        });
    });

    this.Then(/^I can click on add button$/, function (callback) {
        taskMgmtPage.addTask().then(function() {
            callback();
        });
    });

    this.Then(/^I can click on Ok$/, function (callback) {
        taskMgmtPage.clickOK().then(function() {
            callback();
        });
    });

    this.Given(/^I can validate seach is present and click on it$/, function (callback) {
        taskMgmtPage.clickSearch().then(function() {
            callback();
        });
    });

    this.Given(/^I can send the value for task$/, function (callback) {
        taskMgmtPage.sendTaskValue().then(function() {
            callback();
        });
    });

    this.Given(/^I can validate value is present$/, function (callback) {
        taskMgmtPage.validateTaskValue().then(function() {
            callback();
        });
    });

    this.Given(/^I can validate turbine number is present$/, function (callback) {
        taskMgmtPage.validateTurbineNumber().then(function() {
            callback();
        });
    });

    this.Given(/^I can validate TULYN is present$/, function (callback) {
        taskMgmtPage.validateUniUser().then(function() {
            callback();
        });
    });

    this.Given(/^I can validate TULYN is not present$/, function (callback) {
        taskMgmtPage.validateUrNotPre().then(function() {
            callback();
        });
    });

    this.Given(/^I am able to drop that user into existing crew$/, function (callback) {
        taskMgmtPage.dropUniUser().then(function() {
            callback();
        });
    });

    this.Given(/^I can release that user from crew$/, function (callback) {
        taskMgmtPage.releaseUniUser().then(function() {
            callback();
        });
    });

    this.Given(/^I can validate crew is present otherwise add crew$/, function (callback) {
        taskMgmtPage.validateCrewPresent().then(function() {
            callback();
        });
    });

    this.Given(/^I can click on the plus sign to add task$/, function (callback) {
        taskMgmtPage.clickPlus().then(function() {
            callback();
        });
    });

    this.Then(/^I can save the value of the assigned contractor name$/, function (callback) {
        taskMgmtPage.getAssignContractor().then(function() {
            callback();
        });
    });

    this.Given(/^I am able to click on the newly created task name$/, function (callback) {
        taskMgmtPage.clkSavedTaskName().then(function() {
            callback();
        });
    });

    this.Given(/^I am able to mark as completed task$/, function (callback) {
        taskMgmtPage.completedTask().then(function() {
            callback();
        });
    });

    this.Given(/^I can select duration and send the notes$/, function (callback) {
        taskMgmtPage.addDurationNote().then(function(){
            callback();
        });
    });

    this.Given(/^I can click on the done button$/, function (callback) {
        taskMgmtPage.clickDone().then(function(){
            callback();
        });
    });

    this.Given(/^In DPOD scroll down up to save button$/, function (callback) {
        taskMgmtPage.dPODScroll().then(function(){
            callback();
        });
    });

    this.Given(/^I can validate the search and send the trubine name$/, function (callback) {
        taskMgmtPage.sendTurbineName().then(function(){
            callback();
        });
    });

    this.Given(/^I can validate date$/, function (callback) {
        taskMgmtPage.validateTableDate().then(function(){
            callback();
        });
    });

    this.Given(/^I am able to validate the crew name$/, function (callback) {
        taskMgmtPage.ableToValidateCrew().then(function(){
            callback();
        });
    });

    this.Given(/^I can validate task title$/, function (callback) {
        taskMgmtPage.validateTaskTitle().then(function(){
            callback();
        });
    });

    this.Given(/^I am able to validate the crew name is not present into completed task$/, function (callback) {
        taskMgmtPage.CrewNotPresent().then(function(){
            callback();
        });
    });

    this.Given(/^I can validate with the previous data$/, function (callback) {
        taskMgmtPage.assignContractorSecRow().then(function() {
            callback();
        });
    });

    this.Given(/^I can delete all crew from site$/, function (callback) {
        taskMgmtPage.deleteCrew().then(function() {
            callback();
        });
    });

    this.Given(/^I can see context browser is present after scrolling$/, function (callback) {
        taskMgmtPage.contextBrowserValidation().then(function(){
            callback();
        });
    });

    this.Given(/^I can validate record per page is present$/, function (callback) {
        taskMgmtPage.recordValidation().then(function(){
            callback();
        });
    });

    this.Then(/^I can see context browser is present after scrolling up$/, function (callback) {
        taskMgmtPage.scrollUp().then(function() {
            callback();
        });
    });

    this.Then(/^I can validate add new personnel is present$/, function (callback) {
        taskMgmtPage.addNewPersonnel().then(function() {
            callback();
        });
    });

    this.Given(/^I can validate the site name with the context browser in POD$/, function (callback) {
        taskMgmtPage.validateContext().then(function() {
            callback();
        });
    });

    this.Given(/^I can click on the plan module and validate context browser$/, function (callback) {
        taskMgmtPage.validatePlanContext().then(function() {
            callback();
        });
    });

    this.Given(/^I can click on the task module and validate context browser$/, function (callback) {
        taskMgmtPage.validateTaskContext().then(function() {
            callback();
        });
    });

    this.Given(/^I can click on the turbine module and validate context browser$/, function (callback) {
        taskMgmtPage.validateTurbineContext().then(function() {
            callback();
        });
    });

    this.Given(/^I can click on the reports module and validate context browser$/, function (callback) {
        taskMgmtPage.validateReportContext().then(function() {
            callback();
        });
    });

    this.Given(/^I can get the list of sites from PM$/, function (callback) {
        taskMgmtPage.pmSiteList().then(function() {
            callback();
        });
    });

    this.Given(/^I can get the list of sites from DPOD$/, function (callback) {
        taskMgmtPage.dPODSiteList().then(function() {
            callback();
        });
    });

    this.Given(/^I can validate list of PM and DPOD for available sites$/, function (callback) {
        taskMgmtPage.validationSites(callback);
    });

    this.Given(/^I can click on the PM and validate context browser$/, function (callback) {
        taskMgmtPage.pmSiteValidation().then(function() {
            callback();
        });
    });

    this.When(/^I can click on the plan module$/, function (callback) {
        taskMgmtPage.planModule().then(function() {
            callback();
        });
    });

    this.Given(/^I can validate the URL$/, function (callback) {
        taskMgmtPage.validateUrl(callback);
    });

};