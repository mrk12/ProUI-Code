var currentPage = 'taskMgmtPage';
module.exports = function() {

	this.Then(/^Verify user is able to view the Report Module tab$/, function(callback) {
        taskMgmtPage.waitForreportsTab().then(function () {
                         callback();
		});
	});
	this.Then(/^I should able to click on Reports Tab$/, function(callback) {
        taskMgmtPage.reportsTab().then(function () {
		console.log("User is able to navigate into Report page");
                         callback();
		});
	});
       this.Then(/^Verify User able to click on Performance widget disable button$/, function(callback) {
        taskMgmtPage.reportsPerformanceBtn().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify User able to click on Site Contacts disable button$/, function(callback) {
        taskMgmtPage.reportsSiteContractsBtn().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify User able to disable the task under Turbines Operating in Reduced Status$/, function(callback) {
        taskMgmtPage.turbineInReducedTask().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify User able to click on Save button$/, function(callback) {
        taskMgmtPage.reportsSaveBtn().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify User able to click on Print preview button$/, function(callback) {
        taskMgmtPage.reportsPreviewBtn().then(function () {
                         callback();
		});
	});
      // US142684:Reports Page - Drag and Drop Tasks/ Turbines
      this.Then(/^Click on Reports Tab$/, function(callback) {
        taskMgmtPage.reportsTab().then(function () {
                         callback();
		});
	});

    this.Then(/^I should able to do drag and drop for a Task$/, function(callback) {
	TestHelperPO.isElementPresent(element(by.xpath('//*[@id="parentDivPlanned"]/div[2]/div/table/tbody/tr[2]'))).then(function () {
                var src = element(by.xpath('//*[@id="parentDivPlanned"]/div[2]/div/table/tbody/tr[2]'));
                var drop = element(by.xpath('//*[@id="parentDiv1"]/div[2]/div/table/tbody/tr[71]'));
		browser.actions().dragAndDrop(src,drop).mouseUp().perform();
                            callback();
			         });
               });
     this.Then(/^I should able to do drag and drop for a Turbine$/, function(callback) {
	  TestHelperPO.isElementPresent(element(by.xpath('//*[@id="parentDivPlanned"]/div[2]/div/table/tbody/tr[3]'))).then(function () {
                var src = element(by.xpath('//*[@id="parentDivPlanned"]/div[2]/div/table/tbody/tr[3]'));
                var drop = element(by.xpath('//*[@id="parentDiv1"]/div[2]/div/table/tbody/tr[71]'));
		browser.actions().dragAndDrop(src,drop).mouseUp().perform();
                            callback();
			        });
               });
	       // US142529: Reports Page: Display Assets with Planned Maintenance
   this.Then(/^Verify user able to click on Reports Tab$/, function(callback) {
        taskMgmtPage.reportsTab().then(function () {
                         callback();
		});
	});
  this.Then(/^Verify user is able to view the Planned Maintenance Section$/, function(callback) {
        taskMgmtPage.reportsInPlnnedMntTab().then(function (completed) {
			console.log("Here is the Report name: "+ completed);
                         callback();
		});
	});
	this.Then(/^Verify user is able to view the Turbine Name in Planned Maintenance Section$/, function(callback) {
        taskMgmtPage.turbineInPlnnedMnt().then(function (completed) {
			console.log("Here is the Turbine name in Reports page: "+ completed);
                         callback();
		});
	});
	this.Then(/^Verify user is able to view the Task Name in Planned Maintenance Section$/, function(callback) {
        taskMgmtPage.taskInPlnnedMnt().then(function (completed) {
			console.log("Here is the Task name in Reports page: "+ completed);
                         callback();
		});
	});
	this.Then(/^Verify user is able to View site Name in Weather widget$/, function(callback) {
        taskMgmtPage.reportWeatherDetails().then(function (completed) {
			console.log("Country name: "+ completed);
                         callback();
		});
	});

	this.Then(/^Verify user is able to View Date of the Weather details$/, function(callback) {
        taskMgmtPage.reportWeatherDate().then(function (completed) {
			console.log("Date: "+ completed);
                         callback();
		});
	});
	this.Then(/^Verify user is able to View sky of the Weather details$/, function(callback) {
        taskMgmtPage.reportWeatherSky().then(function (completed) {
			console.log("Sky: "+ completed);
                         callback();
		});
	});
	this.Then(/^Verify user is able to View Wind of the Weather details$/, function(callback) {
        taskMgmtPage.reportWeatherWind().then(function (completed) {
			console.log("Wind: "+ completed);
                         callback();
		});
	});
	this.Then(/^Verify user is able to View Wind direction details$/, function(callback) {
        taskMgmtPage.reportWeatherWindDirection().then(function (completed) {
			console.log("Wind direction: "+ completed);
                         callback();
		});
	});
	//Adding turbine to report from Turbine Status Widget
	 this.Then(/^User should able to click on Task Management Tab$/, function(callback) {
        taskMgmtPage.taskMangmntTab().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to see Task Management Tab$/, function(callback) {
        taskMgmtPage.isTaskMangmntTabVisibile().then(function () {
                         callback();
		});
	});
     this.Then(/^User should see Create button available$/, function(callback) {
        taskMgmtPage.waitForcreateButton().then(function () {
                         callback();
		});
	});
	this.Then(/^User should select the Priority type for the Turbine$/, function(callback) {
        taskMgmtPage.priorityDropdown().then(function () {
                         callback();
		});
	});
	this.Then(/^User should click on turbine select icon$/, function(callback) {
        taskMgmtPage.turbinesIcon().then(function () {
                         callback();
		});
	});
	this.Then(/^User should select turbine1$/, function(callback) {
        taskMgmtPage.turbines114().then(function () {

                         callback();
		});
	});
	this.Then(/^User should select turbine2$/, function(callback) {
        taskMgmtPage.turbines141().then(function () {

                         callback();
		});
	});
	this.Then(/^User should click on turbine Save button$/, function(callback) {
        taskMgmtPage.turbinesSelectionSaveBtn().then(function () {
                         callback();
		});
	});
	this.Then(/^User should select the Estimated Techs for the task$/, function(callback) {
        taskMgmtPage.estimatedTechsDropdown().then(function () {
                         callback();
		});
	});
	this.When(/^User should click on Due date button for the task$/, function(callback) {
        taskMgmtPage.dueDateBtn().then(function () {
                         callback();
		});
	});
	this.Then(/^User should select the Due date for the task$/, function(callback) {
        taskMgmtPage.dueDateSelection().then(function () {
                         callback();
		});
	});
	this.Then(/^User should enter the Parts needed text for the task$/, function(callback) {
        taskMgmtPage.partsNeededTxtField().then(function () {
                         callback();
		});
	});
	this.Then(/^User should click on Add button for creating the task$/, function(callback) {
        taskMgmtPage.clickAddBtn().then(function () {
                         callback();
		});
	});
	this.Then(/^User should click on Reports Tab$/, function(callback) {
        taskMgmtPage.reportsTab().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to click on End of the Plan tab$/, function(callback) {
        taskMgmtPage.reportEODTab().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to click on Add tower button in turbine Operating section$/, function(callback) {
        taskMgmtPage.reportTORSAddTower().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to wait for Add tower button in turbine Operating section$/, function(callback) {
        taskMgmtPage.isreportTORSAddTowerVisibile().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to Add Turbine to report from turbine Operating section$/, function(callback) {
        taskMgmtPage.reportAddTaskDropdown().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to wait for Add tower button in Planned Maintenance section$/, function(callback) {
        taskMgmtPage.isreportPMAddTowerVisibile().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to click on Add tower button in Planned Maintenance section$/, function(callback) {
        taskMgmtPage.reportPMAddTower().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to Add a Task to report from Planned Maintenance section$/, function(callback) {
        taskMgmtPage.reportPMAddTaskDropdown().then(function () {
                         callback();
		});
	});
	this.Then(/^I should able to click on Save button$/, function(callback) {
        taskMgmtPage.reportsSaveBtn().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user able to View the Reports Archive button$/, function(callback) {
        taskMgmtPage.waitForreportArchiveBtn().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to click on Reports Archive button$/, function(callback) {
        taskMgmtPage.reportArchiveBtn().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to click on PDF Reports for EOD$/, function(callback) {
        taskMgmtPage.reportEODArchivePDFReport().then(function (Completed) {
		console.log("Report header: "+ Completed);
                         callback();
		});
	});
	this.Then(/^Verify user is able to click on Recipient button$/, function(callback) {
        taskMgmtPage.recipientBtn().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to add Recipient MailID in Email text field$/, function(callback) {
        taskMgmtPage.recipientMailidTxtFld().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to added Recipient MailID in POD reports$/, function(callback) {
        taskMgmtPage.recipientMailidEnter().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to delete added Recipient MailID in POD reports$/, function(callback) {
        taskMgmtPage.recipientDeleteBtn().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to come back to POD reports page$/, function(callback) {
        taskMgmtPage.recipientBackBtn().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to wait for notes in POD reports page$/, function(callback) {
        taskMgmtPage.waitForReportNotes().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to clear existing notes in POD reports page$/, function(callback) {
        taskMgmtPage.reportNotes().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to add notes in POD reports page$/, function(callback) {
        taskMgmtPage.reportNotes1().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to add notes in POD Notes section$/, function(callback) {
        taskMgmtPage.reportNotes2().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to add notes in POD Notes$/, function(callback) {
        taskMgmtPage.reportNotes3().then(function () {
                         callback();
		});
	});
	// Smoke Test cases
	this.Given(/^Verify user is able to see the Turbine Module Tab$/, function(callback) {
        taskMgmtPage.waitForturbineTab().then(function () {
                         callback();
		});
	});
	this.When(/^Verify user is able to navigates into Turbine Module page$/, function(callback) {
        taskMgmtPage.turbineTab().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to navigates into Task Management Tab$/, function(callback) {
        taskMgmtPage.taskMangmntTab().then(function () {
                         callback();
		});
	});
	this.When(/^Verify user is able to view Create button$/, function(callback) {
        taskMgmtPage.waitForcreateButton().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to navigates into Plan page$/, function(callback) {
        taskMgmtPage.planModule().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to Triggering Plan for the day$/, function(callback) {
        taskMgmtPage.planRunBtn().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to Save changes in Plan page$/, function(callback) {
        taskMgmtPage.planSaveBtn().then(function () {
                         callback();
		});
	});
     // Site Task creation
     this.Then(/^User should see Create button$/, function(callback) {
        taskMgmtPage.waitForcreateButton().then(function () {
                         callback();
		});
	});
	 this.Then(/^User click on the Create button$/, function(callback) {
        taskMgmtPage.createButton().then(function () {
                         callback();
		});
	});
	 this.Then(/^User should see the Add task page$/, function(callback) {
        taskMgmtPage.waitFortitleField().then(function (completed) {
                         callback();
		});
	});
	this.Then(/^User should select Site from the Task type dropdown$/, function(callback) {
        taskMgmtPage.siteTaskSelect().then(function () {
                         callback();
		});
	});
	this.Then(/^User should enter the Title in Title field$/, function(callback) {
        taskMgmtPage.titleField().then(function () {
                         callback();
		});
	});
	this.Then(/^User is able to enter the Site level title$/, function(callback) {
        taskMgmtPage.siteLeveltitleField().then(function () {
                         callback();
		});
	});
     this.Then(/^User should enter text in Description field$/, function(callback) {
        taskMgmtPage.descriptionField().then(function () {
                         callback();
		});
	});
	this.Then(/^User should select the category type$/, function(callback) {
        taskMgmtPage.siteCategoryDropdown().then(function () {
                         callback();
		});
	});
	this.Then(/^User should select the Priority type$/, function(callback) {
        taskMgmtPage.sitePriorityDropdown().then(function () {
                         callback();
		});
	});

	this.Then(/^User should select the Estimated Techs$/, function(callback) {
        taskMgmtPage.siteEstimatedTechsDropdown().then(function () {
                         callback();
		});
	});
	this.When(/^User should select the Recurrence type for the task$/, function(callback) {
        taskMgmtPage.recurrenceDropdown().then(function () {
			                         callback();
		   });
	});
	this.Then(/^User should click on End after radio button$/, function(callback) {
        taskMgmtPage.recurrenceEndAfterBtn().then(function () {
			                         callback();
		   });
	});
	this.Then(/^User should enter the End after occurrences$/, function(callback) {
        taskMgmtPage.recurrenceEndAfterOcc().then(function () {
			                         callback();
		   });
	});
	this.Then(/^User should enter the Tech Notes for the task$/, function(callback) {
        taskMgmtPage.techNotesTxtField().then(function () {
                         callback();
		});
	});
	this.Then(/^User should enter the POD or EOD Notes for the task$/, function(callback) {
        taskMgmtPage.pODEODNotesTxtField().then(function () {
                         callback();
		});
	});
	this.Then(/^User should click on Add button for creating the Site task$/, function(callback) {
        taskMgmtPage.clickAddBtn().then(function () {
                         callback();
		});
	});
	this.Then(/^User should click on task created success button$/, function(callback) {
        taskMgmtPage.successOkBtn().then(function () {
                         callback();
		});
	});
	this.When(/^User should able to enter text in search field$/, function(callback) {
        taskMgmtPage.activeSearchBtn().then(function () {
                         callback();
		});
	});
	this.Then(/^User is able to enter Task Title in search field$/, function(callback) {
        taskMgmtPage.activeSearchBtn1().then(function () {
                         callback();
		});
	});
	this.Then(/^User is able to click on Delete Task button$/, function(callback) {
        taskMgmtPage.deleteConformation().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify Deleted task is disapeared from work plan section$/, function(callback) {
	TestHelperPO.isElementPresent(element(by.xpath('//div[@id="crew_section_widget"]/div[10]/div'))).then(function () {
                var src = element(by.xpath('//div[@id="crew_section_widget"]/div[10]/div'));
                var drop = element(by.css('.float--left.u-pr0.createNewCrewDrop.ng-pristine.ng-untouched.ng-valid.ui-droppable'));
		browser.actions().dragAndDrop(src,drop).mouseUp().perform();
                            callback();
			     });
               });
	       this.Then(/^User is able to Remove Turbine from current Plan$/, function(callback) {
        taskMgmtPage.turbineRemoveWorkplan().then(function () {
                         callback();
		});
	});
	this.Then(/^I should able to click on Second Crew Add NeworExisting task button$/, function(callback) {
        taskMgmtPage.addNewORexistingTaskBtn1().then(function () {
                         callback();
		});
	});
	this.Then(/^I should able to select Second Crew Exixting task radio button$/, function(callback) {
        taskMgmtPage.addExistingTaskRadioBtn1().then(function () {
                         callback();
		});
	});
	this.When(/^User should able to click on Existing task dropdown$/, function(callback) {
        taskMgmtPage.existingTaskDropdwn().then(function () {
                         callback();
		});
	});
	this.Then(/^User should able to Add Existing task for Second Crew$/, function(callback) {
        taskMgmtPage.taskAddButton().then(function () {
                         callback();
		});
	});
	this.Then(/^User should able to add Existing task$/, function(callback) {
        taskMgmtPage.existingTurbineSelect().then(function () {
                                 callback();
		});
	});
	this.Then(/^User should able to click on Add button$/, function(callback) {
        taskMgmtPage.addButton().then(function () {
	console.log("The Turbine has already been added to the POD.");
                         callback();
		});
	});
	this.Then(/^User should able to see weather widget description$/, function(callback) {
        taskMgmtPage.PlanWeatherWidget().then(function (completed) {
	console.log("Turbine Weather widget Description" + completed);
                         callback();
		});
	});

	this.Then(/^User should able to see weather widget Temparature$/, function(callback) {
        taskMgmtPage.PlanWeather().then(function (completed) {
					console.log("Turbine Weather widget Temp"  + completed);
					callback();
			  });
	});

	var adminUserOpts = {
			url: 'https://f6d0524d-28d1-4af8-a21c-3c779790aff4.predix-uaa.run.aws-usw02-pr.ice.predix.io/oauth/token',
			headers:{
					'Authorization': 'Basic ' + 'MTZuN2tsNXo1M2pkeHB4M3M1bHd1Y2RmanZnamtocm8wN2x5cXk6cTVsdTFqdzJsN2prYzBtb2w1MHBlenBibzJkemNjYnl5d2F2cA==',
					'Content-Type': 'application/x-www-form-urlencoded',
					'Tenant': 'Basic ' + 'MTZuN2tsNXo1M2pkeHB4M3M1bHd1Y2RmanZnamtocm8wN2x5cXk6cTVsdTFqdzJsN2prYzBtb2w1MHBlenBibzJkemNjYnl5d2F2cA=='
			},
			body:{
					'grant_type' : 'client_credentials',
					'client_id' : '16n7kl5z53jdxpx3s5lwucdfjvgjkhro07lyqy',
					'client_secret' : 'q5lu1jw2l7jkc0mol50pezpbo2dzccbyywavp',
					'scope' : 'stuf.26b305ec-f801-4e76-b03a-ef409403546e.zone,stuf.write'
			}
	};


	this.Then(/^User should be able to see windspeed and temperature at hub height on weather widget$/, function(callback) {

	RestHelper.getAccessToken(adminUserOpts.url, adminUserOpts.headers, adminUserOpts.body, function (err, token) {

		var opts = {
				  headers: {
							'Content-Type': 'application/json',
							'Tenant': '24d9acde-e4b9-4a9c-9e95-579be64419b1',
							'Authorization': 'Bearer ' + token,
							'Accept': 'application/json'
					}
		};
		var url = 'https://ren-planning-svc-gere-qa.run.aws-usw02-pr.ice.predix.io/plans/v1/weather?siteGroupSourceKey=GE_ONW_SOUTH_HURLBURT_1000013';
		RestHelper.executeGetRequest(url, opts.headers, function (err, res) {
				console.log("Auth Token is : " + token);

				Logger.info("Weather service API Result : " + JSON.stringify(res.body));
				//Convert java script object to a string and print it in the console
				console.log("Weather service API Result is : " + JSON.stringify(res.body));
				//Get the number of elements in the java script object
				var size = Object.keys(res.body).length;
				console.log("The number of nodes in response: "+ size);

				var temperature = res.body.temperatureFahrenheit;
 				console.log("The value corresponding to key temperature is: "+ temperature);

 				var windSpeed = res.body.windSpeed + " m/s";
				console.log("The value corresponding to key windSpeed is: "+ windSpeed);

				taskMgmtPage.PlanWeather().then(function (completed) {
					console.log("Turbine Weather widget Temperature is: "  + completed);
					assert.equal(completed, temperature);
					taskMgmtPage.WeatherWidgetWindSpeed().then(function (windSpeedWidget) {
							console.log("Turbine Weather widget Wind Speed is "  + windSpeedWidget);
							assert.equal(windSpeedWidget, windSpeed);
							callback();
					});
				});
	  });
	});
	});

	this.Then(/^User should able to see weather widget Temparature in F$/, function(callback) {
        taskMgmtPage.PlanWeatherTemp().then(function (completed) {
	console.log("Turbine Weather widget Temp in " + completed);
                         callback();
		});
	});
	this.Then(/^User is able to wait for Performance widget$/, function(callback) {
        taskMgmtPage.waitForPerformanceWidgetPOD().then(function () {
                         callback();
		});
	});
	this.Then(/^User should able to see Performance widget in POD$/, function(callback) {
        taskMgmtPage.performanceWidgetPOD().then(function (completed) {
	console.log("Performance widget description" + completed);
                         callback();
		});
	});
	this.Then(/^User should able to see Turbine status widget in POD$/, function(callback) {
        taskMgmtPage.turbineStatusWidgetPOD().then(function (completed) {
	console.log("Turbine Status widget description" + completed);
                         callback();
		});
	});
	this.Then(/^User should able to see Site Contacts widget in POD$/, function(callback) {
        taskMgmtPage.siteContactsWidgetPOD().then(function (completed) {
	console.log("Site contacts widget Heading in POD" + completed);
                         callback();
		});
	});
	this.Then(/^User should able to see Attachments widget in POD$/, function(callback) {
        taskMgmtPage.attachmentsWidgetPOD().then(function (completed) {
	console.log("Attachments widget Heading in POD" + completed);
                         callback();
		});
	});
	this.Then(/^User should select the group type$/, function(callback) {
        taskMgmtPage.groupDropdwn().then(function () {
                                 callback();
		});
	});
	this.Then(/^Verify user is able view site group dropdown$/, function(callback) {
        taskMgmtPage.waitForsiteGroupDropdwn().then(function () {
                                 callback();
		});
	});

	this.Then(/^User should able to select site group$/, function(callback) {
        taskMgmtPage.siteGroupSelect().then(function () {
                                 callback();
		});
	});
	// Creating Hash tag and Deleting Hash tag
	this.Given(/^Verify user is able to view the Turbine page$/, function(callback) {
        taskMgmtPage.waitForturbineTab().then(function () {
                         callback();
		});
	});
	this.When(/^Verify user is able to navigates into Turbine page$/, function(callback) {
        taskMgmtPage.turbineTab().then(function () {
		console.log("User navigate into Turbine page");
                         callback();
		});
	});
	this.Then(/^Verify user is able to view the Create Hashtag Icon$/, function(callback) {
        taskMgmtPage.waitForclickOnHashTag().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to click on Hashtag$/, function(callback) {
        taskMgmtPage.clickOnHashTag().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to creating new Hashtag$/, function(callback) {
        taskMgmtPage.createHashTag().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to deleting existing Hashtag$/, function(callback) {
        taskMgmtPage.deleteHashTag().then(function () {
                         callback();
		});
	});
	//Searching with date range
	this.Given(/^Verify user is able to see the Turbine link$/, function(callback) {
        taskMgmtPage.waitForturbineTab().then(function () {
                         callback();
		});
	});
	this.When(/^Click on Turbine page$/, function(callback) {
        taskMgmtPage.turbineTab().then(function () {
                         callback();
		});
	});
	this.Then(/^Select the first turbine$/, function(callback) {
        taskMgmtPage.turbineLanding().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to change From date under Turbine history section$/, function(callback) {
        taskMgmtPage.fromDateRangeSearch().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to change To date under Turbine history section$/, function(callback) {
        taskMgmtPage.toDateRangeSearch().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to wait for display first turbine$/, function(callback) {
        taskMgmtPage.waitForturbineNames().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to sort with Turbine display name$/, function(callback) {
        taskMgmtPage.turbineLanding().then(function () {
                         callback();
		});
	});
	// Search turbine
	this.Given(/^Verify user is able to search the Turbine name$/, function(callback) {
        taskMgmtPage.turbineLandingSearch().then(function () {
                         callback();
		});
	});
	this.When(/^Verify user is able to select the Turbine$/, function(callback) {
        taskMgmtPage.selectFirstTurbine().then(function () {
                         callback();
		});
	});
	this.Then(/^Validating Turbine Number in Search section and Landing section$/, function(callback) {
        taskMgmtPage.turbineNameInSearch().then(function (turbine) {
	taskMgmtPage.turbineNameInPane().then(function (TName) {
	  assert.equal(turbine, TName);
	  console.log("Here is the Turbine Name : "+ turbine);
                         callback();
	           });
	     });
	});
	this.Then(/^Validating Turbine Model in Search section and Landing section$/, function(callback) {
        taskMgmtPage.turbineModelInSearch().then(function (turbine) {
	taskMgmtPage.turbineModelInPane().then(function (TName) {
	  assert.equal(turbine, TName);
	  console.log("Here is the Turbine Model : "+ turbine);
                         callback();
	           });
	     });
	});
	this.Then(/^Verify user is able to search with text under Turbine history section$/, function(callback) {
        taskMgmtPage.dateRangeSearchFld().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to see the header of site crews$/, function(callback) {
        taskMgmtPage.siteCrewsHeading().then(function (completed) {
		console.log("Here is the Header : "+ completed);
                         callback();
		});
	});
	this.Then(/^Verify user is able to see the first crews Name$/, function(callback) {
        taskMgmtPage.siteCrew1().then(function (completed) {
		console.log("Here is the Crew Name : "+ completed);
                         callback();
		});
	});
	this.Then(/^Verify user is able to see the first contractor Name$/, function(callback) {
        taskMgmtPage.siteCrew2().then(function (completed) {
		console.log("Here is the Contractor Name : "+ completed);
                         callback();
		});
	});
	this.Then(/^Verify user is able to see the first contractor Role$/, function(callback) {
        taskMgmtPage.siteCrewR1().then(function (completed) {
		console.log("Here is the Contractor Role : "+ completed);
                         callback();
		});
	});
	this.Then(/^Verify user is able to see the crews Name in second row$/, function(callback) {
        taskMgmtPage.siteCrewR2().then(function (completed) {
		console.log("Here is the Crew Name : "+ completed);
                         callback();
		});
	});
	this.Then(/^Verify user is able to see the second contractor Name$/, function(callback) {
        taskMgmtPage.siteCrew3().then(function (completed) {
		console.log("Here is the Contractor Name : "+ completed);
                         callback();
		});
	});
	this.Then(/^Verify user is able to see the second contractor Role$/, function(callback) {
        taskMgmtPage.siteCrew4().then(function (completed) {
		console.log("Here is the Contractor Role : "+ completed);
                         callback();
		});
	});
	this.Then(/^Verify user is able to see the crews Name in third row$/, function(callback) {
        taskMgmtPage.siteCrew5().then(function (completed) {
		console.log("Here is the Crew Name : "+ completed);
                         callback();
		});
	});
	this.Then(/^Verify user is able to see the third contractor Name$/, function(callback) {
        taskMgmtPage.siteCrew6().then(function (completed) {
		console.log("Here is the Contractor Name : "+ completed);
                         callback();
		});
	});
	this.Then(/^Verify user is able to see the third contractor Role$/, function(callback) {
        taskMgmtPage.siteCrewR3().then(function (completed) {
		console.log("Here is the Contractor Role : "+ completed);
                         callback();
		});
	});
	this.Then(/^Verify user is able to see the crews Name in Fourth row$/, function(callback) {
        taskMgmtPage.siteCrew5().then(function (completed) {
		console.log("Here is the Crew Name : "+ completed);
                         callback();
		});
	});
	this.Then(/^Verify user is able to see the Fourth contractor Name$/, function(callback) {
        taskMgmtPage.siteCrew6().then(function (completed) {
		console.log("Here is the Contractor Name : "+ completed);
                         callback();
		});
	});
	this.Then(/^Verify user is able to see the Fourth contractor Role$/, function(callback) {
        taskMgmtPage.siteCrewR3().then(function (completed) {
		console.log("Here is the Contractor Role : "+ completed);
                         callback();
		});
	});
	this.Then(/^Verify user is able to see the Performance widget$/, function(callback) {
        taskMgmtPage.performanceWidget().then(function (completed) {
		console.log("Here is the Performance widget Name : "+ completed);
                         callback();
		});
	});
	this.Then(/^Verify user is able to see the MTD Performance production value$/, function(callback) {
        taskMgmtPage.mTDPWProductionValue().then(function (completed) {
		console.log("Here is the MTD Performance Production value : "+ completed);
                         callback();
		});
	});
	this.Then(/^Verify user is able to see the MTD Performance Availability value$/, function(callback) {
        taskMgmtPage.mTDPWAvailabilityValue().then(function (completed) {
		console.log("Here is the MTD Performance Availability value : "+ completed);
                         callback();
		});
	});
	this.Then(/^Verify user is able to click on YTD Performance widget button$/, function(callback) {
        taskMgmtPage.performanceYTDButton().then(function () {
                         callback();
		});
	});

	this.Then(/^Verify user is able to see the YTD Performance production value$/, function(callback) {
        taskMgmtPage.mTDPWProductionValue().then(function (completed) {
		console.log("Here is the YTD Performance Production value : "+ completed);
                         callback();
		});
	});
	this.Then(/^Verify user is able to see the YTD Performance Availability value$/, function(callback) {
        taskMgmtPage.mTDPWAvailabilityValue().then(function (completed) {
		console.log("Here is the YTD Performance Availability value : "+ completed);
                         callback();
		});
	});

	this.Then(/^Verify user is able to click on Task filter button$/, function(callback) {
        taskMgmtPage.taskFilter().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to select Turbine asset type$/, function(callback) {
        taskMgmtPage.turbineCheckbox().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to select Site asset type$/, function(callback) {
        taskMgmtPage.siteCheckbox().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to click on Apply button$/, function(callback) {
        taskMgmtPage.filterApplyBtn().then(function () {
                         callback();
		});
	});
	this.Then(/^I should able to view the asset type is Turbine$/, function(callback) {
        taskMgmtPage.createdTaskTurbine1().then(function (completed) {
			console.log("Here is the Asset type: "+ completed);
                         callback();
		});
	});
	this.Then(/^User should able to see the asset type is Site$/, function(callback) {
        taskMgmtPage.createdTaskSite().then(function (completed) {
			console.log("Here is the Asset type: "+ completed);
                         callback();
		});
	});
	this.Then(/^Verify user is able to select Pending Task type$/, function(callback) {
        taskMgmtPage.turbinePendingCheckbox().then(function () {
                         callback();
		});
	});
	this.Then(/^I should able to view Pending task Type$/, function(callback) {
        taskMgmtPage.completedTaskVerification().then(function (completed) {
			console.log("Here is the task Type: "+ completed);
                         callback();
		});
	});

	this.Then(/^Verify user is able to click on Turbine filter button$/, function(callback) {
        taskMgmtPage.turbineFilter().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to select Turbine online check box$/, function(callback) {
        taskMgmtPage.turbineOnlineCheckbox().then(function () {
                         callback();
		});
	});
	this.Then(/^I should able to see Turbine status in Landing page$/, function(callback) {
        taskMgmtPage.turbineVerification().then(function (completed) {
			console.log("Here is the turbine status: "+ completed);
                         callback();
		});
	});
	this.Then(/^Verify user is able to view the Turbine status Triangular icon$/, function(callback) {
        taskMgmtPage.turbineStatusTriangular().then(function (result) {
		var i=0,flag;
					flag=false;
					for(i=0;i<result.length;i++){
						if(result[i]=='NO TRIANGULAR'){
							flag = true;
						}
					}
			//console.log("Here is the turbine status Widget Pulse point details: "+ isVisible);
                         if(flag){
				taskMgmtPage.turbineStatusTriangular().then(function (result) {
				console.log("Turbine status Triangular is not present: "+ result);
							callback();
						   });

					}else{
				taskMgmtPage.turbineStatusTriangular().then(function () {
                                 console.log("Turbine status Triangular is present: ");
				 //taskMgmtPage.assetNotificationCount().then(function () {
								callback();
								});
							//});

					}
		});
	});
	/*this.Then(/^Verify user is able to view the Turbine status Triangular icon$/, function(callback) {
          taskMgmtPage.turbineStatusTriangular().then(function () {
	 if(true){
	taskMgmtPage.turbineStatusTriangular3().then(function (result) {
	//taskMgmtPage.triangularTask().then(function (TaskName) {
	// console.log("System Generated Task Name: " + TaskName);
       //taskMgmtPage.triangularTaskPlusIcon().then(function (PlusIcon) {
      //taskMgmtPage.triangularselectCrewSection().then(function () {
      //console.log("Turbine Task PlusIcon: " + PlusIcon);
	//});
		//});
	taskMgmtPage.triangularTaskCancelIcon().then(function () {

		//});
	console.log("Turbine status Triangular is not present: "+ result);
	    //callback();
	    });
		});
			}else{
	taskMgmtPage.turbineStatusTriangular2().then(function () {

	});

			}
                         callback();
		});
	});*/
	this.Then(/^Verify user is able to click on Site summary$/, function(callback) {
        taskMgmtPage.siteSummaryPlanPage().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to select Turbine task type APM cases$/, function(callback) {
        taskMgmtPage.taskTypeAPMFilter().then(function () {
	                         callback();
		});
	});
	
	this.Then(/^User should able to validate APM Case task type$/, function(callback) {
        taskMgmtPage.validateAPMCases(callback);		
	});
	this.Then(/^Verify user is able to select Turbine task type ETC$/, function(callback) {
        taskMgmtPage.taskTypeETCFilter().then(function () {
                         callback();
		});
	});
	this.Then(/^User should able to validate ETC task type$/, function(callback) {
        taskMgmtPage.validateETCTaskFilter(callback);		
	});
	this.Then(/^Verify user is able to select Turbine task type Faulted$/, function(callback) {
        taskMgmtPage.taskTypeFaultedFilter().then(function () {
                         callback();
		});
	});
	this.Then(/^User should able to validate Faulted task type$/, function(callback) {
        taskMgmtPage.validateFaultedTaskFilter(callback);		
	});
	this.Then(/^Verify user is able to select Turbine task type Impacted$/, function(callback) {
        taskMgmtPage.taskTypeImpactedFilter().then(function () {
                         callback();
		});
	});
	this.Then(/^User should able to validate Impacted task type$/, function(callback) {
        taskMgmtPage.validateImpactedTaskFilter(callback);		
	});
	this.Then(/^Verify user is able to select Turbine task type Maintenance$/, function(callback) {
        taskMgmtPage.taskTypeMaintenanceFilter().then(function () {
                         callback();
		});
	});
	this.Then(/^User should able to validate Maintenance task type$/, function(callback) {
        taskMgmtPage.validateMaintenanceTaskFilter(callback);		
	});
	this.Then(/^Verify user is able to select Turbine task type MCE$/, function(callback) {
        taskMgmtPage.taskTypeMCEFilter().then(function () {
                         callback();
		});
	});
	this.Then(/^User should able to validate MCE task type$/, function(callback) {
        taskMgmtPage.validateMCETaskFilter(callback);		
	});
	this.Then(/^Verify user is able to select Turbine task type Netcom$/, function(callback) {
        taskMgmtPage.taskTypeNetcomFilter().then(function () {
                         callback();
		});
	});
	this.Then(/^User should able to validate Netcom task type$/, function(callback) {
        taskMgmtPage.validateNetcomTaskFilter(callback);		
	});
	this.Then(/^Verify user is able to select Turbine task type Punch List$/, function(callback) {
        taskMgmtPage.taskTypePunchlistFilter().then(function () {
                         callback();
		});
	});
	this.Then(/^User should able to validate Punch List task type$/, function(callback) {
        taskMgmtPage.validatePunchlistTaskFilter(callback);		
	});
	this.Then(/^Verify user is able to select Turbine task type Retrofits$/, function(callback) {
        taskMgmtPage.taskTypeRetrofitsFilter().then(function () {
                         callback();
		});
	});
	this.Then(/^User should able to validate Retrofits task type$/, function(callback) {
        taskMgmtPage.validateRetrofitsTaskFilter(callback);		
	});
	this.Then(/^Verify user is able to select Turbine task type Stopped$/, function(callback) {
        taskMgmtPage.taskTypeStoppedFilter().then(function () {
                         callback();
		});
	});
	this.Then(/^User should able to validate Stopped task type$/, function(callback) {
        taskMgmtPage.validateStoppedTaskFilter(callback);		
	});
	this.Then(/^Verify user is able to select Turbine task type TIL$/, function(callback) {
        taskMgmtPage.taskTypeTILFilter().then(function () {
                         callback();
		});
	});
	this.Then(/^User should able to validate TIL task type$/, function(callback) {
        taskMgmtPage.validateTILTaskFilter(callback);		
	});
	this.Then(/^Verify user is able to select Turbine task type Unplanned Maintenance$/, function(callback) {
        taskMgmtPage.taskTypeUMFilter().then(function () {
                         callback();
		});
	});
	this.Then(/^User should able to validate Unplanned Maintenance task type$/, function(callback) {
        taskMgmtPage.validateUMTaskFilter(callback);		
	});
	this.Then(/^Verify user is able to select Turbine task type Watchlist$/, function(callback) {
        taskMgmtPage.taskTypeWatchlistFilter().then(function () {
                         callback();
		});
	});
	this.Then(/^User should able to validate Watchlist task type$/, function(callback) {
        taskMgmtPage.validateWatchlistTaskFilter(callback);		
	});
	this.Then(/^Verify user is able to select Turbine task type Other$/, function(callback) {
        taskMgmtPage.taskTypeOtherTurbineFilter().then(function () {
                         callback();
		});
	});
	this.Then(/^User should able to validate Other Turbine task type$/, function(callback) {
        taskMgmtPage.validateOtherTurbineTaskFilter(callback);		
	});

	this.Then(/^Verify user is able to select site task type BOP$/, function(callback) {
        taskMgmtPage.taskTypeSiteBOPFilter().then(function () {
                         callback();
		});
	});
	this.Then(/^User should able to validate BOP site task type$/, function(callback) {
        taskMgmtPage.validateSiteBOPTaskFilter(callback);		
	});
	this.Then(/^Verify user is able to select site task type EHS$/, function(callback) {
        taskMgmtPage.taskTypeSiteEHSFilter().then(function () {
                         callback();
		});
	});
	this.Then(/^User should able to validate EHS site task type$/, function(callback) {
        taskMgmtPage.validateSiteEHSTaskFilter(callback);		
	});
	this.Then(/^Verify user is able to select site task type Others$/, function(callback) {
        taskMgmtPage.taskTypeSiteOthersFilter().then(function () {
                         callback();
		});
	});
	this.Then(/^User should able to validate Others site task type$/, function(callback) {
        taskMgmtPage.validateSiteOthersTaskFilter(callback);		
	});
	this.Then(/^Verify user is able to see the Turbine task type header$/, function(callback) {
        taskMgmtPage.turbineTaskTypeFilterHeader().then(function (value) {
		assert.equal(value, 'Turbine Task Type');
		console.log("Task type Header: "+ value);
                         callback();
		});
	});
	this.Then(/^Verify user is able to see the Site task type header$/, function(callback) {
        taskMgmtPage.siteTaskTypeFilterHeader().then(function (value) {
		assert.equal(value, 'Site Task Type');
		console.log("Task type Header: "+ value);
                         callback();
		});
	});

	/*this.Then(/^Verify user is able to filter Task type Filter for Unplanned Maintenance$/, function(callback) {
        taskMgmtPage.taskTypeFilterUM().then(function () {
			//console.log("Here is the turbine status: "+ completed);
                         callback();
		});
	});
	this.Then(/^User should able to view Unplanned Maintenance task Type$/, function(callback) {
        taskMgmtPage.taskFilterPlusePoint().then(function (completed) {
			console.log("Here is the task Type: "+ completed);
			//TestHelper.assertTrue(completed, 'Pulse Point');
			assert.equal(completed, 'Unplanned Maintenance');
                         callback();
		});
	});
	this.Then(/^Verify user is able to filter Task type Filter for Maintenance$/, function(callback) {
        taskMgmtPage.taskTypeFilterMaintenance().then(function () {
			//console.log("Here is the turbine status: "+ completed);
                         callback();
		});
	});
	this.Then(/^User should able to view Maintenance task Type$/, function(callback) {
        taskMgmtPage.taskFilterPlusePoint().then(function (completed) {
			console.log("Here is the task Type: "+ completed);
			//TestHelper.assertTrue(completed, 'Pulse Point');
			assert.equal(completed, 'Maintenance');
                         callback();
		});
	});*/
	this.Then(/^Verify user is able to Click on Reset filter button$/, function(callback) {
        taskMgmtPage.taskFilterResetBtn().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to wait for work plan$/, function(callback) {
        taskMgmtPage.waitFortaskCompleteIcon().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to Complete the Task in Work plan$/, function(callback) {
        taskMgmtPage.taskCompleteIcon().then(function () {
	taskMgmtPage.taskActualDuration().then(function (result) {
		var i=0,flag;
					flag=false;
					for(i=0;i<result.length;i++){
						if(result[i]=='NOT COMPLETED'){
							flag = true;
						}
					}
			  if(flag){
			taskMgmtPage.workPlanTaskCompleted().then(function () {
				console.log("Turbine Task Already in completed status");
				callback();
				});
					}else{
				taskMgmtPage.completeTaskInWorkPlan().then(function () {
                                    //console.log("Turbine Already completed: ");
								callback();
							});

					}
			});
		});
	});
        this.Then(/^Verify user is able to select Last Visit sorting option$/, function(callback) {
        taskMgmtPage.turbineSortLastvisit().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to Wait for to display First Turbine Task details$/, function(callback) {
        taskMgmtPage.waitForturbineFirstselection().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to Click on First Turbine Task details$/, function(callback) {
        taskMgmtPage.turbineFirstselection().then(function () {
                         callback();
		});
	});
	this.Then(/^User should able to validate the Turbine Last visited date$/, function(callback) {
        taskMgmtPage.turbineUpdatedDate().then(function (turbine) {
	taskMgmtPage.turbineLastVisit().then(function (TName) {
	  //assert.equal(turbine, TName);
	  console.log("Here is the Turbine Last visited date: "+ turbine);
                         callback();
	           });
	     });
	});
	this.Then(/^User should able to view the Turbine Task Title$/, function(callback) {
        taskMgmtPage.turbineTaskTitle().then(function (completed) {
			console.log("Here is the Turbine Task Title: "+ completed);
                         callback();
		});
	});
	this.Then(/^User should able to view the Turbine Task Resolution Notes$/, function(callback) {
        taskMgmtPage.turbineResolutionNotes().then(function (completed) {
			console.log("Here is the Turbine Task Resolution Notes: "+ completed);
                         callback();
		});
	});
	this.Then(/^Verify user is able to Change Turbine Task status$/, function(callback) {
        taskMgmtPage.turbineTaskCompletionInPlan().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to Complete the Previous Task in Work plan$/, function(callback) {
        taskMgmtPage.taskCompleteIcon().then(function () {
	taskMgmtPage.taskActualDuration().then(function (result) {
		var i=0,flag;
					flag=false;
					for(i=0;i<result.length;i++){
						if(result[i]=='NOT COMPLETED'){
							flag = true;
						}
					}
			  if(flag){
			taskMgmtPage.noDataforCurrentDate().then(function (Completed) {
				console.log("There is no Data presnt in the Previous date:" + Completed);
				callback();
				});
					}else{
				taskMgmtPage.completeTaskInWorkPlan().then(function () {
                                    //console.log("Turbine Already completed: ");
								callback();
							});

					}
			});
		});
	});
	this.Then(/^Verify User able to click on Reports Save Prompt button$/, function(callback) {
        taskMgmtPage.EditReportSavePromptYesBtn().then(function () {
                         callback();
		});
	});
	this.Then(/^Click on Technician Report tab$/, function(callback) {
        taskMgmtPage.techReportTab().then(function () {
                         callback();
		});
	});
//29/05/2018----US220446
        this.When(/^Click on Plan of the day Tab$/, function(callback) {
        taskMgmtPage.reportsPODTab().then(function () {
                         callback();
		});
	});
	this.Then(/^Click on Manage contacts Tab$/, function(callback) {
        taskMgmtPage.manageContactBtn().then(function () {
                         callback();
		});
	});
	this.Then(/^Searching Personnel info by entering Person name in Site contacts$/, function(callback) {
        taskMgmtPage.manageContactPersonNameFld().then(function () {
                         callback();
		});
	});
	this.Then(/^Adding seached contact by click on Add contacts button$/, function(callback) {
        taskMgmtPage.addContactBtn().then(function () {
                         callback();
		});
	});
	this.Then(/^User should be view the Site contacts Name in Manage Site Contacts$/, function(callback) {
        taskMgmtPage.siteContactNameText().then(function (completed) {
			console.log("Here is the Site contacts Name: " + completed);
			assert.equal(completed, 'Radha Manchikalapati');
			//assert.equal(completed, 'David Miller');
                         callback();
		});
	});
	this.Then(/^User should be view the Site contacts Role in Manage Site Contacts$/, function(callback) {
        taskMgmtPage.siteContactRole().then(function (completed) {
			console.log("Here is the Site contacts Role: " + completed);
			assert.equal(completed, 'Site Manager');
                         callback();
		});
	});
	this.Then(/^User should be view the Site contacts Email id in Manage Site Contacts$/, function(callback) {
        taskMgmtPage.siteContactEmailText().then(function (completed) {
			console.log("Here is the Site contacts Email id: " + completed);
			assert.equal(completed, 'radha.manchikalapati@ge.com');
			//assert.equal(completed, 'david.miller4@ge.com');
                         callback();
		});
	});
	this.Then(/^Verify user is able to disable the site contacts in Manage Site Contacts$/, function(callback) {
        taskMgmtPage.siteContactDisableIcon().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to delete the Site contacts in Manage Site Contacts$/, function(callback) {
        taskMgmtPage.siteContactDeleteIcon().then(function () {
                         callback();
		});
	});

	this.Then(/^Click on Back button in Manage Site Contacts$/, function(callback) {
        taskMgmtPage.siteContactBackBtn().then(function () {
                         callback();
		});
	});
	this.Then(/^Click on Back button$/, function(callback) {
        taskMgmtPage.rptArchiveBack().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify Added Site contacts info display in site contacts widget$/, function(callback) {
        taskMgmtPage.siteContactWidgetNameTxt().then(function (completed) {
			console.log("Here is the Site contacts Name: " + completed);
			assert.equal(completed, 'Radha Manchikalapati');
			//assert.equal(completed, 'David Miller');
                         callback();
		});
	});
	//1/06/2018-----US220440 and US216766
	this.Then(/^Verify user is able to create a Contractor$/, function(callback) {
        taskMgmtPage.createNewContractor().then(function () {
                         callback();
		});
	});
	this.Then(/^Validation of newly created Contractor$/, function(callback) {
        taskMgmtPage.newContractor().then(function () {
                         callback();
		});
	});
	this.Then(/^Click on Edit Tech tab$/, function(callback) {
        taskMgmtPage.editTechDetails().then(function () {
                         callback();
		});
	});
	this.Then(/^Validation of contractor First name$/, function(callback) {
        taskMgmtPage.editFirstName().then(function (completed) {
	console.log("Here is the Contractor First Name: " + completed);
                         callback();
		});
	});
	this.Then(/^Validation of contractor Last name$/, function(callback) {
        taskMgmtPage.editLastName().then(function (completed) {
	console.log("Here is the Contractor Last Name: " + completed);
                         callback();
		});
	});
	this.Then(/^Verify user is able to Save the contractor details$/, function(callback) {
        taskMgmtPage.editTechSaveBtn().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to Delete the contractor$/, function(callback) {
        taskMgmtPage.deleteTech().then(function () {
                         callback();
		});
	});
	this.Then(/^User should able to see the First Contractor Name$/, function(callback) {
        taskMgmtPage.contractorOnTurbinepage().then(function (completed) {
			console.log("Here is the First Contractor Name: " + completed);
                         callback();
		});

	});
	this.Then(/^User should able to see the Second Contractor Name$/, function(callback) {
        taskMgmtPage.contractorOnTurbinepage1().then(function (completed) {
			console.log("Here is the Second Contractor Name: " + completed);
                         callback();
		});

	});
	this.Then(/^User should validate first technician tooltip in workplan and Crew ribbon$/, function(callback) {
        taskMgmtPage.crewNameTooltipInWP().then(function (completed) {
	taskMgmtPage.crewNameTooltipInCrew().then(function (completed) {
			console.log("Here is the first Contractor Tooltip in Crew ribbon: " + completed);
			console.log("Here is the first Contractor Tooltip in work plan: " + completed);
                         callback();
		});
	     });
	});

	this.Then(/^I verify edit Crew Name tooltip info$/, function(callback) {
				taskMgmtPage.editCrewNameTooltip().then(function (tooltipInfo) {
						console.log("Tooltip info displayed is:"+ tooltipInfo);
						assert.equal(tooltipInfo, 'Click to edit Crew Name');
		        callback();
				});

	});

	this.Then(/^User should validate Second technician tooltip in workplan and Crew ribbon$/, function(callback) {
        taskMgmtPage.crewNameTooltipInWP1().then(function (completed) {
	taskMgmtPage.crewNameTooltipInCrew1().then(function (completed) {
			console.log("Here is the second Contractor Tooltip in Crew ribbon: " + completed);
			console.log("Here is the second Contractor Tooltip in work plan: " + completed);
                         callback();
		});
	     });
	});
	/*this.Then(/^User should validate first technician tooltip in Crew ribbon$/, function(callback) {
        taskMgmtPage.crewNameTooltipInCrew().then(function (completed) {
			console.log("Here is the first Contractor Tooltip in Crew ribbon: " + completed);
                         callback();
		});
	});*/
	this.Then(/^Verify User is able see the Site Level Task in Tech Report$/, function(callback) {
        taskMgmtPage.siteLevelTaskInTech().then(function (completed) {
		 assert.equal(completed, 'SITE');
			console.log("Here is the Site Level Task Name: " + completed);
                         callback();
		});
	});
	this.Then(/^Verify User is able see the Site Level Task created in Task page under Tech Report$/, function(callback) {
        taskMgmtPage.siteLevelTaskVerifyInTech().then(function (completed) {
		 //assert.equal(completed, 'Site_Task_Creation');
			console.log("Here is the Site Level Created Task : " + completed);
                         callback();
		});
	});
	this.Then(/^Verify user is able to Click on Actions button$/, function(callback) {
        taskMgmtPage.actionsBtnTaskpage().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to Click on Import button$/, function(callback) {
        taskMgmtPage.importBtnTaskpage().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to upload the Excel sheet$/, function(callback) {
          taskMgmtPage.openFileSelector().then(function () {
                         callback();
		});
	});
	/*this.Then(/^Verify user is able to upload the Excel sheet$/, function (callback) {
		taskMgmtPage.openFileSelector();
		//Logger.info('File selector invoked and uploaded the file');
		callback();
	});*/
	this.Then(/^Search the Task which is created by using csv file$/, function(callback) {
        taskMgmtPage.activeSearchBtn2().then(function () {
                         callback();
		});
	});
	this.Then(/^Validate the Task name which is created by using csv file$/, function(callback) {
        taskMgmtPage.csvTaskTitle().then(function (completed) {
		assert.equal(completed, 'CSV_ProUITask');
		console.log("Here is the CSV Task : " + completed);
                         callback();
		});
	});
	this.Then(/^Select the Completed check box from Task status$/, function(callback) {
        taskMgmtPage.completedChkBoxTaskFilter().then(function () {
                         callback();
		});
	});
	this.Then(/^Validate the Task status$/, function(callback) {
        taskMgmtPage.completedTaskVerification().then(function (value) {
		assert.equal(value, 'completed');
			console.log("Here is the Task status: "+ value);
                         callback();
		});
	});
	this.Then(/^Verify user is able to upload CSV file in Attachments section$/, function(callback) {
          taskMgmtPage.openFileSelector1().then(function () {
                         callback();
		});
	});
	this.Then(/^Wait for CSV download Attachments icon$/, function(callback) {
          taskMgmtPage.waitForAttachmentDownloadOptn().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to download CSV file in Attachments section$/, function(callback) {
          taskMgmtPage.attachmentDownloadOptn().then(function () {
                         callback();
		});
	});
	this.Then(/^Delete CSV file from Attachments section$/, function(callback) {
          taskMgmtPage.fileDeleteBtn().then(function () {
                         callback();
		});
	});
	this.Then(/^Validate the enterd Notes$/, function(callback) {
        taskMgmtPage.reportNotesMax().then(function (value) {
		assert.equal(value, "Before you can begin to determine what the composition of a particular paragraph will be, you must first decide on an argument and a working thesis statement for your paper. What is the most important idea that you are trying to convey to your reader? The information in each paragraph must be related to that idea. In other words, your paragraphs should remind your reader that there is a recurrent relationship between your thesis and the information in each paragraph. A working thesis functions like a seed from which your paper, and your ideas, will grow. The whole process is an organic one—a natural progression from a seed to a full-blown paper where there are direct, familial relationships between all of the ideas in the paper. The decision about what to put into your paragraphs begins with the germination of a seed of ideas this germination process is better known as brainstorming. There are many techniques for brainstorming; whichever one you choose, this stage of paragraph development cannot be skipped. Building paragraphs can be like building a skyscraper: there must be a well-planned foundation that supports what you are building. Any cracks, inconsistencies, or other corruptions of the foundation can cause your whole paper to crumble.So, let’s suppose that you have done some brainstorming to develop your thesis. What else should you keep in mind as you begin to create paragraphs.There are many different ways to organize a paragraph. The organization you choose will depend on the controlling idea of the paragraph. Below are a few possibilities for organization, with links to brief examples:Narration: Tell a story. Go chronologically,from start to finish. See an example. Description: Provide specific details about what something looks, smells, tastes, sounds, or feels like. Organize spatially, in order of appearance, or by topic. See an example. Narration: Tell a story. Go chronologically,from start to finish. See an example.Before you can begin to determine what the composition of a particular paragraph will be, you must first decide on an argument and a working thesis statement for your paper. What is the most important idea that you are trying to convey to your reader? The information in each paragraph must be related to that idea. In other words, your paragraphs should remind your reader that there is a recurrent relationship between your thesis and the information in each paragraph. A working thesis functions like a seed from which your paper, and your ideas, will grow. The whole process is an organic one—a natural progression from a seed to a full-blown paper where there are direct, familial relationships between all of the ideas in the paper. The decision about what to put into your paragraphs begins with the germination of a seed of ideas; this germination process is better known as brainstorming. There are many techniques for brainstorming; whichever one you choose, this stage of paragraph development cannot be skipped. Building paragraphs can be like building a skyscraper: there must be a well-planned foundation that supports what you are building. Any cracks, inconsistencies, or other corruptions of the foundation can cause your whole paper to crumble.So, let’s suppose that you have done some brainstorming to develop your thesis. What else should you keep in mind as you begin to create paragraphs The decision about what to put into your paragraphs begins with the germination of a seed of ideas this germination process is better known as brainstorming. There are many techniques for brainstorming whichever one you choose, this stage of paragraph development cannot be skipped. Building paragraphs can be like building a skyscraper: there must be a well-planned foundation that supports what you are building. Any cracks, inconsistencies, or other corruptions of the foundation can cause your whole paper to crumble");
			//console.log("Here is the Task status: "+ value);
                         callback();
		});
	});
	this.Then(/^Download the CSV file from Archive section$/, function(callback) {
          taskMgmtPage.fileDownloadArchive().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able to View Site Name in Roman Numerals as Capital in Weather widget$/, function(callback) {
        taskMgmtPage.siteNameInWWReports().then(function(completed) {
            //assert.equal(completed, 'Smoky Hills II');
            console.log("Site name is : " + completed);
            callback();
              });
        });
	this.Then(/^Verify user is able to Click on Select Task option$/, function(callback) {
          taskMgmtPage.selectOptionInTaskpage().then(function () {
                         callback();
		});
	});
	this.Then(/^Select the First Turbine task$/, function(callback) {
          taskMgmtPage.selectFirstTurbineTaskpage().then(function () {
                         callback();
		});
	});
	this.Then(/^Select the Second Turbine task$/, function(callback) {
          taskMgmtPage.selectSecondTurbineTaskpage().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able export all the task details$/, function(callback) {
          taskMgmtPage.exportAllBtnTaskpage().then(function () {
                         callback();
		});
	});
	this.Then(/^Verify user is able export selected task details$/, function(callback) {
          taskMgmtPage.exportBtnTaskpage().then(function () {
                         callback();
		});
	});
	this.Then(/^Click on Cancel button of selected tasks$/, function(callback) {
          taskMgmtPage.selectCancelInTaskpage().then(function () {
                         callback();
		});
	});
	this.Then(/^Click on Show Hide option in POD Turbines Operating in Reduced Status$/, function(callback) {
          taskMgmtPage.podShowHideOption1().then(function () {
                         callback();
		});
	});

  this.Then(/^Turbine work duration is visible under work plan section$/, function(callback) {
      taskMgmtPage.checkWorkDuration().then(function () {
          callback();
      });
  });

  this.Then(/^I display the turbine work duration under work plan section$/, function(callback) {
      taskMgmtPage.displayWorkDuration().then(function (duration) {
          console.log("Duration is: " + duration);
          callback();
      });
   });

   this.Given(/^I click on the first crew name in crews section$/, function(callback) {
   taskMgmtPage.clickCrewName().then(function (completed) {
       assert.isTrue(completed, 'Unable to click on Crew Name');
       console.log("First Crew name is displayed under Crews section in Plan page");
       callback();
  });

});

		this.Then(/^I click on the crew name again in crews section$/, function(callback) {
		taskMgmtPage.clickCrewName().then(function (completed) {
				assert.isTrue(completed, 'Unable to click on Crew Name');
				console.log("Crew name is displayed under Crews section in Plan page");
				callback();
		});

});



this.Then(/^I check if crew name is editable$/, function(callback) {
   element.all(by.className('input--tiny editCrewName ng-pristine ng-untouched ng-valid ng-scope ng-not-empty ng-valid-maxlength')).get(0).getAttribute('value').then(function(crewName){
       console.log('Crew Name is: ' + crewName );
       callback();
   });

 });



 this.Then(/^I modify the crew name$/, function(callback) {
       taskMgmtPage.updateCrewName().then(function () {
			 console.log('Crew Name is updated');
       callback();
   });
 });

 this.Then(/^I click on crews header$/, function(callback) {
       taskMgmtPage.clickCrewsHeader().then(function () {
       callback();
   });
 });

 this.Then(/^Verify user able to drag and drop technicians onto existing technicians in crew$/, function(callback) {
			TestHelperPO.isElementPresent(element(by.xpath('(//*[@ng-model="unassignedCrews"])[1]'))).then(function () {

					var src = element(by.xpath('(//*[@ng-model="unassignedCrews"])[1]'));
					var drop = element(by.xpath('(//*[@class="ng-pristine ng-untouched ng-valid ng-scope ui-draggable ui-draggable-handle ng-not-empty contractor-person"])[1]'));
					browser.actions().dragAndDrop(src,drop).mouseUp().perform();
					browser.waitForAngular();
					callback();
			});
		});

    this.Then(/^Verify user able to drag and drop turbines from one crew to the other$/, function(callback) {
  TestHelperPO.isElementPresent(element(by.xpath('(//*[@ng-model="data.assets"])[2]'))).then(function () {

      var src = element(by.xpath('(//*[@ng-model="data.assets"])[2]'));
      var drop = element(by.xpath('(//*[@ng-model="data.assets"])[3]'));
      browser.actions().dragAndDrop(src,drop).mouseUp().perform();
      browser.waitForAngular();
      browser.actions().dragAndDrop(drop,src).mouseUp().perform();
      browser.waitForAngular();
      callback();
  });
});

this.Then(/^I click on the Recipient button$/, function(callback) {
      taskMgmtPage.clickRecipientButton().then(function () {
      callback();
  });
});

this.Then(/^I add the recipient email id$/, function(callback) {
      taskMgmtPage.addRecipientEmailId().then(function () {
      console.log("Able to add recipient email id");
      callback();
  });
});


this.Then(/^I click on Back button$/, function(callback) {
      taskMgmtPage.clickBackButton().then(function () {
      callback();
  });
});

this.Then(/^I wait for the Recipient Button to be displayed$/, function(callback) {
      taskMgmtPage.waitForRecipientButton().then(function () {
      console.log("Wait for Recipient Button to be displayed");
      callback();
  });
});

this.Then(/^I check if the recipient email id exists$/, function(callback) {
      taskMgmtPage.checkRecipientEmailId().then(function () {
      console.log("Added recipient email id is getting displayed");
      callback();
  });
});

this.Then(/^I click on Preview Button$/, function(callback) {
      taskMgmtPage.clickPreviewButton().then(function () {
      callback();
  });
});

this.Then(/^I check if Print to email Button is displayed$/, function(callback) {
      taskMgmtPage.checkPrintToEmailButton().then(function () {
      callback();
  });
});

this.Then(/^I click on Cancel Button$/, function(callback) {
      taskMgmtPage.clickCancelButton().then(function () {
      callback();
  });
});



	this.Then(/^Select Task Title in Show Hide option in POD Turbines Operating in Reduced Status$/, function(callback) {
          taskMgmtPage.ispodTaskTitleVisibile().then(function () {
	 if(true){
	taskMgmtPage.podTaskTitle1().then(function (completed) {
	console.log("Task Title check box is selected" + completed);
	if(!completed) {
		taskMgmtPage.podTaskTitle().then(function () {
		console.log("Task Title check box is not selected");
		callback();
		});
	}
	});
	}

		});
	});
     this.Then(/^I verify if Turbine checkbox is checked$/, function (callback) {
                element.all(by.className('u-mr-- style-scope px-dropdown-content')).get(1).isSelected().then(function(selected){
                    if (selected){
                        console.log("Turbine checkbox is checked");
                        assert.isTrue(selected, 'Turbine checkbox is not getting checked');
                    } else {
			taskMgmtPage.podTaskTitle().then(function () {
                        console.log("Turbine checkbox is unchecked");
                        assert.isFalse(selected, 'Turbine checkbox is not getting unselected');
			});
                    }
                    callback();

                });
    });
    this.Then(/^Click on Plan page conformation message Yes button$/, function(callback) {
      taskMgmtPage.plnPageConfMsgYesBtn().then(function () {
      callback();
  });
});

this.Then(/^Verify user is able to Change Turbine Task1 status$/, function(callback) {
        taskMgmtPage.turbineTaskCompletionInPlan1().then(function() {
            callback();
        });
    });

this.Then(/^Verify user is able to Complete the Task1 in Work plan$/, function(callback) {
        taskMgmtPage.taskCompleteIcon1().then(function() {
            taskMgmtPage.taskActualDuration().then(function(result) {
                var i = 0,
                    flag;
                flag = false;
                for (i = 0; i < result.length; i++) {
                    if (result[i] == 'NOT COMPLETED') {
                        flag = true;
                    }
                }
                if (flag) {
                    taskMgmtPage.workPlanTaskCompleted().then(function() {
                        console.log("Turbine Task Already in completed status");
                        callback();
                    });
                } else {
                    taskMgmtPage.completeTaskInWorkPlan().then(function() {
                        //console.log("Turbine Already completed: ");
                        callback();
                    });

                }
            });
        });
    });

this.Then(/^Verify user able to add new contractor by drag and drop at crew option$/, function(callback) {
    TestHelperPO.isElementPresent(element(by.xpath('//div[@id="crew_section_widget"]/div[10]/div'))).then(function () {
                var src = element(by.xpath('//div[@id="crew_section_widget"]/div[10]/div'));
                var drop = element(by.xpath('//div[@id="crew_section_widget"]/div[1]/div'));
                                browser.actions().dragAndDrop(src,drop).mouseUp().perform();
                            callback();
                                                     });
               });
this.Then(/^Select Task Title in Show Hide option in POD Turbines Operating in Reduced Status$/, function(callback) {
   element(by.xpath("(//*[@id='list']/li[4]/input[@type='checkbox'])[1]")).isSelected().then(function(value){
      console.log("Value of Checkbox: " +value);
   if(value === true){
              browser.sleep(3000);
              element(by.xpath("(//*[@id='list']/li[4]/input[@type='checkbox'])[1]")).isSelected().then(function (completed) {
                  console.log("Task Title check box is selected: " + completed);
                  callback();
              });
   }else {
      browser.sleep(5000);
              element(by.xpath("(//*[@id='list']/li[4])[1]")).click();
                element(by.xpath("(//*[@id='list']/li[4]/input[@type='checkbox'])[1]")).isSelected().then(function (completed) {
                   console.log("After clicking the value is: " + completed);
                   callback();
               });
   }
});
  });

  //DE62214: Dropdown values should be in the defined order - Chronological Order
this.Then(/^Verify Recurrence dropdown in defined order$/, function(callback) {
	taskMgmtPage.verifyRecurrenceOrder().then(function(completed) {
		for (var inc = 0; inc < completed.length; inc++) {
			if (inc === 0) {
				assert.equal(completed[inc], 'Select');
				console.log('Select - Matched');
			} else if (inc === 1) {
				assert.equal(completed[inc], 'Annual');
				console.log('Annual - Matched');
			} else if (inc === 2) {
				assert.equal(completed[inc], 'Semi Annual');
				console.log('Semi Annual - Matched');
			} else if (inc === 3) {
				assert.equal(completed[inc], 'Monthly');
				console.log('Monthly - Matched');
			} else if (inc === 4) {
				assert.equal(completed[inc], 'Every Climb');
				console.log('Every Climb - Matched');
			} else if (inc === 5) {
				assert.equal(completed[inc], 'Custom');
				console.log('Custom - Matched');
			}
		}
		callback();
	});
});
//DE79909: Filtering on turbine name in Turbine section
this.Given(/^Verify user is able to search the Turbine name in CAPS$/, function(callback) {
        taskMgmtPage.turbineSearchAllCaps().then(function(incaps) {
            taskMgmtPage.turbineSearchCases().then(function(completed) {
                console.log('Turbine name is:' + completed);
                callback();
            });
        });
    });
    this.Given(/^Verify user is able to search the Turbine name in small$/, function(callback) {
        taskMgmtPage.turbineSearchAllSmall().then(function(completed) {
            console.log('Turbine name is:' + completed);
            callback();
        });
    });
    this.Given(/^Verify user is able to search the Turbine name in Camel case$/, function(callback) {
        taskMgmtPage.turbineSearchCamelCase().then(function(completed) {
            console.log('Turbine name is:' + completed);
            callback();
        });
    });
    this.Given(/^Verify user is able to search the Turbine name in Mixed case$/, function(callback) {
        taskMgmtPage.turbineSearchMixedCase().then(function(completed) {
            console.log('Turbine name is:' + completed);
            callback();
        });
    });
    this.Then(/^Verify Turbine list for turbine name$/, function(callback) {
        taskMgmtPage.turbineSearchCases().then(function(completed) {
            console.log('Turbine name is:' + completed);
            callback();
        });
    });
//Priya
 
        this.Then(/^Verify user is able to add notes with opening parenthesis in POD reports page$/, function(callback) {
                taskMgmtPage.reportNotes5().then(function() {
                        //console.log("Text which entered is " + notes);
                        callback();
                });
         });
 
        this.Then(/^Verify the notes with opening parenthesis in POD reports page$/, function(callback) {
                taskMgmtPage.reportNotesText().then(function(notes) {
                        console.log("Text shown in notes section is " + notes);
                        //assert.equal(notes,'Testing open parenthesis... ( *');
                        callback();
                });
         });
        
        this.Then(/^Verify user is able to add notes with closing parenthesis in POD reports page$/, function(callback) {
                taskMgmtPage.reportNotes6().then(function(notes) {
                        callback();
                });     
         }); 
         
        this.Then(/^Verify the notes with closing parenthesis in POD reports page$/, function(callback) {
                taskMgmtPage.reportNotesText().then(function(notes) {
                        //assert.equal(notes,'Testing closing parenthesis... ) *');
                        console.log("Text shown in notes section is " + notes);
                        callback();
                });
         });
        
        this.Then(/^Verify user is able to add notes with all special characters in POD reports page$/, function(callback) {
                taskMgmtPage.reportNotes4().then(function(notes) {
                        //console.log("Text which entered is " + notes);
                        callback();
                });     
        }); 
        this.Then(/^Verify the notes with all special characters in POD reports page$/, function(callback) {
                taskMgmtPage.reportNotesText().then(function(notes) {
                        //assert.equal(notes,'Testing all special characters... ( @ # $ % ^ & * ( ) ! ~ > < ? / } { ] [ - = + *');
                        console.log("Text shown in notes section is " + notes);
                        callback();
                });
         });
        this.Then(/^Verify User able to click on Report Save button$/, function(callback) {
                taskMgmtPage.reportsSaveBtn().then(function() {
                 callback();
                });
         }); 
//DE81332 -Page keeps on loading and getting hung after clicking 'Print to email' for Report
       this.Then(/^I can click in the Report preview button$/, function(callback) {
                taskMgmtPage.printPreviewBtn().then(function() {
                 callback();
                });
         });
   this.Then(/^I can click in the Report print Email button$/, function(callback) {
                taskMgmtPage.printEmailBtn().then(function() {
                 callback();
                });
         });
this.Then(/^I can click in the Archive Report Back button$/, function(callback) {
                taskMgmtPage.archiveReportBackBtn().then(function() {
                 callback();
                });
         });
this.Then(/^I can click on the Personnel Management App Tab$/, function(callback) {
                taskMgmtPage.personnelMangTab().then(function() {
                 callback();
                });
         });
this.Then(/^I can click on the Assets Tab$/, function(callback) {
                taskMgmtPage.assetsMangTab().then(function() {
                 callback();
                });
         });
this.Then(/^I can wait for the Plan of the day Tab$/, function(callback) {
                taskMgmtPage.waitForPODMangTab().then(function() {
                 callback();
                });
         });
this.Then(/^I can click on the Plan of the day Tab$/, function(callback) {
                taskMgmtPage.planofthedayMangTab().then(function() {
                 callback();
                });
         });
this.Then(/^I can able to select Actual duration and Resolution notes$/, function(callback) {
                taskMgmtPage.inCompletetask().then(function() {
                 callback();
                });
         });
this.Then(/^I can verify entered Actual duration and Resolution notes$/, function(callback) {
                taskMgmtPage.taskCompleteIcon().then(function() {
                 callback();
                });
         });
this.Then(/^Click on Task page conformation message No button$/, function(callback) {
                taskMgmtPage.taskPageUnsavedNoBtn().then(function() {
                 callback();
                });
         });
this.Then(/^Click on Task page conformation message Yes button$/, function(callback) {
                taskMgmtPage.taskPageUnsavedYesBtn().then(function() {
                 callback();
                });
         });
this.Then(/^Click on Turbine status widget disable button$/, function(callback) {
                taskMgmtPage.turbineStatusWidgetInReports().then(function() {
                 callback();
                });
         });

this.Then(/^I can able to select Other category type$/, function(callback) {
        taskMgmtPage.otherTurbineCategory().then(function () {
                         callback();
		});
	});
	
this.Then(/^I should able to search Others task$/, function(callback) {
        taskMgmtPage.otherTaskSearch().then(function () {
                         callback();
		});
	});

this.Then(/^I can able to see the Other Task Type$/, function(callback) {
        taskMgmtPage.taskFilterPlusePoint().then(function (completed) {
			console.log("Here is the task Type: "+ completed);
			//TestHelper.assertTrue(completed, 'Pulse Point');
			assert.equal(completed, 'Other');
                         callback();
		});
	});
this.Then(/^I can able to select Others Task type$/, function(callback) {
taskMgmtPage.othersSiteCategoryType().then(function () {
                         callback();
		});
	});
this.Then(/^I can able to see the Others Task Type$/, function(callback) {
taskMgmtPage.taskTypeInLeftNavigation().then(function (completed) {
			console.log("Here is the task Type: "+ completed);
			//TestHelper.assertTrue(completed, 'Pulse Point');
			assert.equal(completed, 'Others');
                         callback();
		});
	});
	this.When(/^I can able to search the Others Task type$/, function(callback) {
        taskMgmtPage.othersTaskTypeSearch().then(function () {
                         callback();
		});
	});

	this.Then(/^I click on the complete a task icon in workplan section$/, function(callback) {
                taskMgmtPage.clickOnTaskComplete().then(function () {
                        //assert.isTrue(completed, 'Unable to click on Crew Name');
                        console.log("First Crew name is displayed under Crews section in Plan page");
                        callback();
                });
        });
 
        this.Then(/^Check if Actual duration is mendatory and asterisk mark in red color available$/, function(callback) {
                taskMgmtPage.CheckMendatoryFiledMark().then(function () {
                        console.log("Check if mendatory filed is available");
                        callback();
                });
        });
 
        this.Then(/^Check if Done button is disabled$/, function(callback) {
                taskMgmtPage.CheckDoneButtonDisabled().then(function () {
                        console.log("Check if done button disabled");
                        callback();
                });
        });
        
        this.Then(/^Changing Hrs value for actual duration$/, function(callback) {
                taskMgmtPage.changeActualDuration().then(function () {
                        callback();
                });
        });
        this.Then(/^Check if Done button is enabled with change actual duration$/, function(callback) {
                taskMgmtPage.CheckDoneButtonEnabled().then(function () {
                        console.log("Check if done button enabled");
                        callback();
                });
        });
        this.Then(/^Changing Hrs value to zero and Min value to non zero$/, function(callback) {
                taskMgmtPage.changeActualDurationHr().then(function () {
                        callback();
                });
        });
        this.Then(/^Check if Done button is enabled with changed actual duration Hrs and Mins$/, function(callback) {
                taskMgmtPage.CheckDoneButtonEnabled().then(function () {
                        console.log("Check if done button enabled");
                        callback();
                });
        });
	 this.Then(/^I am able to logout$/, function (callback) {
        element(by.xpath('//*[@id="pxh-user-menu"]/a/div[2]')).isPresent().then(function () {
            browser.sleep(5000);
            element(by.xpath('//*[@id="pxh-user-menu"]/a/div[2]')).click().then(function () {
                element(by.css('[title="Log Out"]')).isPresent().then(function () {
                    taskMgmtPage.logOut().then(function () {
                        browser.driver.isElementPresent(by.xpath('//*[@value="Sign in"]'));
                        callback();
                    });
                });
            });
        });
    });
    this.Then(/^Verify user is able to Click on Click on APM case Label$/, function(callback) {
          taskMgmtPage.validateAPMCaseURL(callback);
	});
    this.Then(/^Verify user is able to Click on Click on Edit APM case Label$/, function(callback) {
          taskMgmtPage.validateEditAPMCaseURL(callback);
	});
	
this.Then(/^User is able to drag and drop the Task from TORS to Planned Maintenance section$/, function(callback) {
                taskMgmtPage.reportsTaskdragDrop(callback);
         });
this.Then(/^User is able to drag and drop the Turbine from TORS to Planned Maintenance section$/, function(callback) {
                taskMgmtPage.reportsTurbinedragDrop(callback);
         });
this.Then(/^User is able to drag and drop the Task from Planned Maintenance to TORS section$/, function(callback) {
                taskMgmtPage.reportsPMTaskdragDrop(callback);
         });
this.Then(/^User is able to drag and drop the Turbine from Planned Maintenance to TORS section$/, function(callback) {
                taskMgmtPage.reportsPMTurbinedragDrop(callback);
         });

       this.Then(/^I can validate Show hide column tooltip in Tech report$/, function(callback) {
                taskMgmtPage.techReportShowhideTooltip().then(function () {
                        callback();
                });
        });

	this.Then(/^I can enter the turbine name in search field$/, function(callback) {
                taskMgmtPage.addTaskSearchBox().then(function () {
                        callback();
                });
        });

	this.Then(/^I can add Turbine to work plan section$/, function(callback) {
                taskMgmtPage.selectAssetOne(callback);
         });

this.Then(/^I can validate APM Case Priority Field$/, function(callback) {
      taskMgmtPage.apmCasePriorityValidation().then(function (value) {
          console.log("APM Case(s) Priority Field disabled: " + value);
          callback();
      });
   });

   this.Then(/^I can validate APM Case Recurrence Field$/, function(callback) {
      taskMgmtPage.apmCaseRecurrenceValidation().then(function (value) {
          console.log("APM Case(s) Recurrence Field disabled: " + value);
          callback();
      });
   });
   this.Then(/^I can validate APM case Duedate field$/, function(callback) {
                taskMgmtPage.apmCaseDuedateFld().then(function () {
                        callback();
                });
        });

this.When(/^I can able to search Maintenance Task$/, function(callback) {
        taskMgmtPage.activeSearchBtnMaintenance().then(function () {
                         callback();
		});
	});

this.Then(/^I can validate Maintenance task Priority Field$/, function(callback) {
      taskMgmtPage.maintenanceTaskPriority().then(function (value) {
          console.log("Maintenance Priority Field enabled: " + value);
          callback();
      });
   });

   this.Then(/^I can validate Maintenance task Recurrence Field$/, function(callback) {
      taskMgmtPage.maintenanceTaskRecurrence().then(function (value) {
          console.log("Maintenance Recurrence Field enabled: " + value);
          callback();
      });
   });

   this.Then(/^I can validate Maintenance task Duedate field$/, function(callback) {
                taskMgmtPage.maintenanceDuedateFld().then(function () {
                        callback();
                });
        });

	//*** Previous day reports  */
    this.Then(/^I navigate to previous day report$/, function(callback) {
	taskMgmtPage.navigateToPreviusDayReport().then(function () {
			callback();
		});
	});

	this.Then(/^I navigate to current day report$/, function(callback) {
	taskMgmtPage.navigateToCurrentDayReport().then(function () {
		 callback();
		});
	});

	this.Then(/^I can see the number of turbines Online$/, function(callback) {
        taskMgmtPage.fetchCountTurbinesOnline().then(function () {
                         callback();
		});
	});

	this.Then(/^I can validate the number of turbines Online$/, function(callback) {
	taskMgmtPage.validateCountTurbinesOnline().then(function () {
			callback();
		});
	});

  this.Then(/^I can view site Name in Weather widget$/, function(callback) {
	taskMgmtPage.fetchWeatherWidgetSiteName().then(function () {
			callback();
		});
	});

  this.Then(/^I can validate site Name in Weather widget$/, function(callback) {
	taskMgmtPage.validateWeatherWidgetSiteName().then(function () {
		callback();
		});
	});

  this.Then(/^Verify user is able to click on PDF Reports for POD$/, function(callback) {
        taskMgmtPage.reportEODArchivePDFReport().then(function (Completed) {
	console.log("Report header: "+ Completed);
                         callback();
		});
	});

    this.Then(/^Verify user is able to clear existing notes in EOD reports page$/, function(callback) {
        taskMgmtPage.reportEODNotes().then(function () {
                         callback();
		});
	});

	this.Then(/^Verify user is able to clear existing notes in Tech reports page$/, function(callback) {
        taskMgmtPage.reportTechReportNotes().then(function () {
                         callback();
		});
	});

   this.Then(/^Verify user is able to add notes in EOD reports page$/, function(callback) {
        taskMgmtPage.addReportEODNotes().then(function () {
                         callback();
		});
	});

   this.Then(/^Verify user is able to add notes in Tech reports page$/, function(callback) {
	taskMgmtPage.addTechReportNotes().then(function () {					
			callback();
		});
	});
	

};
