(function() {
    'use strict';

    var currentPage = 'casePage';

    var CasePage = function() {

        return {

            clickCasesMicroAppLink: function () {
                browser.waitForAngular();
                browser.sleep(10000);//Adding wait time for the case to get created
                return TestHelper.elementToBeClickable(currentPage, "casesTab");
            },

            verifyCaseStatus: function () {
                browser.driver.sleep(5000);
                browser.waitForAngular();
                return TestHelper.getText(currentPage, "caseStatus");
            },

            clickCreateCaseIcon: function () {
                browser.driver.sleep(2000);
                browser.waitForAngular();
                return TestHelper.elementToBeClickable(currentPage, "createCase");
            },

            inputCaseTitle: function (caseTitle) {
                browser.driver.sleep(2000);
                browser.waitForAngular();
                return cem.findElement(currentPage,"inputCaseTitle").sendKeys(caseTitle);
            },

            clickAssetSelectionLink: function () {
                browser.driver.sleep(2000);
                browser.waitForAngular();
                return TestHelper.elementToBeClickable(currentPage, "assetSelectionLink");
            },

            navigateToTurbineUnderAssetHierarchy: function () {
                browser.waitForAngular();
                browser.sleep(5000);
                return TestHelper.elementToBeClickable(currentPage, 'systemEnterprise').then(function () {
                     browser.waitForAngular();
                     browser.sleep(5000);
                return TestHelper.elementToBeClickable(currentPage, 'systemEnterprise').then(function () {
                     browser.waitForAngular();
                     browser.sleep(5000);
                     return TestHelper.elementToBeClickable(currentPage, 'systemSite').then(function () {
                         browser.waitForAngular();
                         browser.sleep(5000);
                     return TestHelper.elementToBeClickable(currentPage, 'systemSite').then(function () {
                         browser.waitForAngular();
                         browser.sleep(5000);
                         return TestHelper.elementToBeClickable(currentPage, 'systemSegment').then(function () {
                             browser.waitForAngular();
                             browser.sleep(5000);
                         return TestHelper.elementToBeClickable(currentPage, 'systemSegment').then(function () {
                             browser.waitForAngular();
                             browser.sleep(5000);
                             return TestHelper.elementToBeClickable(currentPage, 'systemAsset').then(function () {
                             });
                         });
                         });
                     });
                     });
                });
                });

            },

            clickAssetSelectionOkButton: function () {
                browser.driver.sleep(3000);
                browser.waitForAngular();
                return cem.findElement(currentPage,"assetSelectionOkButton").click();
            },

            clickCreateCaseButton: function () {
                browser.waitForAngular();
                browser.sleep(8000);
                return cem.findElement(currentPage,"caseCreateButton").click();
            },

            clickLatestCaseFromInbox: function () {
                browser.driver.sleep(7000);
                browser.waitForAngular();
                return TestHelper.elementToBeClickable(currentPage, "latestCaseFromInbox");
            },

            verifyTurbineNameCaseDetails: function () {
                browser.driver.sleep(3000);
                return TestHelper.isElementPresent(currentPage, "turbineNameCaseDetails").then(function(){
                    var element = cem.findElement(currentPage, "turbineNameCaseDetails")
                    return element.getText();
                });
            },

            verifyCaseTitle: function () {
                browser.driver.sleep(3000);
                return TestHelper.isElementPresent(currentPage, "caseTitle").then(function(){
                    var element = cem.findElement(currentPage, "caseTitle");
                    return element.getText();
                });
            },

            verifyGridContainer: function () {
                browser.driver.sleep(2000);
                return element(by.xpath("//span[@id ='casesGridViewToggleContainer']//i[contains(@class,'fa-list style-scope px-view-header')]")).isPresent().then(function(flag){
                    console.log("Flag is :" + flag);
                    if(flag===false){
                        element(by.xpath("//span[@id ='casesGridViewToggleContainer']//i[contains(@class,'fa-columns style-scope px-view-header')]")).click();
                        console.log("Switch to Grid view");
                    }else{
                        console.log("Timeline View is selected ");
                    }
                });
            },

            assetId:function (assetId) {
                browser.driver.sleep(2000);
                console.log("Asset Id is : " +assetId);
                return element(by.xpath("//*[@id ='asset_id']")).sendKeys(assetId + protractor.Key.TAB);
            },

            changeStatus:function (status) {
                browser.sleep(3000);
                return element(by.xpath("//*[@class='case-status-container']")).click().then(function(){
                    browser.sleep(3000);
                    element(by.xpath('//*[@title="'+status+'"]')).click();
                })
            },

            changeUrgency:function (action) {
                browser.sleep(2000);
              return  browser.actions().mouseMove(element(by.xpath("(//*[@class='btn-group flex__item dropdown'][3])/div/em"))).click().perform().then(function () {
                    browser.sleep(3000);
                    element(by.xpath('//*[@title="'+action+'"]')).click();
                });
            },

            changeUrgency1:function (actions) {
                browser.sleep(2000);
              return  browser.actions().mouseMove(element(by.xpath("(//*[@class='btn-group flex__item dropdown'][3])/div/em"))).click().perform().then(function () {
                    browser.sleep(3000);
                    element(by.xpath('//*[@title="'+actions+'"]')).click();
                });
            },

            enterSymptoms: function (NewSymptoms) {
                browser.driver.sleep(2000);
              TestHelper.elementToBeClickable(currentPage,"enterSymptoms");
                var all = cem.findElement(currentPage, "enterSymptomsText");
                all.clear();
                return all.sendKeys(NewSymptoms + protractor.Key.TAB);
            },

            enterDiagnosis: function (Diamessage) {
                browser.driver.sleep(2000);
                TestHelper.elementToBeClickable(currentPage,"enterDiagnosis");
                var all = cem.findElement(currentPage, "enterDiagnosisText");
                all.clear();
                return all.sendKeys(Diamessage + protractor.Key.TAB);
            },

            enterRecommendation: function (Recmessage) {
                browser.driver.sleep(2000);
                TestHelper.elementToBeClickable(currentPage,"enterRecommendation");
                var all = cem.findElement(currentPage, "enterRecommendationText");
                all.clear();
                return all.sendKeys(Recmessage + protractor.Key.TAB);
            },

            caseNameUpdate:function(caseNameUpdate){
                browser.driver.sleep(2000);
                TestHelper.elementToBeClickable(currentPage,"caseName");
                var all = cem.findElement(currentPage, "caseNameUpdate");
                all.clear();
                return all.sendKeys(caseNameUpdate + protractor.Key.TAB);
            },

            caseStatusValidate:function(status){
                browser.driver.sleep(2000);
                console.log("Current status is : " +status);
                browser.sleep(3000);
                return element(by.xpath("//*[@class='case-status-container']")).click().then(function(){
                    browser.sleep(3000);
                    element(by.xpath('//*[@title="'+status+'"]')).click();
                    if(status==="Closed"){
                        TestHelper.elementToBeClickable(currentPage,"closureCode");
                        TestHelper.elementToBeClickable(currentPage,"action");
                        TestHelper.elementToBeClickable(currentPage,"closeCase");
                        browser.sleep(3000);
                       return TestHelper.getText(currentPage, "caseStatus").then(function(uiCaseStatus) {
                            console.log("Case status from UI is : " + uiCaseStatus);
                            assert.equal(status, uiCaseStatus);
                        });
                    }
                    else{
                        TestHelper.getText(currentPage, "caseStatus").then(function(uiCaseStatus) {
                            console.log("Case status from UI is : " + uiCaseStatus);
                            return assert.equal(status, uiCaseStatus);
                        });
                    }
                });
            },

            optionSign:function(){
                browser.driver.sleep(2000);
                TestHelper.isElementPresent(currentPage,"optionSign");
                return TestHelper.elementToBeClickable(currentPage,"optionSign");
            },

            deleteCasebtn:function(){
                browser.driver.sleep(2000);
                TestHelper.isElementPresent(currentPage,"deleteCase");
                TestHelper.elementToBeClickable(currentPage,"deleteCase");
                return TestHelper.elementToBeClickable(currentPage,"conformDelete");
            },

            deleteCase:function () {
                browser.sleep(3000);
                return element(by.xpath("//*[@class='case-operations-kabob fa fa-ellipsis-v dropdown-toggle flex__item']")).click().then(function(){
                    browser.sleep(3000);
                    element(by.xpath("//*[@name='delete_case']")).click();
                    element(by.xpath("/html/body/div[1]/div/div/div/div[2]/button[2]")).click();
                })
            },

            deleteCaseText:function () {
                browser.driver.sleep(2000);
                var deleteHeader = "Delete Case";
                var deleteBody = 'Are you sure you want to delete this Case?';
                var deleteConfBtn = 'Delete Case';

                return cem.findElement(currentPage,'deleteHeader').getText().then(function (presentHeader) {
                    console.log("Header is : "+presentHeader);
                    assert.equal(deleteHeader,presentHeader);


                    cem.findElement(currentPage,'deleteBody').getText().then(function (presentBody) {
                        console.log("Body is : " + presentBody);
                        assert.equal(deleteBody, presentBody);


                        cem.findElement(currentPage, 'deleteConfBtn').getText().then(function (presentPad) {
                            console.log("Delete button is : " + presentPad);
                            assert.equal(deleteConfBtn, presentPad);

                        });
                    });
                });
            },

            deleteConfButton: function () {
                browser.waitForAngular();
                browser.sleep(5000);
                return cem.findElement(currentPage,"deleteConfBtn").click();
            },

            planofthedayMangTab: function () {
                browser.waitForAngular();
                browser.sleep(35000);//Adding wait time for the navigating to DOP app
                return cem.findElement(currentPage,"planofthedayMangTab").click();
            },

            isTaskMangmntTabVisibile: function () {
             browser.waitForAngular();
             browser.driver.sleep(12000);//Adding wait time to load Task page
			 return TestHelper.isElementPresent(currentPage,'taskMangmntTab');
            },

            taskpageTab: function () {
                browser.waitForAngular();
                browser.driver.sleep(12000);//Adding wait time for the navigating to Task page
                return cem.findElement(currentPage,'taskMangmntTab').click();
            },

            searchTask:function (caseTitle) {
                browser.sleep(6000);
                return TestHelper.elementToBeClickable(currentPage, "activeSearchBtn").then(function(){
                browser.sleep(2000);
                element(by.xpath("//*[@ng-model='searchField']")).sendKeys(caseTitle + protractor.Key.TAB);
                });
            },

            verifyTaskTitle: function () {
                browser.sleep(6000);
                return TestHelper.isElementPresent(currentPage, "pendingTaskTitle").then(function(){
                    var element = cem.findElement(currentPage, "pendingTaskTitle");
                    return element.getText();
                });
            },

            selectCase: function () {
                browser.sleep(5000);
                return TestHelper.isElementPresent(currentPage, "selectCase").then(function(){
                    browser.sleep(5000);
                   cem.findElement(currentPage, "selectCase").click();
                });
            },

            selectSite1: function (site) {
                browser.waitForAngular();
                browser.driver.sleep(22000);//Adding wait time to display context browser
                cem.findElement(currentPage, 'siteGroupDropdwn').click();
                browser.driver.sleep(3000);
                return element(by.xpath('//*[@class="selected list-bare level style-scope px-context-browser"]//li//span[text()="' + site + '"]')).click();
            },


            InfoTaskValidation: function () {
                browser.sleep(6000);
                return TestHelper.isElementPresent(currentPage, "noResultsFoundInTaskpage").then(function(){
                    var element = cem.findElement(currentPage, "noResultsFoundInTaskpage");
                    return element.getText();
                });
            },

            actionTimeframe: function () {
            browser.waitForAngular();
            browser.driver.sleep(5000);
            return cem.findElement(currentPage,'actionTimeframe').getText();
              },

           actionPurpose: function () {
           browser.waitForAngular();
            browser.driver.sleep(5000);
            return cem.findElement(currentPage,'actionPurpose').getText();
            },

           /* immediateTimeFrame:function () {
                browser.sleep(3000);
                return element(by.xpath("(//*[@class='fa fa-angle-down u-pl-'])[2]")).click().then(function(){
                    browser.sleep(3000);
                   var element = element(by.xpath("//*[@class='case-action-urgency-link ng-binding'][contains(text(),'Before Continued Operation')]"));
                   return element.getText();
                });
            },

            nextOppTimeFrame:function () {
                browser.sleep(3000);
                return element(by.xpath("(//*[@class='fa fa-angle-down u-pl-'])[2]")).click().then(function(){
                    browser.sleep(3000);
                   var element = element(by.xpath("//*[@class='case-action-urgency-link ng-binding'][contains(text(),'Next Available Opportunity')]"));
                   return element.getText();
                });
            },

            nextTowerTimeFrame:function () {
                browser.sleep(3000);
                return element(by.xpath("(//*[@class='fa fa-angle-down u-pl-'])[2]")).click().then(function(){
                    browser.sleep(3000);
                   var element = element(by.xpath("//*[@class='case-action-urgency-link ng-binding'][contains(text(),'Next Scheduled Outage')]"));
                   return element.getText();
                });
            },

            immediateActionPurpose:function () {
                browser.sleep(3000);
                return element(by.xpath("(//*[@class='fa fa-angle-down u-pl-'])[1]")).click().then(function(){
                    browser.sleep(3000);
                   var element = element(by.xpath("//*[@class='case-action-purpose-link ng-binding'][contains(text(),'Resolve')]"));
                            return element.getText();

                });
            },  */

             recommendedSelected: function () {
                 browser.waitForAngular();
                browser.driver.sleep(8000);
                return expect(element(by.xpath("//*[@class='ng-binding color-selected-stage'][contains(.,' Recommended ')]")).isPresent()).to.eventually.be.equals(true);
            },

            plannedSelected: function () {
                browser.waitForAngular();
                browser.driver.sleep(8000);
                return expect(element(by.xpath("//*[@class='ng-binding color-selected-stage'][contains(.,' Planned ')]")).isPresent()).to.eventually.be.equals(true);
            },
            turbineSearch: function (caseTitle) {
                browser.sleep(2000);
                return TestHelper.elementToBeClickable(currentPage, "activeSearchTurbine").then(function(){
                    browser.sleep(2000);
                    element(by.xpath("//*[@ng-model='inputLabel.labelFilter']")).sendKeys(caseTitle + protractor.Key.TAB);
                });
             },

             taskSearch: function () {
                browser.waitForAngular();
                browser.driver.sleep(2000);
                return cem.findElement(currentPage,'taskSearch').sendKeys('51');
                 },

                 validateCaseStatus: function () {
                browser.sleep(6000);
                return TestHelper.isElementPresent(currentPage, "verifyCaseStatus").then(function(){
                    var element = cem.findElement(currentPage, "verifyCaseStatus");
                    return element.getText();
                });
            },

            completedSelected: function () {
                 browser.waitForAngular();
                browser.driver.sleep(8000);
                return expect(element(by.xpath("//*[@class='ng-binding color-selected-stage'][contains(.,' Completed ')]")).isPresent()).to.eventually.be.equals(true);
            },

            selectClosureCodeandCloseCase: function () {
                browser.sleep(5000);
                browser.waitForAngular();
                return cem.findElement(currentPage,"closureCodeDrowdown").click().then(function () {
                    browser.waitForAngular();
                    browser.sleep(5000);
                    return cem.findElement(currentPage,"selectValueClosureCodeDrowdown").click().then(function () {
                        browser.waitForAngular();
                        browser.sleep(5000);
                        return cem.findElement(currentPage,"closeCaseButton").click().then(function () {
                        });
                    });
                });

            },


           actionTimeframeNewAction: function () {
              browser.waitForAngular();
              browser.driver.sleep(3000);
              return cem.findElement(currentPage,'actionTimeframeNewAction').getText();
            },

            actionPurposeNewAction: function () {
            browser.waitForAngular();
             browser.driver.sleep(3000);
             return cem.findElement(currentPage,'actionPurposeNewAction').getText();
             },

            actionTitle: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage,'actionTitle').getText();
            },

            actionTitleNewAction: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage,'actionTitleNewAction').getText();
            },

            actionComments: function () {
                browser.waitForAngular();
                browser.driver.sleep(3000);
                return cem.findElement(currentPage,'actionComments').getText();
            },

            completedSelected: function () {
                browser.waitForAngular();
                browser.driver.sleep(8000);
                return expect(element(by.xpath("//*[@class='ng-binding color-selected-stage'][contains(.,' Completed ')]")).isPresent()).to.eventually.be.equals(true);
            },

            verifyCaseResolutionNotes:function () {
                browser.driver.sleep(3000);
                var Resolution = "Complete Task";
                return cem.findElement(currentPage,'verifyCaseResolutionNotes').getText().then(function (rNotes) {
                    console.log("Resolution Notes is : "+rNotes);
                    assert.equal(Resolution,rNotes);
                });
            },

            verifyCase1000CharResolutionNotes:function () {
                browser.driver.sleep(3000);
                var Resolutions = "Before you can begin to determine what the composition of a particular paragraph will be, you must first decide on an argument and a working thesis statement for your paper. What is the most important idea that you are trying to convey to your reader? The information in each paragraph must be related to that idea. In other words, your paragraphs should remind your reader that there is a recurrent relationship between your thesis and the information in each paragraph. A working thesis functions like a seed from which your paper, and your ideas, will grow. The whole process is an organic one—a natural progression from a seed to a full-blown paper where there are direct, familial relationships between all of the ideas in the paper. The decision about what to put into your paragraphs begins with the germination of a seed of ideas this germination process is better known as brainstorming. There are many techniques for brainstorming; whichever one you choose, this stage of paragraph development cannot be skipped. Building paragraphs can be like building a skyscraper: there must be a well-planned foundation that supports what you are building. Any cracks, inconsistencies, or other corruptions of the foundation can cause your whole paper to crumble.So, let’s suppose that you have done some brainstorming to develop your thesis. What else should you keep in mind as you begin to create paragraphs.There are many different ways to organize a paragraph. The organization you choose will depend on the controlling idea of the paragraph. Below are a few possibilities for organization, with links to brief examples:Narration: Tell a story. Go chronologically,from start to finish. See an example. Description: Provide specific details about what something looks, smells, tastes, sounds, or feels like. Organize spatially, in order of appearance, or by topic. See an example. Narration: Tell a story. Go chronologically,from start to finish. See an example.Before you can begin to determine what the composition of a particular paragraph will be, you must first decide on an argument and a working thesis statement for your paper. What is the most important idea that you are trying to convey to your reader? The information in each paragraph must be related to that idea. In other words, your paragraphs should remind your reader that there is a recurrent relationship between your thesis and the information in each paragraph. A working thesis functions like a seed from which your paper, and your ideas, will grow. The whole process is an organic one—a natural progression from a seed to a full-blown paper where there are direct, familial relationships between all of the ideas in the paper. The decision about what to put into your paragraphs begins with the germination of a seed of ideas; this germination process is better known as brainstorming. There are many techniques for brainstorming; whichever one you choose, this stage of paragraph development cannot be skipped. Building paragraphs can be like building a skyscraper: there must be a well-planned foundation that supports what you are building. Any cracks, inconsistencies, or other corruptions of the foundation can cause your whole paper to crumble.So, let’s suppose that you have done some brainstorming to develop your thesis. What else should you keep in mind as you begin to create paragraphs The decision about what to put into your paragraphs begins with the germination of a seed of ideas this germination process is better known as brainstorming. There are many techniques for brainstorming whichever one you choose, this stage of paragraph development cannot be skipped. Building paragraphs can be like building a skyscraper: there must be a well-planned foundation that supports what you are building. Any cracks, inconsistencies, or other corruptions of the foundation can cause your whole paper to crumble";
                return cem.findElement(currentPage,'verifyCaseResolutionNotes').getText().then(function (rNotes) {
                    console.log("Resolution Notes is : "+rNotes);
                    assert.equal(Resolutions,rNotes);
                });
            },

            deleteBtnDisableTaskpage: function () {
                 browser.waitForAngular();
                browser.driver.sleep(8000);
                return expect(element(by.xpath("//*[@class='fa fa-trash-o ng-scope disabledAction']")).isPresent()).to.eventually.be.equals(true);
            },

            taskDueDate: function () {
            browser.waitForAngular();
            browser.driver.sleep(4000);
            return cem.findElement(currentPage,'taskDueDate').getText();
              },

              verifyTaskDescription: function () {
                browser.sleep(6000);
               return TestHelper.isElementPresent(currentPage, "taskDescriptionDpod").then(function(){
                    var element = cem.findElement(currentPage, "taskDescriptionDpod");
                    return element.getText();
                });
            },

            taskPriority: function () {
            browser.waitForAngular();
            browser.driver.sleep(4000);
           return cem.findElement(currentPage,'taskPriority').getText();
          },

          editCase: function () {
          browser.waitForAngular();
          browser.driver.sleep(4000);
          return cem.findElement(currentPage,'caseNameToEdit').getText();
        },

        clickCasesName: function () {
            browser.waitForAngular();
            browser.driver.sleep(4000);
            return cem.findElement(currentPage,'caseNameToEdit').click();
        },

        updateCaseName: function (newName) {
                  browser.waitForAngular();
                  browser.driver.sleep(8000);
                  cem.findElement(currentPage,'caseEditInput').clear();
                 return cem.findElement(currentPage,'caseEditInput').sendKeys(newName + protractor.Key.TAB);

        },
        completedSelected: function () {
           browser.driver.sleep(3000);
            return expect(element(by.xpath("//*[@class='ng-binding color-selected-stage'][contains(.,' Completed ')]")).isPresent()).to.eventually.be.equals(true);
        },
        acceptActionButtonClicked: function () {
            browser.driver.sleep(3000);
            return cem.findElement(currentPage,'acceptActionButton').click();
        },
        acceptButtonClicked: function () {
            browser.driver.sleep(3000);
            return cem.findElement(currentPage,'acceptButton').click();
        },
        taskCurrentStatus: function () {
            browser.waitForAngular();
            browser.driver.sleep(6000);
            return cem.findElement(currentPage,'taskCurrentStatus').getText().then(function (taskStatus) {
                console.log("Task status of DPOD : "+taskStatus);
                return cem.findElement(currentPage,'taskCurrentStatus').getText();
            });
        },
        createActionButtonClicked: function () {
            browser.driver.sleep(3000);
            return cem.findElement(currentPage,'createActionButton').click();
        },
        createActionTitle: function (actionTitle) {
            browser.waitForAngular();
            return cem.findElement(currentPage,"createActionTitle").sendKeys(actionTitle);
        },
        createActionCloseButtonClicked: function () {
            browser.driver.sleep(3000);
            return cem.findElement(currentPage,'createActionCloseButton').click();
        },
        latestActionCreated: function () {
            browser.waitForAngular();
            return cem.findElement(currentPage,'latestActionCreated').getText().then(function (actionTitle) {
                console.log("Title of Action created : "+actionTitle);
                return cem.findElement(currentPage,'latestActionCreated').getText();
            });
        },
        verifyTaskPriority: function () {
            browser.waitForAngular();
            return cem.findElement(currentPage,'taskPriority1').getText().then(function (priority) {
                console.log("Priority of task : "+priority);
                return cem.findElement(currentPage,'taskPriority1').getText();
            });
        },
        latestActionDelete: function () {
            browser.waitForAngular();
            return cem.findElement(currentPage,'latestActionDelete').click();
        },
        actionDeleteYesButton: function () {
            browser.waitForAngular();
            return cem.findElement(currentPage,'actionDeleteYesButton').click();
        },


        changeTimeframe:function () {
            browser.sleep(12000);
            browser.waitForAngular();
              return element(by.xpath("(//*[@id='content']/div[2]/section/div/section/div/div[2]/case-details/div/div[2]/div/div/div[6]/case-actions/div/div[2]/div/div/div/div[4]/div/div[2]/div[2]/div/div[2])[1]")).click();
              //return element(by.id('(//div[@name='timeframe-dropdown'][@class='min-width-70 white-space-nowrap case-actions-code-button ng-binding dropdown-toggle'])/i')).click();

        },

        selectTimeframe:function () {
            browser.sleep(12000);
            browser.waitForAngular();
            return element(by.xpath("//*[@id='timeframe-1']")).click();
            //return element(by.id('timeframe-1')).click();

        },

        validateCaseUrgency: function () {
            browser.driver.sleep(5000);
            browser.waitForAngular();
            return TestHelper.getText(currentPage, "verifyCaseUrgency");
        }

        };
	};

    module.exports = new CasePage();

}());
