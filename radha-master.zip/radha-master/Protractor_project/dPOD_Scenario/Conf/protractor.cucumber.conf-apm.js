/**
 * Created by 212556710 on 5/9/16.

 */
exports.config = {

	sauceUser: null,
		sauceKey: null,
		sauceSeleniumAddress: null,
		directConnect: false,
		firefoxPath: null,
		//chromeDriver: '../../../chrome-driver/chromedriver_2.33.exe',
		//chromeDriver: '../../../node_modules/protractor/selenium/chromedriver_2.33',

	// Organize spec files into suites. To run specific suite, --suite=<name of suite>
	suites: {

		crewInPlan:[//"../Features/APM_DPOD_Integration.feature",
		"../Features/APM_DPOD_Integration_Preprod.feature",
		//"../Features/DPOD_Test.feature",
			//"../Features/apm_integration.feature",
			//"../Features/dPODTaskAPMCase.feature",	    
			   ],

	},

	// Hooks running in the background
	plugins: [{
		path: '../../node_modules/proui-utils/Compressed_Utils/GeneralHook.js',
		// path: 'hook.js',

	}],

	capabilities: {
			browserName: 'chrome',
			/*proxy:{
                proxyType:'manual',
                httpProxy: 'sjc1intproxy01.crd.ge.com:8080',
                sslProxy: 'sjc1intproxy01.crd.ge.com:8080',
            },*/
			count: 1,
			shardTestFiles: false,
			maxInstances: 1,
			'chromeOptions': {
				args: ['--no-sandbox', '--test-type=browser'],
				prefs: {
					'download': {
						'prompt_for_download': false,
						'directory_upgrade': true,
						'default_directory': 'C:/Jenkins/sharedspace/public/test/e2e-reboot/steps/'
					}
				}
			}
		},

	/* params: {
		env: 'qa'
	}, */

	maxSessions: -1,
		allScriptsTimeout: 250000,
		getPageTimeout: 1650000,
		beforeLaunch: function () {
		},
		onPrepare: function () {
			var folderName = (new Date()).toString().split(' ').splice(1, 4).join(' ');
			var mkdirp = require('mkdirp');
			var reportsPath = "./Reports/";
			mkdirp(reportsPath, function (err) {
				if (err) {
					console.error(err);
				} else {
				}
			});

			browser.manage().deleteAllCookies();
			browser.manage().timeouts().pageLoadTimeout(90000);
			browser.manage().timeouts().implicitlyWait(90000);
			browser.driver.manage().window().maximize();
			//browser.manage().window().setSize(1400, 900);
			chai = require('chai');
			expect = chai.expect;
			path = require('path');
			Cucumber = require('cucumber');
			fs = require('fs');

		// Initializing necessary utils from ProUI-Utils module
		TestHelper = require('proui-utils').TestHelper;
		TestHelperPO = require('proui-utils').TestHelperPO;
		ElementManager = require('proui-utils').ElementManager;
		Logger = require('proui-utils').Logger;
		cem = new ElementManager('../../../dPOD_Scenario/taskmngmnt-element-repo.json');
		//cem = new ElementManager('../../../planmngmnt-element-repo.json');
		TestHelper.setElementManager(cem);
		RestHelper = require('proui-utils').RestHelper;

		// Initializing page object variables
		taskMgmtPage = require('../PageObjects/dPODTaskMgmt_po.js');
		casePage = require('../PageObjects/case_po.js');
		//planMgmtPage = require('../PageObjects/dPODPlanMgmt_po.js');
		//commonTestData = require('../../TestData/common-test-data.json').data;
	},

	// A callback function called once tests are finished
	onComplete: function() {},


	// A callback function called once tests are cleaning up
	onCleanUp: function(exitCode) {

	},

	// A callback function after tests are launched
	afterLaunch: function() {

	},

	// Browser parameters for feature files.

	params: {
		login: {
			//baseUrl: 'https://apmpreprod.apm.aws-usw02-pr.predix.io/ren-wind-dev/plan/#/dashboard',
			//baseUrl: 'https://apmpreprod.apm.aws-usw02-pr.predix.io/gere-qa/plan/#/dashboard',
			baseUrl: 'https://apmpreprod.preprod-app.aws-usw02-pr.predix.io/ge-wind-dfsa/plan/#/dashboard',
			//baseUrl: 'https://apmpreprod.apm.aws-usw02-pr.predix.io/ren-wind-dev/',

			"username": "502790245",
			"password": "r300FqRZ2t",


			"btn": '//*[@value="Log In & Remember Me"]',
			//"Value": "121",

		}
	},

	resultJsonOutputFile: null,

	// If true, protractor will restart the browser between each test.
	// CAUTION: This will cause your tests to slow down drastically.
	restartBrowserBetweenTests: false,

	// Custom framework in this case cucumber
	framework: 'custom',
	frameworkPath: require.resolve('protractor-cucumber-framework'),
	cucumberOpts: {

		// define your step definitions in this file
		require: [
			'../step_definitions/env.js',
			'../step_definitions/dPODTaskMngmt-spec.js',
			//'../step_definitions/dPODQ3-spec.js',
			//'../step_definitions/dPODPlanMngmt-spec.js',
			'../step_definitions/dPODReportsMngmt-spec.js',
			'../step_definitions/case-spec.js',
			'../../node_modules/proui-utils/Compressed_Utils/Reporter.js'
		],

		//format: 'pretty'
	}
};
